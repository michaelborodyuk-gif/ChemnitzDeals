import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { UserState, Transaction, Quest, Partner, RewardTier, Challenge } from "../types";
import { INITIAL_USER_STATE, MOCK_QUESTS, MOCK_PARTNERS, MOCK_TRANSACTIONS, MOCK_CHALLENGES, COIN_CONFIG } from "../constants";
import { supabase, isSupabaseConfigured as isSupabaseConfiguredFlag } from "../lib/supabase";
import { useAuth } from "./AuthContext";

interface UserContextType {
  user: UserState;
  quests: Quest[];
  partners: Partner[];
  transactions: Transaction[];
  isLoading: boolean;
  addCoins: (amount: number, description: string, type?: Transaction["type"]) => void;
  spendCoins: (amount: number, description: string) => void;
  toggleFavorite: (partnerId: string) => void;
  updateMoji: (config: UserState["mojiConfig"]) => void;
  joinLeaderboard: () => void;
  claimReward: (partnerId: string, tierId: string) => void;
  unlockReward: (partnerId: string, tierId: string) => void;
  checkIn: (partnerId: string) => void;
  submitStory: (partnerId: string, instagram: string) => void;
  completeQuest: (questId: string) => void;
  sharePartnerPost: (partnerId: string) => void;
  followPartnerSocial: (partnerId: string) => void;
  submitGoogleReview: (partnerId: string) => void;
  claimDailyScratch: () => void;
  supportPartner: (partnerId: string) => void;
  unsupportPartner: () => void;
  claimSupporterBonus: () => void;
  openBlindBox: () => void;
  incrementDuelCount: () => void;
  addPartnerCoins: (partnerId: string, amount: number, description: string) => void;
  refreshData: () => Promise<void>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

// Helper: Check if Supabase is configured
const isSupabaseConfigured = () => isSupabaseConfiguredFlag;

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const auth = useAuth();
  const [user, setUser] = useState<UserState>(INITIAL_USER_STATE);
  const [quests, setQuests] = useState<Quest[]>(MOCK_QUESTS);
  const [partners, setPartners] = useState<Partner[]>(MOCK_PARTNERS);
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
  const [isLoading, setIsLoading] = useState(false);
  const useSupabase = isSupabaseConfigured() && !!auth.user;

  // Load data from Supabase when authenticated
  const refreshData = useCallback(async () => {
    if (!useSupabase || !auth.user) return;
    setIsLoading(true);

    try {
      // Load partners with their tiers
      const { data: partnersData } = await supabase
        .from("partners")
        .select("*, reward_tiers(*)");

      if (partnersData) {
        // Load user reward states
        const { data: userRewards } = await supabase
          .from("user_rewards")
          .select("*")
          .eq("user_id", auth.user.id);

        const rewardMap = new Map<string, { isUnlocked: boolean; isClaimed: boolean }>();
        userRewards?.forEach(ur => {
          rewardMap.set(ur.tier_id, { isUnlocked: ur.is_unlocked, isClaimed: ur.is_claimed });
        });

        const mappedPartners: Partner[] = partnersData.map((p: any) => ({
          id: p.id,
          name: p.name,
          category: p.category,
          location: p.location,
          coordinates: { lat: p.lat, lng: p.lng },
          image: p.image,
          description: p.description,
          rating: p.rating,
          visitorCount: p.visitor_count,
          instagram: p.instagram,
          briefFacts: p.brief_facts || [],
          tiers: (p.reward_tiers || [])
            .sort((a: any, b: any) => a.sort_order - b.sort_order)
            .map((t: any) => ({
              id: t.id,
              title: t.title,
              description: t.description,
              type: t.type,
              unlockMethod: t.unlock_method,
              coinCost: t.coin_cost,
              isUnlocked: rewardMap.get(t.id)?.isUnlocked ?? (t.unlock_method === "none"),
              isClaimed: rewardMap.get(t.id)?.isClaimed ?? false,
            })),
        }));
        setPartners(mappedPartners);
      }

      // Load quests with user progress
      const { data: questsData } = await supabase
        .from("quests")
        .select("*")
        .eq("is_active", true)
        .order("node_number");

      if (questsData) {
        const { data: userQuests } = await supabase
          .from("user_quests")
          .select("*")
          .eq("user_id", auth.user.id);

        const questProgressMap = new Map<string, { progress: number; status: string }>();
        userQuests?.forEach(uq => {
          questProgressMap.set(uq.quest_id, { progress: uq.progress, status: uq.status });
        });

        const mappedQuests: Quest[] = questsData.map((q: any) => {
          const uq = questProgressMap.get(q.id);
          return {
            id: q.id,
            title: q.title,
            description: q.description,
            type: q.type,
            reward: q.reward,
            progress: uq?.progress ?? 0,
            maxProgress: q.max_progress,
            deadline: q.deadline,
            status: (uq?.status as Quest["status"]) ?? "active",
            partnerId: q.partner_id,
            nodeNumber: q.node_number,
            isRewardNode: q.is_reward_node,
            category: q.category,
          };
        });
        setQuests(mappedQuests);
      }

      // Load user profile
      const { data: userData } = await supabase
        .from("users")
        .select("*")
        .eq("id", auth.user.id)
        .single();

      if (userData) {
        // Load partner balances
        const { data: balances } = await supabase
          .from("partner_balances")
          .select("*")
          .eq("user_id", auth.user.id);

        const partnerBalances: Record<string, number> = {};
        balances?.forEach(b => { partnerBalances[b.partner_id] = b.balance; });

        // Load challenges
        const { data: challengesData } = await supabase
          .from("challenges")
          .select("*")
          .eq("is_active", true);

        const { data: userChallenges } = await supabase
          .from("user_challenges")
          .select("*")
          .eq("user_id", auth.user.id);

        const challengeProgressMap = new Map<string, number>();
        userChallenges?.forEach(uc => challengeProgressMap.set(uc.challenge_id, uc.progress));

        const challenges: Challenge[] = (challengesData || []).map((c: any) => ({
          id: c.id,
          title: c.title,
          progress: challengeProgressMap.get(c.id) ?? 0,
          maxProgress: c.max_progress,
          reward: c.reward,
          deadline: c.deadline,
          isNew: c.is_new,
        }));

        setUser({
          username: userData.username,
          level: userData.level,
          levelProgress: userData.level_progress,
          levelMax: userData.level_max,
          balance: userData.balance,
          todayEarned: userData.today_earned,
          streak: userData.streak,
          streakAtRisk: userData.streak_at_risk,
          mojiCreated: userData.moji_created,
          mojiConfig: userData.moji_config || { hair: 0, glasses: 0, accessory: 0, outfit: 0 },
          favorites: userData.favorites || [],
          leaderboardJoined: userData.leaderboard_joined,
          challenges,
          supportedPartner: userData.supported_partner_id ? {
            partnerId: userData.supported_partner_id,
            since: userData.supported_since,
            bonusEarned: userData.supporter_bonus_earned || 0,
          } : null,
          lastSupporterBonusDate: userData.last_supporter_bonus_date,
          duelCount: userData.duel_count,
          blindBoxAvailable: userData.blind_box_available,
          lastScratchDate: userData.last_scratch_date,
          socialFollowed: userData.social_followed || [],
          reviewedPartners: userData.reviewed_partners || [],
          visitedPartnerIds: userData.visited_partner_ids || [],
          partnerBalances,
        });
      }

      // Load transactions
      const { data: txData } = await supabase
        .from("transactions")
        .select("*")
        .eq("user_id", auth.user.id)
        .order("created_at", { ascending: false })
        .limit(50);

      if (txData) {
        setTransactions(txData.map((t: any) => ({
          id: t.id,
          type: t.type,
          amount: t.amount,
          description: t.description,
          timestamp: t.created_at,
          status: t.status,
        })));
      }
    } catch (err) {
      console.error("Error loading data from Supabase:", err);
    }
    setIsLoading(false);
  }, [useSupabase, auth.user]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Supabase realtime subscription for partners
  useEffect(() => {
    if (!useSupabase) return;
    const channel = supabase
      .channel("realtime-partners")
      .on("postgres_changes", { event: "*", schema: "public", table: "partners" }, () => {
        refreshData();
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [useSupabase, refreshData]);

  // --- All action functions (work with both mock and Supabase) ---

  const syncUserToSupabase = async (updates: Partial<Record<string, any>>) => {
    if (!useSupabase || !auth.user) return;
    await supabase.from("users").update(updates).eq("id", auth.user.id);
  };

  const addTransaction = async (type: Transaction["type"], amount: number, description: string) => {
    if (!useSupabase || !auth.user) return;
    await supabase.from("transactions").insert({
      user_id: auth.user.id,
      type,
      amount,
      description,
      status: "completed",
    });
  };

  const addCoins = (amount: number, description: string, type: Transaction["type"] = "earn") => {
    const newTransaction: Transaction = {
      id: `t${Date.now()}`,
      type,
      amount,
      description,
      timestamp: new Date().toISOString(),
      status: "completed"
    };
    setTransactions(prev => [newTransaction, ...prev]);
    setUser(prev => {
      const newBalance = prev.balance + amount;
      const newTodayEarned = prev.todayEarned + amount;
      syncUserToSupabase({ balance: newBalance, today_earned: newTodayEarned });
      return { ...prev, balance: newBalance, todayEarned: newTodayEarned };
    });
    addTransaction(type, amount, description);
  };

  const spendCoins = (amount: number, description: string) => {
    const newTransaction: Transaction = {
      id: `t${Date.now()}`,
      type: "spend",
      amount,
      description,
      timestamp: new Date().toISOString(),
      status: "completed"
    };
    setTransactions(prev => [newTransaction, ...prev]);
    setUser(prev => {
      const newBalance = prev.balance - amount;
      syncUserToSupabase({ balance: newBalance });
      return { ...prev, balance: newBalance };
    });
    addTransaction("spend", amount, description);
  };

  const addPartnerCoins = (partnerId: string, amount: number, description: string) => {
    const partner = partners.find(p => p.id === partnerId);
    const newTransaction: Transaction = {
      id: `t${Date.now()}`,
      type: "earn",
      amount,
      description: `${description} (${partner?.name || partnerId})`,
      timestamp: new Date().toISOString(),
      status: "completed"
    };
    setTransactions(prev => [newTransaction, ...prev]);
    setUser(prev => {
      const newBalance = (prev.partnerBalances[partnerId] || 0) + amount;
      const newPartnerBalances = { ...prev.partnerBalances, [partnerId]: newBalance };

      if (useSupabase && auth.user) {
        supabase.from("partner_balances")
          .upsert({ user_id: auth.user.id, partner_id: partnerId, balance: newBalance }, { onConflict: "user_id,partner_id" });
      }

      return { ...prev, partnerBalances: newPartnerBalances };
    });
    addTransaction("earn", amount, `${description} (${partner?.name || partnerId})`);
  };

  const toggleFavorite = (partnerId: string) => {
    setUser(prev => {
      const newFavorites = prev.favorites.includes(partnerId)
        ? prev.favorites.filter(id => id !== partnerId)
        : [...prev.favorites, partnerId];
      syncUserToSupabase({ favorites: newFavorites });
      return { ...prev, favorites: newFavorites };
    });
  };

  const updateMoji = (config: UserState["mojiConfig"]) => {
    setUser(prev => {
      const alreadyCreated = prev.mojiCreated;
      if (!alreadyCreated) {
        setTimeout(() => addCoins(COIN_CONFIG.MOJI_CREATION, "ChemnitzMoji erstellt! 🎨"), 100);
      }
      syncUserToSupabase({ moji_created: true, moji_config: config });
      return { ...prev, mojiCreated: true, mojiConfig: config };
    });
  };

  const joinLeaderboard = () => {
    setUser(prev => {
      syncUserToSupabase({ leaderboard_joined: true });
      return { ...prev, leaderboardJoined: true };
    });
  };

  const unlockReward = (partnerId: string, tierId: string) => {
    setPartners(prev => prev.map(p => {
      if (p.id === partnerId) {
        return {
          ...p,
          tiers: p.tiers.map(t => {
            if (t.id === tierId) {
              if (t.unlockMethod === "coins" && t.coinCost) {
                const partnerBalance = user.partnerBalances[partnerId] || 0;
                const cost = t.coinCost;

                if (partnerBalance >= cost) {
                  const newBal = partnerBalance - cost;
                  setUser(prev => ({
                    ...prev,
                    partnerBalances: { ...prev.partnerBalances, [partnerId]: newBal }
                  }));
                  if (useSupabase && auth.user) {
                    supabase.from("partner_balances")
                      .upsert({ user_id: auth.user.id, partner_id: partnerId, balance: newBal }, { onConflict: "user_id,partner_id" });
                  }
                } else {
                  const remaining = cost - partnerBalance;
                  setUser(prev => ({
                    ...prev,
                    balance: prev.balance - remaining,
                    partnerBalances: { ...prev.partnerBalances, [partnerId]: 0 }
                  }));
                  if (useSupabase && auth.user) {
                    syncUserToSupabase({ balance: user.balance - remaining });
                    supabase.from("partner_balances")
                      .upsert({ user_id: auth.user.id, partner_id: partnerId, balance: 0 }, { onConflict: "user_id,partner_id" });
                  }
                }

                addTransaction("spend", cost, `${p.name} Reward freigeschaltet`);
                const newTx: Transaction = {
                  id: `t${Date.now()}`,
                  type: "spend",
                  amount: cost,
                  description: `${p.name} Reward freigeschaltet`,
                  timestamp: new Date().toISOString(),
                  status: "completed"
                };
                setTransactions(prev => [newTx, ...prev]);
              }

              // Save to Supabase
              if (useSupabase && auth.user) {
                supabase.from("user_rewards").upsert({
                  user_id: auth.user.id,
                  tier_id: tierId,
                  partner_id: partnerId,
                  is_unlocked: true,
                  is_claimed: false,
                }, { onConflict: "user_id,tier_id" });
              }

              return { ...t, isUnlocked: true };
            }
            return t;
          })
        };
      }
      return p;
    }));
  };

  const claimReward = (partnerId: string, tierId: string) => {
    setPartners(prev => prev.map(p => {
      if (p.id === partnerId) {
        return {
          ...p,
          tiers: p.tiers.map(t => {
            if (t.id === tierId) {
              if (useSupabase && auth.user) {
                supabase.from("user_rewards")
                  .update({ is_claimed: true, claimed_at: new Date().toISOString() })
                  .eq("user_id", auth.user.id)
                  .eq("tier_id", tierId);
              }
              return { ...t, isClaimed: true };
            }
            return t;
          })
        };
      }
      return p;
    }));
  };

  const checkIn = (partnerId: string) => {
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;

    let amount = Math.floor(Math.random() * (COIN_CONFIG.CHECK_IN_MAX - COIN_CONFIG.CHECK_IN_MIN + 1)) + COIN_CONFIG.CHECK_IN_MIN;
    const isLucky = Math.random() < COIN_CONFIG.LUCKY_CHANCE;
    if (isLucky) {
      amount += COIN_CONFIG.LUCKY_BONUS;
      addCoins(amount, `Glücksmoment @ ${partner.name}! 🍀`);
    } else {
      addCoins(amount, `Check-in @ ${partner.name} 🏪`);
    }

    setPartners(prev => prev.map(p =>
      p.id === partnerId ? { ...p, visitorCount: p.visitorCount + 1 } : p
    ));

    if (useSupabase) {
      supabase.from("partners").update({ visitor_count: partner.visitorCount + 1 }).eq("id", partnerId);
    }

    setUser(prev => {
      const newVisited = prev.visitedPartnerIds.includes(partnerId)
        ? prev.visitedPartnerIds
        : [...prev.visitedPartnerIds, partnerId];
      syncUserToSupabase({ visited_partner_ids: newVisited });
      return { ...prev, visitedPartnerIds: newVisited };
    });
  };

  const submitStory = (partnerId: string, instagram: string) => {
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;
    addPartnerCoins(partnerId, COIN_CONFIG.STORY_POST, `Story Bonus @ ${partner.name} 📸`);
  };

  const sharePartnerPost = (partnerId: string) => {
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;
    addPartnerCoins(partnerId, COIN_CONFIG.SHARE_POST, `Post geteilt @ ${partner.name} 📢`);
  };

  const followPartnerSocial = (partnerId: string) => {
    if (user.socialFollowed.includes(partnerId)) return;
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;

    setUser(prev => {
      const newFollowed = [...prev.socialFollowed, partnerId];
      syncUserToSupabase({ social_followed: newFollowed });
      return { ...prev, socialFollowed: newFollowed };
    });
    addPartnerCoins(partnerId, COIN_CONFIG.SOCIAL_FOLLOW, `Social Follow @ ${partner.name} 👤`);
  };

  const submitGoogleReview = (partnerId: string) => {
    if (user.reviewedPartners.includes(partnerId)) return;
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;

    setUser(prev => {
      const newReviewed = [...prev.reviewedPartners, partnerId];
      syncUserToSupabase({ reviewed_partners: newReviewed });
      return { ...prev, reviewedPartners: newReviewed };
    });
    addPartnerCoins(partnerId, COIN_CONFIG.GOOGLE_REVIEW, `Google Review @ ${partner.name} ⭐`);
  };

  const claimDailyScratch = () => {
    const today = new Date().toISOString().split('T')[0];
    if (user.lastScratchDate === today) return;

    const amount = Math.floor(Math.random() * (COIN_CONFIG.SCRATCH_MAX - COIN_CONFIG.SCRATCH_MIN + 1)) + COIN_CONFIG.SCRATCH_MIN;
    setUser(prev => {
      syncUserToSupabase({ last_scratch_date: today });
      return { ...prev, lastScratchDate: today };
    });
    addCoins(amount, `Tägliches Rubbellos 🎫`);
  };

  const supportPartner = (partnerId: string) => {
    const partner = partners.find(p => p.id === partnerId);
    if (!partner) return;
    const now = new Date().toISOString();

    setUser(prev => {
      syncUserToSupabase({
        supported_partner_id: partnerId,
        supported_since: now,
        supporter_bonus_earned: 0,
      });
      return {
        ...prev,
        supportedPartner: { partnerId, since: now, bonusEarned: 0 }
      };
    });
  };

  const unsupportPartner = () => {
    setUser(prev => {
      syncUserToSupabase({
        supported_partner_id: null,
        supported_since: null,
        supporter_bonus_earned: 0,
      });
      return { ...prev, supportedPartner: null };
    });
  };

  const claimSupporterBonus = () => {
    if (!user.supportedPartner) return;
    const today = new Date().toISOString().split('T')[0];
    if (user.lastSupporterBonusDate === today) return;

    const partner = partners.find(p => p.id === user.supportedPartner?.partnerId);
    if (!partner) return;

    if (partner.visitorCount % 3 === 0) {
      const amount = Math.floor(Math.random() * (COIN_CONFIG.SUPPORTER_BONUS_MAX - COIN_CONFIG.SUPPORTER_BONUS_MIN + 1)) + COIN_CONFIG.SUPPORTER_BONUS_MIN;
      setUser(prev => {
        const newBonusEarned = (prev.supportedPartner?.bonusEarned || 0) + amount;
        syncUserToSupabase({
          last_supporter_bonus_date: today,
          supporter_bonus_earned: newBonusEarned,
        });
        return {
          ...prev,
          lastSupporterBonusDate: today,
          supportedPartner: prev.supportedPartner ? {
            ...prev.supportedPartner,
            bonusEarned: newBonusEarned
          } : null
        };
      });
      addCoins(amount, `Supporter Bonus @ ${partner.name} ⚡`);
    }
  };

  const incrementDuelCount = () => {
    setUser(prev => {
      const newCount = prev.duelCount + 1;
      const blindBox = newCount % 5 === 0 ? true : prev.blindBoxAvailable;
      syncUserToSupabase({ duel_count: newCount, blind_box_available: blindBox });
      return { ...prev, duelCount: newCount, blindBoxAvailable: blindBox };
    });
  };

  const openBlindBox = () => {
    if (!user.blindBoxAvailable) return;

    const visitedPartnerIds = transactions
      .filter(t => t.description.includes("@"))
      .map(t => {
        const match = t.description.match(/@ (.*?)(?: \(|$)/);
        return match ? match[1] : null;
      })
      .filter(Boolean);

    const availablePartners = partners.filter(p => !visitedPartnerIds.includes(p.name));
    const targetPartner = availablePartners.length > 0
      ? availablePartners[Math.floor(Math.random() * availablePartners.length)]
      : partners[Math.floor(Math.random() * partners.length)];

    setPartners(prev => prev.map(p => {
      if (p.id === targetPartner.id) {
        return {
          ...p,
          tiers: p.tiers.map(t => t.type === "basis" ? { ...t, isUnlocked: true } : t)
        };
      }
      return p;
    }));

    setUser(prev => {
      syncUserToSupabase({ blind_box_available: false });
      return { ...prev, blindBoxAvailable: false };
    });
    addCoins(COIN_CONFIG.BLIND_BOX, `Blind Box geöffnet! 🎁 (${targetPartner.name})`);
  };

  const completeQuest = (questId: string) => {
    const quest = quests.find(q => q.id === questId);
    if (!quest || quest.status === "completed") return;

    setQuests(prev => prev.map(q =>
      q.id === questId ? { ...q, status: "completed", progress: q.maxProgress } : q
    ));

    if (useSupabase && auth.user) {
      supabase.from("user_quests").upsert({
        user_id: auth.user.id,
        quest_id: questId,
        progress: quest.maxProgress,
        status: "completed",
        completed_at: new Date().toISOString(),
      }, { onConflict: "user_id,quest_id" });
    }

    addCoins(quest.reward, `Quest abgeschlossen: ${quest.title} 🏆`);

    setUser(prev => {
      const newLevelProgress = prev.levelProgress + 1;
      if (newLevelProgress >= prev.levelMax) {
        const updates = {
          level: prev.level + 1,
          level_progress: 0,
          level_max: prev.levelMax + 4,
        };
        syncUserToSupabase(updates);
        return { ...prev, level: prev.level + 1, levelProgress: 0, levelMax: prev.levelMax + 4 };
      }
      syncUserToSupabase({ level_progress: newLevelProgress });
      return { ...prev, levelProgress: newLevelProgress };
    });
  };

  return (
    <UserContext.Provider value={{
      user,
      quests,
      partners,
      transactions,
      isLoading,
      addCoins,
      spendCoins,
      toggleFavorite,
      updateMoji,
      joinLeaderboard,
      claimReward,
      unlockReward,
      checkIn,
      submitStory,
      completeQuest,
      sharePartnerPost,
      followPartnerSocial,
      submitGoogleReview,
      claimDailyScratch,
      supportPartner,
      unsupportPartner,
      claimSupporterBonus,
      openBlindBox,
      incrementDuelCount,
      addPartnerCoins,
      refreshData,
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) throw new Error("useUser must be used within UserProvider");
  return context;
};
