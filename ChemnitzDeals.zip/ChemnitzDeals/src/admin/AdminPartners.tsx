import React, { useState } from "react";
import { Plus, Pencil, Trash2, X, Save, Store } from "lucide-react";
import { Partner, Category, RewardTier } from "../types";
import { MOCK_PARTNERS, CATEGORIES } from "../constants";

const emptyTier = (partnerId: string, index: number): RewardTier => ({
  id: `${partnerId}-t${Date.now()}-${index}`,
  title: "",
  description: "",
  type: "basis",
  unlockMethod: "none",
  isUnlocked: true,
  isClaimed: false,
});

const AdminPartners: React.FC = () => {
  const [partners, setPartners] = useState<Partner[]>([...MOCK_PARTNERS]);
  const [editingPartner, setEditingPartner] = useState<Partner | null>(null);
  const [isNew, setIsNew] = useState(false);

  const openNew = () => {
    const id = `p${Date.now()}`;
    setEditingPartner({
      id,
      name: "",
      category: "food",
      location: "",
      coordinates: { lat: 50.83, lng: 12.92 },
      image: "",
      description: "",
      rating: 4.5,
      visitorCount: 0,
      instagram: "",
      briefFacts: [],
      tiers: [emptyTier(id, 0)],
    });
    setIsNew(true);
  };

  const openEdit = (p: Partner) => {
    setEditingPartner({ ...p, tiers: p.tiers.map(t => ({ ...t })) });
    setIsNew(false);
  };

  const handleSave = () => {
    if (!editingPartner || !editingPartner.name.trim()) return;
    if (isNew) {
      setPartners(prev => [...prev, editingPartner]);
    } else {
      setPartners(prev => prev.map(p => p.id === editingPartner.id ? editingPartner : p));
    }
    setEditingPartner(null);
  };

  const handleDelete = (id: string) => {
    if (!confirm("Partner wirklich löschen?")) return;
    setPartners(prev => prev.filter(p => p.id !== id));
  };

  const updateField = (field: keyof Partner, value: any) => {
    setEditingPartner(prev => prev ? { ...prev, [field]: value } : null);
  };

  const updateTier = (index: number, field: keyof RewardTier, value: any) => {
    if (!editingPartner) return;
    const tiers = [...editingPartner.tiers];
    tiers[index] = { ...tiers[index], [field]: value };
    setEditingPartner({ ...editingPartner, tiers });
  };

  const addTier = () => {
    if (!editingPartner) return;
    setEditingPartner({
      ...editingPartner,
      tiers: [...editingPartner.tiers, emptyTier(editingPartner.id, editingPartner.tiers.length)],
    });
  };

  const removeTier = (index: number) => {
    if (!editingPartner) return;
    setEditingPartner({
      ...editingPartner,
      tiers: editingPartner.tiers.filter((_, i) => i !== index),
    });
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Partner-Verwaltung</h1>
          <p className="text-sm text-gray-500 mt-1">{partners.length} Partner registriert</p>
        </div>
        <button onClick={openNew} className="flex items-center gap-2 px-4 py-2.5 bg-[#E63946] text-white rounded-xl font-bold text-sm shadow-lg shadow-red-500/20">
          <Plus size={18} />
          Neuer Partner
        </button>
      </div>

      {/* Partner List */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Name</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Kategorie</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Adresse</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden lg:table-cell">Instagram</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Gutscheine</th>
              <th className="text-right px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Aktionen</th>
            </tr>
          </thead>
          <tbody>
            {partners.map(p => (
              <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-3">
                  <p className="text-sm font-bold">{p.name}</p>
                </td>
                <td className="px-4 py-3 hidden md:table-cell">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-600 capitalize">{p.category}</span>
                </td>
                <td className="px-4 py-3 text-xs text-gray-500 hidden md:table-cell">{p.location}</td>
                <td className="px-4 py-3 text-xs text-blue-500 hidden lg:table-cell">@{p.instagram}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-col gap-0.5">
                    {p.tiers.map(t => (
                      <span key={t.id} className="text-[10px] text-gray-600">
                        {t.type === "premium" ? "🎁" : "✅"} {t.title}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <button onClick={() => openEdit(p)} className="p-1.5 hover:bg-blue-50 text-blue-500 rounded-lg">
                      <Pencil size={14} />
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="p-1.5 hover:bg-red-50 text-red-500 rounded-lg">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit/Create Modal */}
      {editingPartner && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-5 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10 rounded-t-2xl">
              <h2 className="text-lg font-black">{isNew ? "Neuer Partner" : "Partner bearbeiten"}</h2>
              <button onClick={() => setEditingPartner(null)} className="p-2 hover:bg-gray-100 rounded-lg"><X size={18} /></button>
            </div>

            <div className="p-5 flex flex-col gap-4">
              {/* Basic Info */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-gray-500 uppercase">Name *</label>
                  <input value={editingPartner.name} onChange={e => updateField("name", e.target.value)}
                    className="w-full mt-1 p-2.5 border rounded-xl text-sm" placeholder="z.B. Döner Palace" />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-500 uppercase">Kategorie</label>
                  <select value={editingPartner.category} onChange={e => updateField("category", e.target.value as Category)}
                    className="w-full mt-1 p-2.5 border rounded-xl text-sm">
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-500 uppercase">Adresse</label>
                  <input value={editingPartner.location} onChange={e => updateField("location", e.target.value)}
                    className="w-full mt-1 p-2.5 border rounded-xl text-sm" placeholder="Straße, Chemnitz" />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-500 uppercase">Instagram</label>
                  <input value={editingPartner.instagram} onChange={e => updateField("instagram", e.target.value)}
                    className="w-full mt-1 p-2.5 border rounded-xl text-sm" placeholder="username" />
                </div>
                <div className="col-span-2">
                  <label className="text-xs font-bold text-gray-500 uppercase">Beschreibung</label>
                  <textarea value={editingPartner.description} onChange={e => updateField("description", e.target.value)}
                    rows={2} className="w-full mt-1 p-2.5 border rounded-xl text-sm resize-none" />
                </div>
              </div>

              {/* Reward Tiers */}
              <div className="border-t pt-4 mt-2">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-black uppercase tracking-widest text-gray-700">Gutscheine / Rewards</h3>
                  <button onClick={addTier} className="text-[#E63946] text-xs font-bold flex items-center gap-1">
                    <Plus size={12} /> Tier hinzufügen
                  </button>
                </div>
                <div className="space-y-3">
                  {editingPartner.tiers.map((tier, i) => (
                    <div key={i} className="border rounded-xl p-3 bg-gray-50">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-bold text-gray-400 uppercase">
                          Tier {i + 1} — {tier.type === "premium" ? "🎁 Premium" : "✅ Basis"}
                        </span>
                        {editingPartner.tiers.length > 1 && (
                          <button onClick={() => removeTier(i)} className="text-red-400 hover:text-red-600">
                            <Trash2 size={12} />
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <input value={tier.title} onChange={e => updateTier(i, "title", e.target.value)}
                          className="p-2 border rounded-lg text-sm" placeholder="z.B. Döner für 1€" />
                        <select value={tier.type} onChange={e => updateTier(i, "type", e.target.value)}
                          className="p-2 border rounded-lg text-sm">
                          <option value="basis">Basis (gratis)</option>
                          <option value="premium">Premium</option>
                        </select>
                        <input value={tier.description} onChange={e => updateTier(i, "description", e.target.value)}
                          className="p-2 border rounded-lg text-sm col-span-2" placeholder="Beschreibung / Bedingung" />
                        {tier.type === "premium" && (
                          <select value={tier.unlockMethod} onChange={e => updateTier(i, "unlockMethod", e.target.value)}
                            className="p-2 border rounded-lg text-sm col-span-2">
                            <option value="story">Story + Bewertung</option>
                            <option value="coins">Coins bezahlen</option>
                            <option value="none">Keine Bedingung</option>
                          </select>
                        )}
                        {tier.type === "premium" && tier.unlockMethod === "coins" && (
                          <div className="col-span-2">
                            <input type="number" value={tier.coinCost || 0} onChange={e => updateTier(i, "coinCost", Number(e.target.value))}
                              className="p-2 border rounded-lg text-sm w-full" placeholder="Coin-Kosten" />
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-4 border-t">
                <button onClick={() => setEditingPartner(null)} className="flex-1 py-2.5 border rounded-xl font-bold text-sm">Abbrechen</button>
                <button onClick={handleSave} disabled={!editingPartner.name.trim()} className="flex-1 py-2.5 bg-[#E63946] text-white rounded-xl font-bold text-sm shadow-lg disabled:opacity-50 flex items-center justify-center gap-2">
                  <Save size={14} /> Speichern
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPartners;
