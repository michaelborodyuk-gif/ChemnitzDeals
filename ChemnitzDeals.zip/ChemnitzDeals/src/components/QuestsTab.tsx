import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Gift,
  Lock,
  ChevronLeft,
  Backpack,
  Map as MapIcon,
  List,
  Clock,
  Users,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Footprints,
  Star,
  ChevronRight,
  X
} from "lucide-react";
import { useUser } from "../context/UserContext";
import { useLanguage } from "../context/LanguageContext";
import { LevelDefinition, LevelChallenge } from "../types";
import { MOCK_LEVELS } from "../constants";
import KarlMarxCoin from "./KarlMarxCoin";
import InventoryModal from "./InventoryModal";

const QuestsTab: React.FC = () => {
  const { user, quests } = useUser();
  const { t } = useLanguage();
  const [viewMode, setViewMode] = useState<"map" | "grid">("map");
  const [selectedQuestId, setSelectedQuestId] = useState<string | null>(null);
  const [showInventory, setShowInventory] = useState(false);
  const [coinPower, setCoinPower] = useState(20);

  // Level Challenge Popup
  const [selectedLevel, setSelectedLevel] = useState<LevelDefinition | null>(null);
  const [selectedChallenge, setSelectedChallenge] = useState<LevelChallenge | null>(null);
  const levels = MOCK_LEVELS;

  const selectedQuest = quests.find(q => q.id === selectedQuestId);

  const renderCityscape = () => (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {/* Sky */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FFFBEB] to-[#FEF3C7]" />
      
      {/* Skyline Silhouette */}
      <svg className="absolute bottom-[40%] w-full h-40 text-gray-800/10" viewBox="0 0 1000 200" preserveAspectRatio="none">
        <path d="M0,200 L0,150 L50,150 L50,100 L80,100 L80,150 L120,150 L120,80 L160,80 L160,150 L200,150 L200,120 L250,120 L250,150 L300,150 L300,50 L340,50 L340,150 L400,150 L400,90 L450,90 L450,150 L500,150 L500,110 L550,110 L550,150 L600,150 L600,40 L650,40 L650,150 L700,150 L700,80 L750,80 L750,150 L800,150 L800,100 L850,100 L850,150 L900,150 L900,60 L950,60 L950,150 L1000,150 L1000,200 Z" fill="currentColor" />
        {/* Roter Turm Silhouette */}
        <rect x="310" y="30" width="20" height="120" fill="currentColor" />
        <path d="M305,30 L335,30 L320,10 Z" fill="currentColor" />
        {/* Karl Marx Monument Silhouette */}
        <circle cx="625" cy="30" r="15" fill="currentColor" />
        <rect x="615" y="45" width="20" height="105" fill="currentColor" />
      </svg>

      {/* Ground */}
      <div className="absolute bottom-0 w-full h-[40%] bg-[#2D5A27]" />

      {/* Trees */}
      {[...Array(8)].map((_, i) => (
        <div 
          key={i} 
          className="absolute bottom-[38%] text-[#1E3D1A]"
          style={{ left: `${i * 15 + 5}%`, transform: `scale(${0.8 + Math.random() * 0.5})` }}
        >
          <svg width="40" height="60" viewBox="0 0 40 60">
            <path d="M20,0 L40,40 L30,40 L35,60 L5,60 L10,40 L0,40 Z" fill="currentColor" />
          </svg>
        </div>
      ))}
    </div>
  );

  const renderNodeMap = () => {
    const sortedQuests = [...quests].sort((a, b) => (a.nodeNumber || 0) - (b.nodeNumber || 0));
    
    return (
      <div className="relative flex flex-col items-center py-20 gap-12 min-h-[800px]">
        {/* Connection Lines */}
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          {sortedQuests.map((q, i) => {
            if (i === sortedQuests.length - 1) return null;
            const nextQ = sortedQuests[i + 1];
            return (
              <line 
                key={`line-${q.id}`}
                x1="50%" y1={`${120 + i * 100}px`}
                x2="50%" y2={`${120 + (i + 1) * 100}px`}
                stroke="#E5E7EB"
                strokeWidth="4"
                strokeDasharray="8 8"
              />
            );
          })}
        </svg>

        {/* Treasure Chest at Top */}
        <motion.div 
          initial={{ y: 0 }}
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="mb-8"
        >
          <div className="w-24 h-24 bg-gradient-to-br from-amber-400 to-amber-600 rounded-3xl flex items-center justify-center shadow-2xl border-4 border-white">
            <Gift size={48} className="text-white" />
          </div>
        </motion.div>

        {/* Nodes (Reversed for bottom-up feel) */}
        {[...sortedQuests].reverse().map((quest) => {
          const isActive = quest.status === "active";
          const isLocked = quest.status === "locked";
          const isCompleted = quest.status === "completed";

          return (
            <motion.button
              key={quest.id}
              whileTap={{ scale: 0.9 }}
              onClick={() => setSelectedQuestId(quest.id)}
              className="relative z-10"
            >
              <div className={`
                ${isActive ? "w-20 h-20 bg-[#E63946] shadow-lg shadow-red-500/30" : "w-14 h-14 bg-white border-4 border-gray-200"}
                rounded-full flex items-center justify-center transition-all duration-300
              `}>
                {isCompleted ? (
                  <CheckCircle2 size={isActive ? 32 : 24} className={isActive ? "text-white" : "text-green-500"} />
                ) : isLocked ? (
                  <Lock size={24} className="text-gray-300" />
                ) : (
                  <span className={`text-xl font-black ${isActive ? "text-white" : "text-gray-400"}`}>
                    {quest.nodeNumber}
                  </span>
                )}
              </div>

              {/* Reward Badge */}
              {quest.isRewardNode && (
                <div className="absolute -top-2 -right-2 w-8 h-8 bg-[#F59E0B] rounded-full border-2 border-white flex items-center justify-center shadow-md">
                  <Gift size={14} className="text-white" />
                </div>
              )}
            </motion.button>
          );
        })}
      </div>
    );
  };

  const renderGridView = () => {
    const categories = [
      { id: "check-in", color: "bg-green-100", textColor: "text-green-600", emoji: "📍" },
      { id: "story", color: "bg-pink-100", textColor: "text-pink-600", emoji: "📸" },
      { id: "community", color: "bg-purple-100", textColor: "text-purple-600", emoji: "👥" },
      { id: "discovery", color: "bg-yellow-100", textColor: "text-yellow-600", emoji: "✨" }
    ];

    return (
      <div className="grid grid-cols-2 gap-4 p-6">
        {quests.map((quest) => {
          const cat = categories.find(c => c.id === quest.category) || categories[0];
          return (
            <motion.div
              key={quest.id}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelectedQuestId(quest.id)}
              className="bg-white rounded-3xl overflow-hidden border border-border shadow-sm flex flex-col"
            >
              <div className={`h-24 ${cat.color} flex items-center justify-center relative`}>
                <span className="text-4xl">{cat.emoji}</span>
                <div className="absolute top-2 left-2 bg-white/80 backdrop-blur-sm px-2 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest">
                  {quest.type === "visit" ? "Täglich" : "Wöchentlich"}
                </div>
              </div>
              <div className="p-4 flex flex-col gap-3 flex-1">
                <h3 className="text-xs font-black text-text-primary leading-tight line-clamp-2">
                  {quest.title}
                </h3>
                <div className="mt-auto flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-black text-[#F59E0B]">+{quest.reward}</span>
                    <KarlMarxCoin size={14} />
                  </div>
                  <div className="w-6 h-6 rounded-full bg-pink-500 flex items-center justify-center text-white">
                    <ArrowRight size={12} />
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="flex flex-col min-h-full bg-white relative">
      {/* Top Bar */}
      <div className="fixed top-16 left-0 right-0 h-14 bg-white/80 backdrop-blur-md border-b border-border z-40 px-4 flex items-center justify-between">
        <button className="flex items-center gap-1 text-xs font-black text-text-secondary uppercase tracking-widest">
          <ChevronLeft size={16} />
          {t("zurueck")}
        </button>

        <div className="flex flex-col items-center">
          <span className="text-[10px] font-black text-text-primary uppercase tracking-widest">
            Level {user.level} · {user.levelProgress}/{user.levelMax}
          </span>
          <div className="w-24 h-1.5 bg-secondary rounded-full overflow-hidden mt-0.5">
            <div 
              className="h-full bg-[#E63946]" 
              style={{ width: `${(user.levelProgress / user.levelMax) * 100}%` }} 
            />
          </div>
        </div>

        <button onClick={() => setShowInventory(true)} className="flex flex-col items-center gap-0.5">
          <div className="w-8 h-8 rounded-full bg-amber-50 flex items-center justify-center text-[#F59E0B] border border-amber-100">
            <Backpack size={16} />
          </div>
          <span className="text-[8px] font-black text-text-secondary uppercase tracking-widest">
            {t("inventar")}
          </span>
        </button>
      </div>

      {/* View Toggle */}
      <div className="mt-14 px-6 pt-6 flex justify-center">
        <div className="bg-secondary p-1 rounded-2xl flex gap-1 border border-border">
          <button 
            onClick={() => setViewMode("map")}
            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
              viewMode === "map" ? "bg-white text-text-primary shadow-sm" : "text-text-secondary"
            }`}
          >
            {t("karte")}
          </button>
          <button
            onClick={() => setViewMode("grid")}
            className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
              viewMode === "grid" ? "bg-white text-text-primary shadow-sm" : "text-text-secondary"
            }`}
          >
            {t("liste")}
          </button>
        </div>
      </div>

      {/* Level Buttons — horizontal scroll */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {levels.map(lvl => {
            const completedCount = lvl.challenges.filter(c => c.status === "completed").length;
            const isLocked = user.level < lvl.requiredLevel;
            return (
              <motion.button
                key={lvl.level}
                whileTap={{ scale: 0.95 }}
                onClick={() => !isLocked && setSelectedLevel(lvl)}
                className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-2xl border transition-all ${
                  isLocked
                    ? "bg-gray-100 border-gray-200 opacity-60"
                    : "bg-white border-gray-200 shadow-sm active:shadow-none"
                }`}
              >
                <span className="text-xl">{lvl.icon}</span>
                <div className="text-left">
                  <p className="text-[10px] font-black uppercase tracking-wider text-gray-800">
                    Lv.{lvl.level} {lvl.title}
                  </p>
                  <p className="text-[9px] text-gray-500">
                    {isLocked ? (
                      <span className="flex items-center gap-0.5"><Lock size={8} /> Ab Level {lvl.requiredLevel}</span>
                    ) : (
                      `${completedCount}/${lvl.challenges.length}`
                    )}
                  </p>
                </div>
                {!isLocked && <ChevronRight size={14} className="text-gray-400 ml-1" />}
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 relative">
        {viewMode === "map" ? (
          <>
            {renderCityscape()}
            <div className="relative z-10">
              {renderNodeMap()}
            </div>
          </>
        ) : (
          renderGridView()
        )}
      </div>

      {/* ========== Level Challenge Popup ========== */}
      <AnimatePresence>
        {selectedLevel && !selectedChallenge && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedLevel(null)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[32px] z-[70] px-5 pt-2 pb-8 shadow-2xl max-h-[80vh] overflow-y-auto"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-4" />

              {/* Level Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className="w-14 h-14 bg-yellow-100 rounded-2xl flex items-center justify-center text-3xl">
                  {selectedLevel.icon}
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-black">Level {selectedLevel.level}: {selectedLevel.title}</h2>
                  <p className="text-xs text-gray-500">{selectedLevel.description}</p>
                </div>
                <button onClick={() => setSelectedLevel(null)} className="p-2 hover:bg-gray-100 rounded-full">
                  <X size={18} />
                </button>
              </div>

              {/* CoinPower mini-bar */}
              <div className="bg-gradient-to-r from-yellow-100 to-yellow-200 rounded-xl p-3 mb-4 flex items-center gap-2">
                <Sparkles size={16} className="text-yellow-600" />
                <span className="text-xs font-bold text-yellow-800">CoinPower: {coinPower}</span>
                <div className="flex-1 h-1.5 bg-yellow-300/50 rounded-full overflow-hidden">
                  <div className="h-full bg-yellow-500 rounded-full" style={{ width: `${coinPower}%` }} />
                </div>
              </div>

              {/* 2-Column Challenge Grid */}
              <div className="grid grid-cols-2 gap-3">
                {selectedLevel.challenges.map(ch => (
                  <motion.button
                    key={ch.id}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => setSelectedChallenge(ch)}
                    className={`relative rounded-2xl p-3 border text-left transition-all ${
                      ch.status === "completed"
                        ? "bg-green-50 border-green-200"
                        : ch.status === "active"
                          ? "bg-white border-gray-200 shadow-sm"
                          : "bg-gray-50 border-gray-200 opacity-50"
                    }`}
                  >
                    <div className="text-2xl mb-2">{ch.icon}</div>
                    <h4 className="text-xs font-bold leading-tight mb-1">{ch.title}</h4>
                    <p className="text-[10px] text-gray-500 leading-tight mb-2 line-clamp-2">{ch.description}</p>

                    {/* Progress bar */}
                    <div className="w-full h-1.5 bg-gray-200 rounded-full mb-1.5 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${ch.status === "completed" ? "bg-green-500" : "bg-[#E63946]"}`}
                        style={{ width: `${(ch.progress / ch.maxProgress) * 100}%` }}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-yellow-600 flex items-center gap-0.5">
                        +{ch.reward} <KarlMarxCoin size={10} />
                      </span>
                      <span className="text-[9px] text-gray-400">
                        {"⭐".repeat(ch.difficulty)}
                      </span>
                    </div>

                    {ch.status === "completed" && (
                      <div className="absolute top-2 right-2">
                        <CheckCircle2 size={16} className="text-green-500" />
                      </div>
                    )}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ========== Challenge Detail Popup ========== */}
      <AnimatePresence>
        {selectedChallenge && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedChallenge(null)}
              className="fixed inset-0 bg-black/50 z-[80]"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 250 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[32px] z-[90] px-5 pt-2 pb-8 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-4" />

              {/* CoinPower Banner */}
              <div className="bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-2xl p-3 mb-4 flex items-center gap-3">
                <div className="w-10 h-10 bg-yellow-200 rounded-full flex items-center justify-center">
                  <span className="text-lg font-black text-yellow-700">{coinPower}</span>
                </div>
                <div className="flex-1">
                  <p className="text-xs font-bold text-yellow-900">CoinPower Bonus</p>
                  <p className="text-[10px] text-yellow-800">+{selectedChallenge.coinPowerBonus} CP bei Abschluss</p>
                </div>
              </div>

              {/* Challenge Info */}
              <div className="text-center mb-4">
                <div className="text-5xl mb-2">{selectedChallenge.icon}</div>
                <h3 className="text-xl font-black">{selectedChallenge.title}</h3>
                <div className="flex items-center justify-center gap-1 mt-1">
                  {Array.from({ length: 3 }).map((_, i) => (
                    <Star
                      key={i}
                      size={16}
                      className={i < selectedChallenge.difficulty ? "text-yellow-400 fill-yellow-400" : "text-gray-200"}
                    />
                  ))}
                </div>
                <p className="text-sm text-gray-600 mt-2">{selectedChallenge.description}</p>
              </div>

              {/* Progress */}
              <div className="mb-4">
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-gray-600">Fortschritt</span>
                  <span className="font-bold">{selectedChallenge.progress}/{selectedChallenge.maxProgress}</span>
                </div>
                <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(selectedChallenge.progress / selectedChallenge.maxProgress) * 100}%` }}
                    className="h-full bg-[#E63946] rounded-full"
                  />
                </div>
              </div>

              {/* Reward */}
              <div className="bg-gray-50 rounded-2xl p-4 mb-4 flex items-center justify-between">
                <span className="text-sm font-bold text-gray-700">Belohnung</span>
                <div className="flex items-center gap-2">
                  <span className="text-lg font-black text-[#F59E0B]">+{selectedChallenge.reward}</span>
                  <KarlMarxCoin size={20} />
                </div>
              </div>

              {/* Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={() => setSelectedChallenge(null)}
                  className="flex-1 py-3.5 border border-gray-300 rounded-2xl font-bold text-sm"
                >
                  Zurück
                </button>
                {selectedChallenge.status === "active" && (
                  <button
                    onClick={() => {
                      setCoinPower(prev => Math.min(prev + selectedChallenge.coinPowerBonus, 100));
                      setSelectedChallenge(null);
                    }}
                    className="flex-1 py-3.5 bg-[#E63946] text-white rounded-2xl font-black text-sm shadow-lg shadow-red-500/20"
                  >
                    Challenge annehmen
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Quest Detail Bottom Sheet */}
      <AnimatePresence>
        {selectedQuestId && selectedQuest && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedQuestId(null)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[40px] z-[70] px-6 pt-2 pb-10 shadow-2xl max-h-[85vh] overflow-y-auto"
            >
              <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6" />

              {selectedQuest.status === "locked" ? (
                <div className="flex flex-col items-center text-center gap-6">
                  <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-500">
                    <Lock size={40} />
                  </div>
                  <div className="flex flex-col gap-2">
                    <h2 className="text-2xl font-black text-text-primary tracking-tight">
                      {t("levelUnlock")} {selectedQuest.nodeNumber}
                    </h2>
                    <p className="text-sm font-bold text-text-secondary leading-relaxed">
                      {t("moreRewardsDesc")}
                    </p>
                  </div>

                  <div className="w-full grid grid-cols-2 gap-4">
                    <div className="bg-secondary/50 p-4 rounded-3xl border border-border flex flex-col items-center gap-2">
                      <Gift size={24} className="text-[#F59E0B]" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                        {t("belohnung")}
                      </span>
                      <span className="text-sm font-bold text-text-primary">Exklusiv Reward</span>
                    </div>
                    <div className="bg-amber-50 p-4 rounded-3xl border border-amber-100 flex flex-col items-center gap-2">
                      <Sparkles size={24} className="text-[#F59E0B]" />
                      <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                        TIPP
                      </span>
                      <span className="text-sm font-bold text-text-primary">Schneller Leveln</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => setSelectedQuestId(null)}
                    className="w-full bg-[#E63946] text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-red-500/20"
                  >
                    {t("verstanden")}
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-6">
                  <div className="flex justify-between items-start">
                    <div className="flex flex-col gap-2">
                      <div className="flex gap-2">
                        <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                          📍 CHECK-IN
                        </span>
                        {selectedQuest.status === "active" && (
                          <span className="bg-red-100 text-[#E63946] px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                            {t("aktiv")}
                          </span>
                        )}
                      </div>
                      <h2 className="text-2xl font-black text-text-primary tracking-tight">
                        {selectedQuest.title}
                      </h2>
                      <p className="text-sm font-bold text-text-secondary leading-relaxed">
                        {selectedQuest.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between items-end">
                      <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">
                        {t("fortschrittVerfolgen")}
                      </span>
                      <span className="text-xs font-black text-text-primary">
                        {selectedQuest.progress}/{selectedQuest.maxProgress}
                      </span>
                    </div>
                    <div className="w-full h-3 bg-secondary rounded-full overflow-hidden border border-border">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(selectedQuest.progress / selectedQuest.maxProgress) * 100}%` }}
                        className="h-full bg-[#E63946]"
                      />
                    </div>
                  </div>

                  <div className="bg-secondary/50 p-6 rounded-3xl border border-border flex items-center justify-between">
                    <div className="flex flex-col gap-1">
                      <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                        {t("belohnung")}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-xl font-black text-text-primary">+{selectedQuest.reward}</span>
                        <KarlMarxCoin size={24} />
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                        {t("noch")}
                      </span>
                      <div className="flex items-center gap-1 text-[#E63946]">
                        <Clock size={16} />
                        <span className="text-sm font-black">2T 4H</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 px-2">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map(i => (
                        <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                          <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="User" referrerPolicy="no-referrer" />
                        </div>
                      ))}
                    </div>
                    <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">
                      <span className="text-text-primary font-black">124 Chemnitzer</span> {t("machenDasGerade")}
                    </span>
                  </div>

                  <button 
                    onClick={() => setSelectedQuestId(null)}
                    className="w-full bg-[#E63946] text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-red-500/20"
                  >
                    {t("mitmachen")}
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="h-20" />

      {/* Inventory Modal */}
      <InventoryModal
        isOpen={showInventory}
        onClose={() => setShowInventory(false)}
        coinPower={coinPower}
        userCoins={user.balance}
        userStreak={user.streak}
        onActivatePowerUp={(pu) => {
          console.log("Activated power-up:", pu.name);
        }}
        onBuyPowerUp={(pu, method) => {
          console.log("Bought power-up:", pu.name, "via", method);
        }}
      />
    </div>
  );
};

export default QuestsTab;
