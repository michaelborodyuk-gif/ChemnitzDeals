import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  Gift, 
  MapPin, 
  Star, 
  ArrowRight, 
  Lock, 
  X, 
  Instagram, 
  Clock, 
  AlertCircle,
  TrendingUp,
  ChevronRight
} from "lucide-react";
import { useUser } from "../context/UserContext";
import { useLanguage } from "../context/LanguageContext";
import KarlMarxCoin from "./KarlMarxCoin";

const RewardsTab: React.FC = () => {
  const { partners, unlockReward, claimReward, user } = useUser();
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeSubTab, setActiveSubTab] = useState<"offers" | "partners">("offers");
  const [selectedPartnerId, setSelectedPartnerId] = useState<string | null>(null);

  const selectedPartner = partners.find(p => p.id === selectedPartnerId);
  const partnerBalance = selectedPartnerId ? user.partnerBalances[selectedPartnerId] || 0 : 0;

  const filteredPartners = partners.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getCategoryGradient = (category: string) => {
    switch (category) {
      case "food": return "from-red-500 to-orange-600";
      case "cafe": return "from-purple-400 to-indigo-600";
      case "fitness": return "from-blue-400 to-blue-700";
      case "beauty": return "from-pink-400 to-pink-600";
      case "entertainment": return "from-yellow-400 to-orange-600";
      default: return "from-gray-400 to-gray-600";
    }
  };

  return (
    <div className="flex flex-col min-h-full bg-white">
      {/* Header & Search */}
      <div className="px-6 pt-8 pb-4 flex flex-col gap-6 sticky top-0 bg-white/80 backdrop-blur-md z-40 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-text-primary tracking-tight">
            {t("rewards")}
          </h2>
          <div className="flex items-center gap-2 bg-secondary px-3 py-1.5 rounded-full border border-border shadow-sm">
            <span className="text-[10px] font-black text-text-primary">{user.balance}</span>
            <KarlMarxCoin size={16} />
          </div>
        </div>

        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary" size={20} />
          <input
            type="text"
            placeholder={t("searchPlaceholder")}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-secondary border-none rounded-2xl py-4 pl-12 pr-4 text-sm font-bold focus:ring-2 focus:ring-[#E63946] transition-all"
          />
        </div>

        <div className="flex gap-2 p-1 bg-secondary rounded-2xl border border-border">
          {(["offers", "partners"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveSubTab(tab)}
              className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeSubTab === tab ? "bg-white text-text-primary shadow-sm" : "text-text-secondary"
              }`}
            >
              {tab === "offers" ? "Angebote" : "Partner"}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 px-6 py-8">
        {activeSubTab === "offers" ? (
          <div className="flex flex-col gap-8">
            <h3 className="text-sm font-black text-text-primary uppercase tracking-widest">
              {t("rewardPasses")}
            </h3>
            
            <div className="flex flex-col gap-6">
              {filteredPartners.map((partner) => (
                <motion.div
                  key={partner.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  onClick={() => setSelectedPartnerId(partner.id)}
                  className={`relative w-full h-[180px] rounded-[32px] overflow-hidden shadow-xl cursor-pointer group bg-gradient-to-br ${getCategoryGradient(partner.category)}`}
                >
                  <div className="absolute left-0 top-0 bottom-0 w-[40%] overflow-hidden">
                    <img 
                      src={partner.image} 
                      alt={partner.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/20 backdrop-blur-[2px]" />
                  </div>

                  <div className="absolute right-0 top-0 bottom-0 w-[60%] p-6 flex flex-col justify-between text-white">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2 text-[8px] font-black uppercase tracking-widest opacity-80">
                        <span>{partner.tiers[1].type === "premium" ? "Premium Pass" : "Basis Pass"}</span>
                        <ArrowRight size={10} />
                      </div>
                      <h4 className="text-lg font-black leading-tight">
                        Exklusive Rewards @ {partner.name}
                      </h4>
                    </div>

                    <div className="flex flex-col gap-2">
                      <span className="text-[10px] font-bold opacity-90">
                        {partner.tiers[1].isUnlocked ? t("jetztAktivieren") : t("levelUpToUnlock")}
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black uppercase tracking-widest">{partner.visitorCount} {t("heuteBesucht")}</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {filteredPartners.map((partner) => (
              <motion.div
                key={partner.id}
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                onClick={() => setSelectedPartnerId(partner.id)}
                className="bg-white rounded-3xl overflow-hidden border border-border shadow-sm flex flex-col cursor-pointer"
              >
                <div className="h-32 relative">
                  <img src={partner.image} alt={partner.name} className="w-full h-full object-cover" />
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
                    <Star size={10} className="text-yellow-500 fill-yellow-500" />
                    <span className="text-[10px] font-black">{partner.rating}</span>
                  </div>
                </div>
                <div className="p-4 flex flex-col gap-1">
                  <h4 className="text-sm font-black text-text-primary truncate">{partner.name}</h4>
                  <div className="flex items-center gap-1 text-text-secondary">
                    <MapPin size={10} />
                    <span className="text-[10px] font-medium truncate">{partner.location}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Partner Detail Modal */}
      <AnimatePresence>
        {selectedPartnerId && selectedPartner && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-end sm:items-center justify-center p-4"
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="bg-white w-full max-w-md rounded-t-[40px] sm:rounded-[40px] p-8 flex flex-col gap-8 max-h-[90vh] overflow-y-auto relative"
            >
              <div className="flex items-center justify-between">
                <div className="flex flex-col">
                  <h3 className="text-xl font-black text-text-primary tracking-tight">
                    {selectedPartner.name}
                  </h3>
                  <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">
                    {selectedPartner.category} · {selectedPartner.location}
                  </span>
                </div>
                <button 
                  onClick={() => setSelectedPartnerId(null)}
                  className="p-2 hover:bg-secondary rounded-full"
                >
                  <X size={24} />
                </button>
              </div>

              {/* Loyalty Progress Card */}
              <div className="bg-secondary/50 rounded-[32px] p-6 border border-border flex flex-col gap-6">
                <div className="flex justify-between items-start">
                  <div className="flex flex-col gap-1">
                    <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">
                      Deine Shop-Coins
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-3xl font-black text-text-primary">{partnerBalance}</span>
                      <KarlMarxCoin size={24} />
                    </div>
                  </div>
                  <div className="bg-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border border-border shadow-sm">
                    {t("heuteBesucht")}
                  </div>
                </div>

                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black text-[#E63946] uppercase tracking-widest">
                      {t("fastGeschafft")}
                    </span>
                    <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">
                      {partnerBalance}/100
                    </span>
                  </div>
                  <div className="w-full h-3 bg-white rounded-full overflow-hidden border border-border">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(partnerBalance / 100 * 100, 100)}%` }}
                      className="h-full bg-[#E63946]"
                    />
                  </div>
                  <p className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">
                    {partnerBalance >= 100 ? "Du hast genug für einen Reward!" : `Noch ${100 - partnerBalance} Coins bis zum nächsten Reward`}
                  </p>
                </div>
              </div>

              {/* Reward Tiers */}
              <div className="flex flex-col gap-6">
                <h4 className="text-sm font-black text-text-primary uppercase tracking-widest">
                  Verfügbare Belohnungen
                </h4>
                {selectedPartner.tiers.map((tier) => (
                  <div key={tier.id} className="relative">
                    <div className={`p-6 rounded-3xl border-2 flex flex-col gap-4 transition-all ${
                      tier.isUnlocked 
                        ? "border-[#E63946] bg-red-50/30" 
                        : "border-border bg-secondary/30 opacity-60 grayscale"
                    }`}>
                      <div className="flex justify-between items-start">
                        <div className="flex flex-col gap-1">
                          <span className={`text-[10px] font-black uppercase tracking-widest ${
                            tier.type === "premium" ? "text-pink-500" : "text-[#E63946]"
                          }`}>
                            {tier.type === "premium" ? "Premium Reward" : "Basis Reward"}
                          </span>
                          <h4 className="text-lg font-black text-text-primary">
                            {tier.title}
                          </h4>
                        </div>
                        {!tier.isUnlocked && (
                          <Lock size={20} className="text-text-secondary" />
                        )}
                      </div>

                      <p className="text-sm font-medium text-text-secondary leading-relaxed">
                        {tier.description}
                      </p>

                      {tier.isUnlocked ? (
                        <button 
                          onClick={() => claimReward(selectedPartnerId, tier.id)}
                          disabled={tier.isClaimed}
                          className={`w-full py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg transition-all ${
                            tier.isClaimed 
                              ? "bg-secondary text-text-secondary" 
                              : "bg-[#E63946] text-white shadow-red-500/20"
                          }`}
                        >
                          {tier.isClaimed ? "Eingelöst ✓" : t("activateReward")}
                        </button>
                      ) : (
                        <div className="flex flex-col gap-4">
                          <button 
                            onClick={() => unlockReward(selectedPartnerId, tier.id)}
                            className="bg-white text-[#E63946] border-2 border-[#E63946] w-full py-4 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-sm hover:bg-red-50 transition-colors"
                          >
                            <KarlMarxCoin size={16} />
                            {tier.coinCost || 50} Coins einlösen
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="h-20" />
    </div>
  );
};

export default RewardsTab;
