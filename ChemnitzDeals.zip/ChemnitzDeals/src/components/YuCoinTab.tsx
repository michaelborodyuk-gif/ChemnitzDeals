import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MapPin, Gift, UserPlus, ArrowRight, Flame, Sparkles, Gamepad2, Instagram, Star, Share2, Info } from "lucide-react";
import { useUser } from "../context/UserContext";
import { useLanguage } from "../context/LanguageContext";
import { MOCK_TIPS, CATEGORIES, COIN_CONFIG } from "../constants";
import KarlMarxCoin from "./KarlMarxCoin";
import DuelModal from "./DuelModal";

const YuCoinTab: React.FC = () => {
  const { 
    user, 
    transactions, 
    partners,
    openBlindBox, 
    claimSupporterBonus, 
    supportPartner,
    sharePartnerPost,
    followPartnerSocial,
    submitGoogleReview,
    submitStory
  } = useUser();
  const { t } = useLanguage();
  const [currentTipIndex, setCurrentTipIndex] = useState(0);
  const [isDuelOpen, setIsDuelOpen] = useState(false);
  const [showPartnerSelect, setShowPartnerSelect] = useState<{ type: 'support' | 'story', isOpen: boolean }>({ type: 'support', isOpen: false });

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTipIndex(prev => (prev + 1) % MOCK_TIPS.length);
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const earnings = transactions.filter(t => t.type === "earn" || t.type === "gift_receive").slice(0, 3);
  const dailyGoalPercent = Math.min(Math.round((user.todayEarned / 100) * 100), 100);

  const totalPartnerCoins = Object.values(user.partnerBalances).reduce((a: number, b: number) => a + b, 0);
  const totalBalance = user.balance + totalPartnerCoins;

  const supportedPartnerData = user.supportedPartner 
    ? partners.find(p => p.id === user.supportedPartner?.partnerId) 
    : null;

  const CATEGORY_EMOJIS: Record<string, string> = {
    food: "🍔",
    cafe: "☕",
    fitness: "💪",
    shopping: "🛍️",
    beauty: "💅",
    culture: "🎭",
    entertainment: "🎮",
    services: "🔧"
  };

  return (
    <div className="flex flex-col min-h-full bg-[#FFFBEB]">
      {/* Blind Box Banner */}
      <AnimatePresence>
        {user.blindBoxAvailable && (
          <motion.button
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            exit={{ y: -100 }}
            onClick={openBlindBox}
            className="bg-[#E63946] text-white py-3 px-6 flex items-center justify-center gap-3 font-black uppercase tracking-widest text-[10px] shadow-xl z-50 animate-pulse"
          >
            <Gift size={16} />
            🎁 Blind Box verfügbar! Jetzt öffnen
            <ArrowRight size={14} />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Top Badge */}
      <div className="px-6 pt-4 flex justify-end">
        <div className="bg-[#E63946] text-white px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-500/20">
          {user.challenges.filter(c => c.progress === c.maxProgress).length}/5 {t("challengesToday")}
        </div>
      </div>

      {/* Hero Section */}
      <div className="flex flex-col items-center text-center px-6 py-10 gap-4">
        <KarlMarxCoin size={200} animate={true} className="mb-4" />
        
        <div className="flex flex-col">
          <motion.h2 
            key={totalBalance}
            initial={{ scale: 1.2, color: "#F59E0B" }}
            animate={{ scale: 1, color: "#111827" }}
            className="text-4xl font-black text-text-primary tracking-tighter"
          >
            {totalBalance} ChemnitzCoins
          </motion.h2>
          <div className="flex flex-col gap-1">
            <span className="text-sm font-bold text-text-secondary uppercase tracking-widest">
              {t("gesamtBalance")}
            </span>
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
              100 Coins = 1 € Rabatt
            </span>
          </div>
        </div>

        <div className="bg-red-50 text-[#E63946] px-6 py-2 rounded-full flex flex-col items-center shadow-sm border border-red-100">
          <div className="flex items-center gap-2">
            <span className="text-sm font-black uppercase tracking-widest">
              {user.streak} {t("streakTage")}
            </span>
          </div>
          <span className="text-[8px] font-bold uppercase tracking-widest opacity-80">
            {t("streakBonus")}
          </span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="bg-white rounded-t-[40px] flex-1 px-6 py-8 flex flex-col gap-8 shadow-2xl">
        
        {/* Supporter Section */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-text-primary uppercase tracking-widest">
              Dein unterstützter Laden
            </h3>
          </div>
          
          {!user.supportedPartner ? (
            <button 
              onClick={() => setShowPartnerSelect({ type: 'support', isOpen: true })}
              className="bg-secondary/50 border-2 border-dashed border-border p-6 rounded-3xl flex flex-col items-center gap-2 text-center group hover:border-[#E63946] transition-colors"
            >
              <div className="w-12 h-12 rounded-2xl bg-white flex items-center justify-center text-text-secondary group-hover:text-[#E63946] transition-colors shadow-sm">
                <Star size={24} />
              </div>
              <div className="flex flex-col">
                <span className="text-xs font-black text-text-primary uppercase tracking-widest">Werde Supporter</span>
                <span className="text-[10px] font-medium text-text-secondary">Verdiene täglich Bonus-Coins</span>
              </div>
            </button>
          ) : (
            <div className="bg-white border border-border p-5 rounded-3xl shadow-sm flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">{CATEGORY_EMOJIS[supportedPartnerData?.category || 'food']}</span>
                  <div className="flex flex-col">
                    <span className="text-sm font-black text-text-primary">{supportedPartnerData?.name}</span>
                    <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">Seit {new Date(user.supportedPartner.since).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[10px] font-black text-[#F59E0B] uppercase tracking-widest">Bonus gesamt</span>
                  <span className="text-sm font-black text-text-primary">+{user.supportedPartner.bonusEarned}</span>
                </div>
              </div>
              
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">Energie</span>
                  <span className="text-[10px] font-black text-[#E63946] uppercase tracking-widest">
                    {supportedPartnerData ? (supportedPartnerData.visitorCount % 3) : 0} / 3
                  </span>
                </div>
                <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${((supportedPartnerData?.visitorCount || 0) % 3) / 3 * 100}%` }}
                    className="h-full bg-[#E63946]"
                  />
                </div>
              </div>

              <button 
                disabled={user.lastSupporterBonusDate === new Date().toISOString().split('T')[0] || (supportedPartnerData?.visitorCount || 0) % 3 !== 0}
                onClick={claimSupporterBonus}
                className={`w-full py-3 rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg transition-all ${
                  user.lastSupporterBonusDate === new Date().toISOString().split('T')[0] || (supportedPartnerData?.visitorCount || 0) % 3 !== 0
                    ? "bg-gray-100 text-gray-400 border border-gray-200"
                    : "bg-[#E63946] text-white shadow-red-500/20"
                }`}
              >
                {user.lastSupporterBonusDate === new Date().toISOString().split('T')[0] ? "Heute schon abgeholt" : "Bonus abholen"}
              </button>
            </div>
          )}
        </div>

        {/* Achievement Progress */}
        <div className="flex flex-col gap-2">
          <p className="text-[10px] font-black text-text-secondary uppercase tracking-widest text-center">
            {t("achievementProgress").replace("{percent}", dailyGoalPercent.toString())}
          </p>
          <div className="w-full h-3 bg-secondary rounded-full overflow-hidden border border-border">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${dailyGoalPercent}%` }}
              className="h-full bg-[#E63946]"
            />
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { icon: MapPin, label: t("partnerBesuchen"), color: "bg-blue-50 text-blue-500", onClick: () => {} },
            { icon: Gift, label: t("coinsVerschenken"), color: "bg-purple-50 text-purple-500", onClick: () => {} },
            { icon: Instagram, label: "STORY", color: "bg-pink-50 text-pink-500", onClick: () => setShowPartnerSelect({ type: 'story', isOpen: true }) },
            { icon: Gamepad2, label: "DUELL", color: "bg-red-50 text-[#E63946]", onClick: () => setIsDuelOpen(true) },
          ].map((action) => (
            <button key={action.label} onClick={action.onClick} className="flex flex-col items-center gap-2 group">
              <div className={`w-14 h-14 rounded-3xl ${action.color} flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform`}>
                <action.icon size={24} />
              </div>
              <span className="text-[7px] font-black text-text-primary uppercase tracking-widest text-center leading-tight">
                {action.label}
              </span>
            </button>
          ))}
        </div>

        {/* Mehr verdienen Section */}
        <div className="flex flex-col gap-4">
          <h3 className="text-sm font-black text-text-primary uppercase tracking-widest">
            Mehr verdienen
          </h3>
          <div className="flex flex-col gap-3">
            {[
              {
                icon: Share2,
                label: "Post teilen",
                reward: COIN_CONFIG.SHARE_POST,
                onClick: () => setShowPartnerSelect({ type: 'support', isOpen: true }),
                isDone: false
              },
              {
                icon: Instagram,
                label: "Profil folgen",
                reward: COIN_CONFIG.SOCIAL_FOLLOW,
                onClick: () => setShowPartnerSelect({ type: 'support', isOpen: true }),
                isDone: user.socialFollowed.length > 0
              },
              {
                icon: Star,
                label: "Google Review",
                reward: COIN_CONFIG.GOOGLE_REVIEW,
                onClick: () => setShowPartnerSelect({ type: 'support', isOpen: true }),
                isDone: user.reviewedPartners.length > 0
              }
            ].map((task, i) => (
              <button 
                key={i}
                onClick={task.onClick}
                className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${
                  task.isDone ? "bg-green-50 border-green-100 opacity-60" : "bg-white border-border hover:border-[#E63946]"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${task.isDone ? "text-green-500" : "text-text-secondary"}`}>
                    <task.icon size={18} />
                  </div>
                  <span className={`text-xs font-bold ${task.isDone ? "text-green-700" : "text-text-primary"}`}>{task.label}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className={`text-xs font-black ${task.isDone ? "text-green-600" : "text-[#F59E0B]"}`}>+{task.reward}</span>
                  <KarlMarxCoin size={14} />
                </div>
              </button>
            ))}
          </div>
        </div>

        <DuelModal isOpen={isDuelOpen} onClose={() => setIsDuelOpen(false)} />

        {/* Partner Select Modal (Simplified Bottom Sheet) */}
        <AnimatePresence>
          {showPartnerSelect.isOpen && (
            <>
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setShowPartnerSelect(prev => ({ ...prev, isOpen: false }))}
                className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[150]"
              />
              <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[40px] p-8 z-[160] max-h-[70vh] overflow-y-auto"
              >
                <div className="flex justify-center mb-6">
                  <div className="w-12 h-1.5 bg-gray-200 rounded-full" />
                </div>
                <h3 className="text-xl font-black text-text-primary tracking-tight mb-6">
                  {showPartnerSelect.type === 'support' ? "Partner wählen" : "Story posten für..."}
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {partners.map(p => (
                    <button
                      key={p.id}
                      onClick={() => {
                        if (showPartnerSelect.type === 'support') supportPartner(p.id);
                        else submitStory(p.id, "insta_user");
                        setShowPartnerSelect(prev => ({ ...prev, isOpen: false }));
                      }}
                      className="p-4 rounded-3xl border border-border hover:border-[#E63946] transition-all flex flex-col items-center gap-2"
                    >
                      <span className="text-3xl">{CATEGORY_EMOJIS[p.category]}</span>
                      <span className="text-[10px] font-black text-text-primary text-center">{p.name}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* Active Challenge Cards */}
        <div className="flex flex-col gap-4">
          <div className="flex overflow-x-auto gap-4 pb-4 snap-x no-scrollbar">
            {user.challenges.map((challenge) => (
              <div 
                key={challenge.id}
                className="min-w-[85%] snap-center bg-white rounded-3xl p-6 border border-border shadow-xl flex flex-col gap-4 relative overflow-hidden"
              >
                {challenge.isNew && (
                  <div className="absolute top-0 left-0 bg-[#E63946] text-white px-4 py-1 rounded-br-2xl text-[8px] font-black uppercase tracking-widest">
                    🔥 {t("newBadge")}
                  </div>
                )}
                
                <div className="flex flex-col gap-1 mt-2">
                  <h3 className="text-lg font-black text-text-primary leading-tight">
                    {challenge.title}
                  </h3>
                  <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">
                    {challenge.deadline}
                  </span>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-black text-[#F59E0B] uppercase tracking-widest">
                      {challenge.progress} / {challenge.maxProgress}
                    </span>
                    <div className="flex items-center gap-1">
                      <span className="text-xl font-black text-text-primary">+{challenge.reward}</span>
                      <KarlMarxCoin size={20} />
                    </div>
                  </div>
                  <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(challenge.progress / challenge.maxProgress) * 100}%` }}
                      className="h-full bg-[#E63946]"
                    />
                  </div>
                </div>

                <button className="bg-[#E63946] text-white w-full py-3 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-red-500/20">
                  {t("mitmachen")}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Tip of the Day */}
        <div className="bg-white rounded-3xl p-6 border border-border shadow-sm flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <Sparkles size={16} className="text-[#F59E0B]" />
            <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">
              {t("tippDesTages")}
            </span>
          </div>
          <AnimatePresence mode="wait">
            <motion.p 
              key={currentTipIndex}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="text-sm font-bold text-text-primary leading-relaxed"
            >
              {MOCK_TIPS[currentTipIndex]}
            </motion.p>
          </AnimatePresence>
        </div>

        {/* Recent Activity */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-black text-text-primary uppercase tracking-widest">
              {t("deineVerdienste")}
            </h3>
            <button className="text-[10px] font-black text-[#F59E0B] uppercase tracking-widest">
              {t("alleAnsehen")}
            </button>
          </div>
          <div className="flex flex-col gap-3">
            {earnings.map((item) => {
              const isPartnerPoint = item.description.includes("(");
              const partnerName = isPartnerPoint ? item.description.split("(")[1].replace(")", "") : "";
              const cleanDescription = isPartnerPoint ? item.description.split("(")[0].trim() : item.description;
              
              return (
                <div key={item.id} className="flex items-center justify-between p-3 bg-secondary/30 rounded-2xl border border-border/50">
                  <div className="flex items-center gap-3">
                    {isPartnerPoint ? (
                      <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center">
                        <MapPin size={14} className="text-gray-600" />
                      </div>
                    ) : (
                      <KarlMarxCoin size={24} />
                    )}
                    <div className="flex flex-col">
                      <span className="text-xs font-bold text-text-primary">{cleanDescription}</span>
                      {isPartnerPoint && (
                        <span className="text-[8px] font-black text-text-secondary uppercase tracking-widest">{partnerName}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className={`text-sm font-black ${isPartnerPoint ? "text-text-primary" : "text-[#F59E0B]"}`}>
                      +{item.amount}
                    </span>
                    {isPartnerPoint && (
                      <span className="text-[8px] font-black text-text-secondary uppercase tracking-widest">PTS</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="h-20" />
      </div>
    </div>
  );
};

export default YuCoinTab;
