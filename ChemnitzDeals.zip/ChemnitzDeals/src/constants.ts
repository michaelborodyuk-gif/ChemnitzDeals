import { Category, Partner, Quest, UserState, Transaction, Challenge, Reward, PowerUp, LevelDefinition, LevelChallenge, SeasonalRewardPath } from "./types";

// ============================================================
// COIN ECONOMICS - Business Model
// ============================================================
// Partner zahlen monatliche Gebuehr oder Provision pro Reward.
// Coins treiben echten Foot Traffic zu den Partnern.
//
// VERDIENEN:
//   Check-in (Besuch)     = 15 Coins   (hoechster wiederkehrender Wert)
//   Story posten          = 25 Coins   (Social Proof)
//   Social Follow         = 30 Coins   (einmalig, Reichweite)
//   Google Review         = 40 Coins   (einmalig, hoechster Einzelwert)
//   Post teilen           = 20 Coins   (Reichweite)
//   Duell Sieg            = 10 Coins   (Gamification)
//   Taegliches Rubbellos  = 2-8 Coins  (Login-Anreiz)
//
// AUSGEBEN:
//   Basis Reward           = 0 Coins   (Lockvogel)
//   Kleiner Premium        = 100 Coins (~7 Besuche)
//   Mittlerer Premium      = 300 Coins (~20 Besuche)
//   Grosser Premium        = 750 Coins (~50 Besuche)
//
// ROI-Beispiel: 750 Coins / 15 pro Besuch = 50 Besuche
//   50 Besuche × 6 EUR Durchschnitt = 300 EUR Umsatz
//   Partner verschenkt 6 EUR, generiert 300 EUR → ROI 50:1
// ============================================================

export const COIN_CONFIG = {
  // Earning rates
  CHECK_IN_MIN: 12,
  CHECK_IN_MAX: 18,
  LUCKY_BONUS: 25,
  LUCKY_CHANCE: 0.08,
  STORY_POST: 25,
  SOCIAL_FOLLOW: 30,
  GOOGLE_REVIEW: 40,
  SHARE_POST: 20,
  DUEL_WIN_MIN: 8,
  DUEL_WIN_MAX: 15,
  DUEL_DRAW_MIN: 3,
  DUEL_DRAW_MAX: 6,
  SCRATCH_MIN: 2,
  SCRATCH_MAX: 8,
  MOJI_CREATION: 20,
  BLIND_BOX: 10,
  SUPPORTER_BONUS_MIN: 8,
  SUPPORTER_BONUS_MAX: 15,

  // Display
  COINS_PER_EURO: 100,  // 100 Coins = 1 EUR Rabatt
};

export const BRAND_COLORS = {
  primary: "#E63946", // Chemnitz red
  secondary: "#1A1A1A", // Near black
  accent: "#F59E0B", // Gold
  background: "#FFFFFF",
  cardBg: "#F8F8F8",
  textPrimary: "#1A1A1A",
  textSecondary: "#6B7280",
  warmYellow: "#FFFBEB"
};

export const CATEGORIES: Category[] = [
  "food",
  "cafe",
  "fitness",
  "shopping",
  "entertainment",
  "beauty",
  "culture",
  "services"
];

export const MOCK_PARTNERS: Partner[] = [
  {
    id: "1",
    name: "Döner Palace",
    category: "food",
    location: "Zwickauer Str. 12",
    coordinates: { lat: 50.827, lng: 12.912 },
    image: "https://picsum.photos/seed/doner/800/600",
    description: "Der beste Döner in Chemnitz mit frischen Zutaten.",
    rating: 4.8,
    visitorCount: 47,
    instagram: "donerpalace_chemnitz",
    briefFacts: [
      "Täglich frisch gebackenes Brot",
      "Geheimrezept für die Kräutersoße",
      "Über 20 Jahre Erfahrung",
      "Beliebtester Spot für Nachtschwärmer"
    ],
    tiers: [
      { id: "1a", title: "Gratis Soße", description: "Basis, immer verfügbar", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "1b", title: "1€ Rabatt auf alles", description: "Nach 7 Besuchen erreichbar", type: "premium", unlockMethod: "coins", coinCost: 100, isUnlocked: false, isClaimed: false },
      { id: "1c", title: "Gratis Döner", description: "Für treue Stammkunden", type: "premium", unlockMethod: "coins", coinCost: 750, isUnlocked: false, isClaimed: false }
    ]
  },
  {
    id: "2",
    name: "Café Roter Turm",
    category: "cafe",
    location: "Markt 1",
    coordinates: { lat: 50.833, lng: 12.921 },
    image: "https://picsum.photos/seed/cafe/800/600",
    description: "Traditionelles Café direkt am Wahrzeichen.",
    rating: 4.5,
    visitorCount: 32,
    instagram: "caferoterturm",
    briefFacts: [
      "Bester Blick auf den Roten Turm",
      "Hausgemachte Torten nach Omas Rezept",
      "Röstkaffee aus lokaler Manufaktur",
      "Historisches Ambiente seit 1990"
    ],
    tiers: [
      { id: "2a", title: "Gratis Aufguss", description: "Basis Reward", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "2b", title: "Gratis Stück Kuchen", description: "Nach ~7 Besuchen", type: "premium", unlockMethod: "coins", coinCost: 100, isUnlocked: false, isClaimed: false },
      { id: "2c", title: "Kaffeeflatrate für einen Tag", description: "Für echte Stammgäste", type: "premium", unlockMethod: "coins", coinCost: 750, isUnlocked: false, isClaimed: false }
    ]
  },
  {
    id: "8",
    name: "Roter Turm Döner",
    category: "food",
    location: "Neumarkt, Chemnitz",
    coordinates: { lat: 50.832, lng: 12.922 },
    image: "https://picsum.photos/seed/roterdoner/800/600",
    description: "Frischer Döner direkt am Roten Turm — Chemnitz Klassiker.",
    rating: 4.7,
    visitorCount: 0,
    instagram: "roterdoner_chemnitz",
    briefFacts: [
      "Direkt am Roten Turm",
      "Frische Zutaten täglich",
      "Schnell, günstig, lecker",
      "Geheimtipp der Stammkunden"
    ],
    tiers: [
      { id: "8a", title: "Gratis Extra-Soße", description: "Basis, immer verfügbar", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "8b", title: "Döner für 1€", description: "Story + Google-Bewertung posten", type: "premium", unlockMethod: "story", isUnlocked: false, isClaimed: false },
    ]
  },
  {
    id: "9",
    name: "Feuerbiss",
    category: "food",
    location: "Chemnitz Innenstadt",
    coordinates: { lat: 50.834, lng: 12.917 },
    image: "https://picsum.photos/seed/feuerbiss/800/600",
    description: "Saftige Burger mit Feuer-Feeling — Chemnitz bestes Burger-Joint.",
    rating: 4.6,
    visitorCount: 0,
    instagram: "feuerbiss_chemnitz",
    briefFacts: [
      "Hausgemachte Burger-Patties",
      "Scharfe Signature-Saucen",
      "Frische Brioche-Brötchen",
      "Auch vegane Optionen"
    ],
    tiers: [
      { id: "9a", title: "Gratis Dip-Sauce", description: "Basis, immer verfügbar", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "9b", title: "Burger für 3€", description: "Instagram-Story bei Feuerbiss posten", type: "premium", unlockMethod: "story", isUnlocked: false, isClaimed: false },
    ]
  },
  {
    id: "10",
    name: "Hychinka Chemnitz",
    category: "food",
    location: "Chemnitz",
    coordinates: { lat: 50.829, lng: 12.919 },
    image: "https://picsum.photos/seed/hychinka/800/600",
    description: "Authentische Küche mit besonderem Flair — ein Muss in Chemnitz.",
    rating: 4.8,
    visitorCount: 0,
    instagram: "hychinka_chemnitz",
    briefFacts: [
      "Authentische Rezepte",
      "Familiäre Atmosphäre",
      "Frisch gekocht jeden Tag",
      "Geheimtipp der Locals"
    ],
    tiers: [
      { id: "10a", title: "Gratis Brot zum Essen", description: "Basis, immer verfügbar", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "10b", title: "5€ Rabatt", description: "Story + Google-Bewertung posten", type: "premium", unlockMethod: "story", isUnlocked: false, isClaimed: false },
    ]
  },
  {
    id: "11",
    name: "Eisfenster Gloesa",
    category: "food",
    location: "Gloesa, Chemnitz",
    coordinates: { lat: 50.831, lng: 12.920 },
    image: "https://picsum.photos/seed/eisfenster/800/600",
    description: "Cremiges Eis aus eigener Herstellung — der süßeste Stopp in Gloesa.",
    rating: 4.9,
    visitorCount: 0,
    instagram: "eisfenster_gloesa",
    briefFacts: [
      "Über 20 hausgemachte Sorten",
      "Frische Saisonkugeln",
      "Vegane und laktosefreie Optionen",
      "Familienrezept seit Jahrzehnten"
    ],
    tiers: [
      { id: "11a", title: "Gratis Waffelspitze", description: "Basis, immer verfügbar", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "11b", title: "2. Kugel gratis", description: "Story + Google-Bewertung posten", type: "premium", unlockMethod: "story", isUnlocked: false, isClaimed: false },
    ]
  },
  {
    id: "4",
    name: "SportCity Chemnitz",
    category: "fitness",
    location: "Limbacher Str. 67",
    coordinates: { lat: 50.841, lng: 12.898 },
    image: "https://picsum.photos/seed/gym/800/600",
    description: "Modernes Fitnessstudio mit Sauna und Kursen.",
    rating: 4.7,
    visitorCount: 56,
    instagram: "sportcity_chemnitz",
    briefFacts: [
      "Größte Saunalandschaft der Stadt",
      "Über 50 Kurse pro Woche",
      "Modernste E-Gym Geräte",
      "Kostenlose Parkplätze für Mitglieder"
    ],
    tiers: [
      { id: "4a", title: "Gratis Probestunde", description: "Basis Reward", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "4b", title: "1 Woche gratis", description: "Nach ~7 Besuchen", type: "premium", unlockMethod: "coins", coinCost: 100, isUnlocked: false, isClaimed: false },
      { id: "4c", title: "1 Monat -50%", description: "Für loyale Mitglieder", type: "premium", unlockMethod: "coins", coinCost: 750, isUnlocked: false, isClaimed: false }
    ]
  },
  {
    id: "5",
    name: "Galerie Roter Turm",
    category: "shopping",
    location: "Neumarkt 2",
    coordinates: { lat: 50.832, lng: 12.923 },
    image: "https://picsum.photos/seed/shopping/800/600",
    description: "Das größte Shopping-Center im Herzen von Chemnitz.",
    rating: 4.4,
    visitorCount: 120,
    instagram: "galerieroterturm",
    briefFacts: [
      "Über 60 Fachgeschäfte",
      "Zentraler Treffpunkt am Neumarkt",
      "Regelmäßige Events und Aktionen",
      "Großes Parkhaus direkt im Center"
    ],
    tiers: [
      { id: "5a", title: "Gratis Parken (1h)", description: "Basis Reward", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "5b", title: "5€ Shopping Gutschein", description: "Nach ~20 Besuchen", type: "premium", unlockMethod: "coins", coinCost: 300, isUnlocked: false, isClaimed: false }
    ]
  },
  {
    id: "6",
    name: "Beauty Lounge",
    category: "beauty",
    location: "Theaterstr. 4",
    coordinates: { lat: 50.835, lng: 12.918 },
    image: "https://picsum.photos/seed/beauty/800/600",
    description: "Deine Oase für Entspannung und Schönheit.",
    rating: 4.9,
    visitorCount: 18,
    instagram: "beautylounge_c",
    briefFacts: [
      "Zertifizierte Naturkosmetik",
      "Individuelle Hautanalyse",
      "Entspannende Massagen",
      "Exklusive Make-up Beratung"
    ],
    tiers: [
      { id: "6a", title: "Kostenlose Beratung", description: "Basis Reward", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "6b", title: "10% auf Behandlungen", description: "Nach ~7 Besuchen", type: "premium", unlockMethod: "coins", coinCost: 100, isUnlocked: false, isClaimed: false }
    ]
  },
  {
    id: "7",
    name: "Opernhaus Chemnitz",
    category: "culture",
    location: "Theaterplatz 2",
    coordinates: { lat: 50.838, lng: 12.924 },
    image: "https://picsum.photos/seed/opera/800/600",
    description: "Eines der modernsten Opernhäuser Deutschlands.",
    rating: 4.8,
    visitorCount: 85,
    instagram: "theaterchemnitz",
    briefFacts: [
      "Prachtvoller Bau am Theaterplatz",
      "Vielfältiges Programm (Oper, Ballett)",
      "Herausragende Akustik",
      "Blick hinter die Kulissen möglich"
    ],
    tiers: [
      { id: "7a", title: "Programmheft gratis", description: "Basis Reward", type: "basis", unlockMethod: "none", isUnlocked: true, isClaimed: false },
      { id: "7b", title: "2-für-1 Ticket", description: "Nach ~20 Besuchen", type: "premium", unlockMethod: "coins", coinCost: 300, isUnlocked: false, isClaimed: false }
    ]
  }
];

export const MOCK_REWARDS: Reward[] = MOCK_PARTNERS.map(p => ({
  id: `r-${p.id}`,
  partnerId: p.id,
  title: p.name,
  description: p.description,
  category: p.category,
  tiers: p.tiers
}));

export const MOCK_QUESTS: Quest[] = [
  {
    id: "q1",
    title: "Besuche heute 2 Partner in der Innenstadt",
    description: "Check-in bei lokalen Partnern.",
    type: "visit",
    reward: 35,
    progress: 1,
    maxProgress: 2,
    status: "active",
    nodeNumber: 1,
    category: "check-in"
  },
  {
    id: "q2",
    title: "Sammle 50 Coins durch Check-ins",
    description: "Sei aktiv in der Stadt.",
    type: "earn",
    reward: 25,
    progress: 10,
    maxProgress: 50,
    status: "locked",
    nodeNumber: 2,
    category: "discovery"
  },
  {
    id: "q3",
    title: "Teile dein Erlebnis im Schnitzelhaus",
    description: "Poste eine Story @schnitzelhaus_c",
    type: "social",
    reward: 20,
    progress: 0,
    maxProgress: 1,
    status: "locked",
    nodeNumber: 3,
    category: "story"
  },
  {
    id: "q4",
    title: "Community Champion",
    description: "Schenke 3 verschiedenen Nutzern Coins.",
    type: "community",
    reward: 40,
    progress: 1,
    maxProgress: 3,
    status: "locked",
    nodeNumber: 4,
    isRewardNode: true,
    category: "community"
  },
  {
    id: "q5",
    title: "Entdecker Tour",
    description: "Besuche 3 neue Kategorien.",
    type: "discovery",
    reward: 60,
    progress: 1,
    maxProgress: 3,
    status: "locked",
    nodeNumber: 5,
    category: "discovery"
  },
  {
    id: "q6",
    title: "Chemnitz Experte",
    description: "Check-in bei 10 Partnern.",
    type: "visit",
    reward: 80,
    progress: 4,
    maxProgress: 10,
    status: "locked",
    nodeNumber: 6,
    category: "check-in"
  }
];

export const MOCK_CHALLENGES: Challenge[] = [
  {
    id: "c1",
    title: "Besuche heute 2 Partner in der Innenstadt",
    progress: 1,
    maxProgress: 2,
    reward: 35,
    deadline: "Noch 4h 23min",
    isNew: true
  },
  {
    id: "c2",
    title: "Schenke einem Freund 10 Coins",
    progress: 0,
    maxProgress: 1,
    reward: 15,
    deadline: "Noch 8h 12min"
  }
];

export const MOCK_TIPS = [
  "🏛 Wusstest du? Der Nischel wiegt 40 Tonnen!",
  "🍕 Pizzeria Sachsen hat heute verlängerte Öffnungszeiten",
  "🌳 Der Küchwald ist perfekt für einen Frühlingsspaziergang!",
  "🎨 Das Museum Gunzenhauser beherbergt eine der bedeutendsten Sammlungen der Klassischen Moderne."
];

export const MOCK_LEADERBOARD = [
  { rank: 1, username: "SaxonKing_C", coins: 1420, quests: 12, moji: { hair: 1, glasses: 2, accessory: 0, outfit: 1 } },
  { rank: 2, username: "ChemnitzExplorer", coins: 1060, quests: 9, moji: { hair: 2, glasses: 0, accessory: 1, outfit: 2 } },
  { rank: 3, username: "KarlsFan99", coins: 810, quests: 8, moji: { hair: 0, glasses: 1, accessory: 2, outfit: 0 } },
  { rank: 4, username: "DönerQueen", coins: 580, quests: 7, moji: { hair: 3, glasses: 3, accessory: 3, outfit: 3 } },
  { rank: 5, username: "NeumarktNinja", coins: 340, quests: 5, moji: { hair: 1, glasses: 0, accessory: 1, outfit: 1 } },
  { rank: 6, username: "RoamingChemnitz", coins: 190, quests: 3, moji: { hair: 2, glasses: 1, accessory: 0, outfit: 2 } }
];

// User startet mit 0 Coins - muss sich alles verdienen
export const INITIAL_USER_STATE: UserState = {
  username: "Neuer Chemnitzer",
  level: 1,
  levelProgress: 0,
  levelMax: 6,
  balance: 0,
  todayEarned: 0,
  streak: 0,
  streakAtRisk: false,
  mojiCreated: false,
  mojiConfig: { hair: 0, glasses: 0, accessory: 0, outfit: 0 },
  favorites: [],
  leaderboardJoined: false,
  challenges: MOCK_CHALLENGES,
  supportedPartner: null,
  lastSupporterBonusDate: null,
  duelCount: 0,
  blindBoxAvailable: false,
  lastScratchDate: null,
  socialFollowed: [],
  reviewedPartners: [],
  visitedPartnerIds: [],
  partnerBalances: {}
};

export const MOCK_TRANSACTIONS: Transaction[] = [];

// ============================================================
// POWER-UPS (kaufbar mit Coins / Streaks / Werbung)
// ============================================================
export const MOCK_POWERUPS: PowerUp[] = [
  {
    id: "pu1", type: "coin_boost", name: "Coin Magnet",
    description: "+50% Coins für 30 Minuten bei jedem Check-in",
    icon: "🧲", duration: 30, multiplier: 1.5, rarity: "common",
    isActive: false, quantity: 0,
    coinCost: 50, watchAd: true,
  },
  {
    id: "pu2", type: "xp_boost", name: "XP Turbo",
    description: "+100% Quest-XP für 1 Stunde",
    icon: "⚡", duration: 60, multiplier: 2.0, rarity: "rare",
    isActive: false, quantity: 0,
    coinCost: 120, streakRequired: 7,
  },
  {
    id: "pu3", type: "streak_shield", name: "Streak Shield",
    description: "Schützt deinen Streak für einen Tag",
    icon: "🛡️", duration: 0, rarity: "rare",
    isActive: false, quantity: 0,
    coinCost: 80, streakRequired: 5, watchAd: true,
  },
  {
    id: "pu4", type: "double_reward", name: "Doppel-Reward",
    description: "Nächstes Reward doppelt einlösen",
    icon: "🎯", duration: 0, multiplier: 2.0, rarity: "epic",
    isActive: false, quantity: 0,
    coinCost: 200, streakRequired: 14,
  },
  {
    id: "pu5", type: "lucky_charm", name: "Glücksbringer",
    description: "Lucky-Bonus Chance auf 25% erhöht (1h)",
    icon: "🍀", duration: 60, multiplier: 3.0, rarity: "epic",
    isActive: false, quantity: 0,
    coinCost: 150, streakRequired: 10, watchAd: true,
  }
];

// ============================================================
// LEVEL-CHALLENGES: Jedes Level = Partner-Besuche & Aktionen
// ============================================================
// Alles dreht sich um Läden besuchen, promoten, bewerten.
// CoinPower steigt mit jeder Challenge → bessere Rewards.
// ============================================================
export const MOCK_LEVELS: LevelDefinition[] = [
  {
    level: 1,
    title: "Entdecker",
    description: "Lerne deine ersten Partner kennen",
    icon: "🐌",
    isUnlocked: true,
    requiredLevel: 1,
    challenges: [
      {
        id: "lc1-1", title: "Erster Check-in", description: "Besuche einen beliebigen Partner und checke ein",
        challengeType: "visit", icon: "📍", reward: 15, progress: 0, maxProgress: 1,
        status: "active", coinPowerBonus: 2, difficulty: 1, level: 1,
      },
      {
        id: "lc1-2", title: "Döner testen", description: "Check-in beim Döner Palace",
        challengeType: "visit", icon: "🥙", reward: 20, partnerId: "1", progress: 0, maxProgress: 1,
        status: "active", coinPowerBonus: 3, difficulty: 1, level: 1,
      },
      {
        id: "lc1-3", title: "Kaffee-Pause", description: "Besuche das Café Roter Turm",
        challengeType: "visit", icon: "☕", reward: 20, partnerId: "2", progress: 0, maxProgress: 1,
        status: "active", coinPowerBonus: 3, difficulty: 1, level: 1,
      },
      {
        id: "lc1-4", title: "Story posten", description: "Poste eine Instagram-Story bei einem Partner",
        challengeType: "story", icon: "📸", reward: 25, progress: 0, maxProgress: 1,
        status: "active", coinPowerBonus: 4, difficulty: 2, level: 1,
      },
    ]
  },
  {
    level: 2,
    title: "Stammgast",
    description: "Zeig den Partnern, dass du wiederkommst",
    icon: "🐿️",
    isUnlocked: false,
    requiredLevel: 2,
    challenges: [
      {
        id: "lc2-1", title: "Doppel-Besuch", description: "Besuche heute 2 verschiedene Partner",
        challengeType: "multi_visit", icon: "🏃", reward: 35, progress: 0, maxProgress: 2,
        status: "locked", coinPowerBonus: 5, difficulty: 2, level: 2,
      },
      {
        id: "lc2-2", title: "Fitness-Check", description: "Check-in bei SportCity Chemnitz",
        challengeType: "visit", icon: "💪", reward: 20, partnerId: "4", progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 3, difficulty: 1, level: 2,
      },
      {
        id: "lc2-3", title: "Social Follower", description: "Folge einem Partner auf Instagram",
        challengeType: "social", icon: "📱", reward: 30, progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 4, difficulty: 1, level: 2,
      },
      {
        id: "lc2-4", title: "Google-Bewertung", description: "Schreibe eine Google-Review für einen Partner",
        challengeType: "review", icon: "⭐", reward: 40, progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 6, difficulty: 2, level: 2,
      },
      {
        id: "lc2-5", title: "Kultur erleben", description: "Besuche das Opernhaus",
        challengeType: "visit", icon: "🎭", reward: 25, partnerId: "7", progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 4, difficulty: 1, level: 2,
      },
    ]
  },
  {
    level: 3,
    title: "Lokalkenner",
    description: "Du kennst schon viele Ecken — zeig es!",
    icon: "🐰",
    isUnlocked: false,
    requiredLevel: 3,
    challenges: [
      {
        id: "lc3-1", title: "3er-Streak", description: "3 Tage hintereinander bei einem Partner einchecken",
        challengeType: "streak", icon: "🔥", reward: 40, progress: 0, maxProgress: 3,
        status: "locked", coinPowerBonus: 8, difficulty: 3, level: 3,
      },
      {
        id: "lc3-2", title: "Kategorie-Entdecker", description: "Besuche Partner aus 3 verschiedenen Kategorien",
        challengeType: "explore_category", icon: "🗺️", reward: 50, progress: 0, maxProgress: 3,
        status: "locked", coinPowerBonus: 8, difficulty: 2, level: 3,
      },
      {
        id: "lc3-3", title: "Beauty-Check", description: "Lass dich bei der Beauty Lounge beraten",
        challengeType: "visit", icon: "💅", reward: 20, partnerId: "6", progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 3, difficulty: 1, level: 3,
      },
      {
        id: "lc3-4", title: "Shopping-Spree", description: "Check-in in der Galerie Roter Turm",
        challengeType: "visit", icon: "🛍️", reward: 20, partnerId: "5", progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 3, difficulty: 1, level: 3,
      },
      {
        id: "lc3-5", title: "Stammgast-Bonus", description: "Löse dein erstes Premium-Reward ein",
        challengeType: "spend_coins", icon: "🎁", reward: 30, progress: 0, maxProgress: 1,
        status: "locked", coinPowerBonus: 5, difficulty: 2, level: 3,
      },
    ]
  },
  {
    level: 4,
    title: "Chemnitz-Pro",
    description: "Du bist ein echter Chemnitz-Experte",
    icon: "🦊",
    isUnlocked: false,
    requiredLevel: 4,
    challenges: [
      {
        id: "lc4-1", title: "5 Partner besucht", description: "Checke bei 5 verschiedenen Partnern ein",
        challengeType: "multi_visit", icon: "🏆", reward: 60, progress: 0, maxProgress: 5,
        status: "locked", coinPowerBonus: 10, difficulty: 3, level: 4,
      },
      {
        id: "lc4-2", title: "Story-Profi", description: "Poste 3 Stories bei verschiedenen Partnern",
        challengeType: "story", icon: "🎬", reward: 50, progress: 0, maxProgress: 3,
        status: "locked", coinPowerBonus: 8, difficulty: 3, level: 4,
      },
      {
        id: "lc4-3", title: "7er-Streak", description: "7 Tage hintereinander bei Partnern einchecken",
        challengeType: "streak", icon: "💎", reward: 80, progress: 0, maxProgress: 7,
        status: "locked", coinPowerBonus: 15, difficulty: 3, level: 4,
      },
      {
        id: "lc4-4", title: "Alle Kategorien", description: "Besuche mindestens einen Partner pro Kategorie",
        challengeType: "explore_category", icon: "🌟", reward: 100, progress: 0, maxProgress: 6,
        status: "locked", coinPowerBonus: 20, difficulty: 3, level: 4,
      },
    ]
  },
];

// ============================================================
// SEASONAL REWARD PATH
// ============================================================
export const MOCK_SEASONAL_PATH: SeasonalRewardPath = {
  currentTier: 0, maxTier: 10, xp: 0, xpToNext: 100,
  rewards: [
    { tier: 1, type: "coins", item: "25", claimed: false },
    { tier: 2, type: "powerup", item: "pu1", claimed: false },
    { tier: 3, type: "coins", item: "50", claimed: false },
    { tier: 4, type: "powerup", item: "pu3", claimed: false },
    { tier: 5, type: "coins", item: "100", claimed: false },
    { tier: 6, type: "powerup", item: "pu2", claimed: false },
    { tier: 7, type: "cosmetic", item: "golden_crown", claimed: false },
    { tier: 8, type: "powerup", item: "pu5", claimed: false },
    { tier: 9, type: "coins", item: "200", claimed: false },
    { tier: 10, type: "powerup", item: "pu4", claimed: false },
  ]
};

// ============================================================
// STEP DUEL MOCK DATA
// ============================================================
export const MOCK_DUEL_OPPONENTS = [
  { id: "bot1", name: "SaxonKing_C", avgSteps: 4500, moji: { hair: 1, glasses: 2, accessory: 0, outfit: 1 } },
  { id: "bot2", name: "ChemnitzExplorer", avgSteps: 6200, moji: { hair: 2, glasses: 0, accessory: 1, outfit: 2 } },
  { id: "bot3", name: "KarlsFan99", avgSteps: 3800, moji: { hair: 0, glasses: 1, accessory: 2, outfit: 0 } },
  { id: "bot4", name: "DönerQueen", avgSteps: 5100, moji: { hair: 3, glasses: 3, accessory: 3, outfit: 3 } },
  { id: "bot5", name: "NeumarktNinja", avgSteps: 7500, moji: { hair: 1, glasses: 0, accessory: 1, outfit: 1 } },
];
