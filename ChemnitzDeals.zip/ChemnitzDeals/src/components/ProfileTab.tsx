import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Settings, History, Heart, Gift, ArrowRight, Save, Sparkles, Coins, Trophy, Flame, MapPin } from "lucide-react";
import { useUser } from "../context/UserContext";
import { useLanguage } from "../context/LanguageContext";
import ChemnitzMoji from "./ChemnitzMoji";
import KarlMarxCoin from "./KarlMarxCoin";

const ProfileTab: React.FC = () => {
  const { user, transactions, updateMoji, partners } = useUser();
  const { t } = useLanguage();
  const [isEditingMoji, setIsEditingMoji] = useState(false);
  const [tempMoji, setTempMoji] = useState(user.mojiConfig);

  const stats = [
    { label: t("statsEarned"), value: user.balance + 1200, icon: KarlMarxCoin, color: "text-accent" },
    { label: t("statsActivated"), value: user.visitedPartnerIds.length, icon: Trophy, color: "text-blue-500" },
    { label: t("statsCompleted"), value: 28, icon: Sparkles, color: "text-purple-500" },
    { label: t("statsStreak"), value: user.streak, icon: Flame, color: "text-orange-500" }
  ];

  const CATEGORY_EMOJIS: Record<string, string> = {
    food: "🍔",
    cafe: "☕",
    fitness: "💪",
    shopping: "🛍️",
    beauty: "💅",
    culture: "🎭",
    entertainment: "🎮",
    services: "🔧"
  };

  const visitedPartners = partners.filter(p => user.visitedPartnerIds.includes(p.id));

  const handleSaveMoji = () => {
    updateMoji(tempMoji);
    setIsEditingMoji(false);
  };

  return (
    <div className="px-6 py-8 flex flex-col gap-8 max-w-md mx-auto">
      {/* Profile Header */}
      <div className="flex flex-col items-center text-center gap-4">
        <div className="relative">
          <div className="w-32 h-32 rounded-full bg-white shadow-xl border-4 border-white flex items-center justify-center overflow-hidden">
            <ChemnitzMoji config={user.mojiConfig} size={100} />
          </div>
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            className="absolute -bottom-2 -right-2 w-10 h-10 bg-pink-500 text-white rounded-full flex items-center justify-center shadow-lg border-4 border-white"
          >
            <Settings size={20} />
          </motion.button>
        </div>

        <div className="flex flex-col">
          <h2 className="text-2xl font-black text-text-primary tracking-tight">
            {user.username}
          </h2>
          <div className="flex items-center justify-center gap-2">
            <span className="bg-[#E63946] text-white px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest shadow-sm">
              Level {user.level}
            </span>
          </div>
        </div>

        <button 
          onClick={() => setIsEditingMoji(true)}
          className="bg-white px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest text-text-primary border border-border shadow-sm hover:bg-secondary transition-colors"
        >
          {t("createMoji")}
        </button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white rounded-3xl p-4 border border-border flex flex-col gap-1 shadow-sm"
          >
            <div className={`w-8 h-8 rounded-xl bg-secondary flex items-center justify-center mb-2 ${stat.color}`}>
              {stat.icon === KarlMarxCoin ? <KarlMarxCoin size={18} /> : <stat.icon size={18} />}
            </div>
            <span className="text-lg font-black text-text-primary tracking-tighter">
              {stat.value}
            </span>
            <span className="text-[8px] font-bold text-text-secondary uppercase tracking-widest">
              {stat.label}
            </span>
          </motion.div>
        ))}
      </div>

      {/* Stamp Cards Section */}
      <div className="flex flex-col gap-4">
        <h3 className="text-sm font-black text-text-primary uppercase tracking-widest">
          Meine Belohnungen
        </h3>
        <div className="grid grid-cols-4 gap-3">
          {partners.map((partner, i) => {
            const isVisited = user.visitedPartnerIds.includes(partner.id);
            const partnerBalance = user.partnerBalances[partner.id] || 0;
            return (
              <motion.div
                key={partner.id}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.3 + i * 0.05 }}
                className={`aspect-square rounded-2xl border-2 flex flex-col items-center justify-center gap-1 relative overflow-hidden ${
                  isVisited || partnerBalance > 0 ? "bg-white border-[#E63946] shadow-sm" : "bg-gray-50 border-dashed border-gray-200 opacity-40"
                }`}
              >
                <span className={`text-xl ${(!isVisited && partnerBalance === 0) && "grayscale"}`}>
                  {CATEGORY_EMOJIS[partner.category]}
                </span>
                <div className="flex flex-col items-center">
                  <span className="text-[6px] font-black text-text-primary uppercase tracking-widest text-center px-1 truncate w-full">
                    {partner.name}
                  </span>
                  {partnerBalance > 0 && (
                    <span className="text-[8px] font-black text-[#F59E0B] tracking-tighter">
                      {partnerBalance} C
                    </span>
                  )}
                </div>
                {isVisited && (
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#E63946] rounded-full flex items-center justify-center border-2 border-white">
                    <Sparkles size={8} className="text-white" />
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Menu Options */}
      <div className="flex flex-col gap-3">
        {[
          { icon: Heart, label: t("favorites"), count: user.favorites.length },
          { icon: History, label: t("history"), count: transactions.length },
          { icon: Gift, label: t("myRedemptions"), count: 4 }
        ].map((item, i) => (
          <motion.button
            key={item.label}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6 + i * 0.1 }}
            className="bg-white rounded-2xl p-4 flex items-center justify-between border border-border group shadow-sm"
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center text-text-secondary group-hover:text-[#E63946] transition-colors">
                <item.icon size={20} />
              </div>
              <span className="text-sm font-bold text-text-primary uppercase tracking-wider">
                {item.label}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-text-secondary">{item.count}</span>
              <ArrowRight size={16} className="text-text-secondary" />
            </div>
          </motion.button>
        ))}
      </div>

      {/* Moji Editor Modal */}
      <AnimatePresence>
        {isEditingMoji && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-end sm:items-center justify-center p-4"
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="bg-white w-full max-w-md rounded-t-[40px] sm:rounded-[40px] p-8 flex flex-col gap-8 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-black text-text-primary tracking-tight">
                  {t("createMoji")}
                </h3>
                <button 
                  onClick={() => setIsEditingMoji(false)}
                  className="text-text-secondary font-bold text-sm uppercase tracking-widest"
                >
                  Abbrechen
                </button>
              </div>

              <div className="flex justify-center py-8 bg-secondary rounded-[32px]">
                <ChemnitzMoji config={tempMoji} size={180} />
              </div>

              <div className="flex flex-col gap-6">
                {[
                  { label: t("frisur"), key: "hair", count: 4 },
                  { label: t("brille"), key: "glasses", count: 4 },
                  { label: t("accessoire"), key: "accessory", count: 4 },
                  { label: t("outfit"), key: "outfit", count: 4 }
                ].map((option) => (
                  <div key={option.key} className="flex flex-col gap-3">
                    <span className="text-[10px] font-black uppercase tracking-widest text-text-secondary">
                      {option.label}
                    </span>
                    <div className="flex gap-3">
                      {Array.from({ length: option.count }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setTempMoji(prev => ({ ...prev, [option.key]: i }))}
                          className={`w-12 h-12 rounded-xl border-2 transition-all ${
                            tempMoji[option.key as keyof typeof tempMoji] === i 
                              ? "border-accent bg-accent/5" 
                              : "border-border hover:border-text-secondary"
                          } flex items-center justify-center text-sm font-bold`}
                        >
                          {i === 0 ? "X" : i}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <button 
                onClick={handleSaveMoji}
                className="bg-[#E63946] text-white w-full py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
              >
                <Save size={20} />
                {t("save")}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="h-20" />
    </div>
  );
};

export default ProfileTab;
