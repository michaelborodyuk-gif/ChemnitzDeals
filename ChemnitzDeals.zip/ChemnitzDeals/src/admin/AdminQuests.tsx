import React from "react";
import { Navigate } from "react-router-dom";

// Quests sind jetzt Level-Challenges — redirect zu Activities
const AdminQuests: React.FC = () => {
  return <Navigate to="/admin/activities" replace />;
};

export default AdminQuests;
