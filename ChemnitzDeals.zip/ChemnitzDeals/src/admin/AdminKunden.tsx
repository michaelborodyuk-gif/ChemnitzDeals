import React, { useState } from "react";
import {
  Plus, Search, X, Gift, CheckCircle2, Trash2,
  User, Phone, Mail, Tag, ChevronDown, Edit2
} from "lucide-react";
import { MOCK_PARTNERS } from "../constants";

// ──────────────────────────────────────────────
// Types
// ──────────────────────────────────────────────
interface Gutschein {
  id: string;
  partnerId: string;
  partnerName: string;
  tierId: string;
  tierTitle: string;
  issuedAt: string;
  expiresAt?: string;
  status: "aktiv" | "eingeloest" | "abgelaufen";
  note?: string;
}

interface Kunde {
  id: string;
  name: string;
  email: string;
  phone: string;
  addedAt: string;
  gutscheine: Gutschein[];
  note: string;
}

// ──────────────────────────────────────────────
// Mock initial data
// ──────────────────────────────────────────────
const INITIAL_KUNDEN: Kunde[] = [
  {
    id: "k1",
    name: "Max Mustermann",
    email: "max@example.com",
    phone: "+49 171 1234567",
    addedAt: new Date().toISOString(),
    note: "Stammkunde beim Döner Palace",
    gutscheine: [
      {
        id: "g1", partnerId: "8", partnerName: "Roter Turm Döner",
        tierId: "8b", tierTitle: "Döner für 1€",
        issuedAt: new Date().toISOString(), status: "aktiv",
      }
    ]
  }
];

// ──────────────────────────────────────────────
// Component
// ──────────────────────────────────────────────
const AdminKunden: React.FC = () => {
  const [kunden, setKunden] = useState<Kunde[]>(INITIAL_KUNDEN);
  const [search, setSearch] = useState("");
  const [selectedKunde, setSelectedKunde] = useState<Kunde | null>(null);

  // Add customer modal
  const [showAddKunde, setShowAddKunde] = useState(false);
  const [newKunde, setNewKunde] = useState({ name: "", email: "", phone: "", note: "" });

  // Add voucher modal
  const [showAddGutschein, setShowAddGutschein] = useState(false);
  const [gutscheinForm, setGutscheinForm] = useState({
    partnerId: "",
    tierId: "",
    expiresAt: "",
    note: "",
  });

  // ── Helpers ─────────────────────────────────
  const filteredKunden = kunden.filter(k =>
    k.name.toLowerCase().includes(search.toLowerCase()) ||
    k.email.toLowerCase().includes(search.toLowerCase()) ||
    k.phone.includes(search)
  );

  const selectedPartner = MOCK_PARTNERS.find(p => p.id === gutscheinForm.partnerId);

  const addKunde = () => {
    if (!newKunde.name.trim()) return;
    const k: Kunde = {
      id: `k${Date.now()}`,
      ...newKunde,
      addedAt: new Date().toISOString(),
      gutscheine: [],
    };
    setKunden(prev => [k, ...prev]);
    setNewKunde({ name: "", email: "", phone: "", note: "" });
    setShowAddKunde(false);
  };

  const deleteKunde = (id: string) => {
    if (!confirm("Kunden wirklich löschen?")) return;
    setKunden(prev => prev.filter(k => k.id !== id));
    if (selectedKunde?.id === id) setSelectedKunde(null);
  };

  const addGutschein = () => {
    if (!selectedKunde || !gutscheinForm.partnerId || !gutscheinForm.tierId) return;
    const partner = MOCK_PARTNERS.find(p => p.id === gutscheinForm.partnerId);
    const tier = partner?.tiers.find(t => t.id === gutscheinForm.tierId);
    if (!partner || !tier) return;

    const g: Gutschein = {
      id: `g${Date.now()}`,
      partnerId: gutscheinForm.partnerId,
      partnerName: partner.name,
      tierId: gutscheinForm.tierId,
      tierTitle: tier.title,
      issuedAt: new Date().toISOString(),
      expiresAt: gutscheinForm.expiresAt || undefined,
      status: "aktiv",
      note: gutscheinForm.note,
    };

    const updatedKunde = { ...selectedKunde, gutscheine: [g, ...selectedKunde.gutscheine] };
    setKunden(prev => prev.map(k => k.id === selectedKunde.id ? updatedKunde : k));
    setSelectedKunde(updatedKunde);
    setGutscheinForm({ partnerId: "", tierId: "", expiresAt: "", note: "" });
    setShowAddGutschein(false);
  };

  const markEingeloest = (kundeId: string, gutscheinId: string) => {
    setKunden(prev => prev.map(k => {
      if (k.id !== kundeId) return k;
      const updated = {
        ...k,
        gutscheine: k.gutscheine.map(g =>
          g.id === gutscheinId ? { ...g, status: "eingeloest" as const } : g
        )
      };
      if (selectedKunde?.id === kundeId) setSelectedKunde(updated);
      return updated;
    }));
  };

  const deleteGutschein = (kundeId: string, gutscheinId: string) => {
    if (!confirm("Gutschein löschen?")) return;
    setKunden(prev => prev.map(k => {
      if (k.id !== kundeId) return k;
      const updated = { ...k, gutscheine: k.gutscheine.filter(g => g.id !== gutscheinId) };
      if (selectedKunde?.id === kundeId) setSelectedKunde(updated);
      return updated;
    }));
  };

  const statusBadge = (status: Gutschein["status"]) => {
    switch (status) {
      case "aktiv": return "bg-green-50 text-green-600 border border-green-200";
      case "eingeloest": return "bg-gray-100 text-gray-500 border border-gray-200";
      case "abgelaufen": return "bg-red-50 text-red-400 border border-red-200";
    }
  };

  const statusLabel = (status: Gutschein["status"]) => {
    switch (status) {
      case "aktiv": return "Aktiv";
      case "eingeloest": return "Eingelöst";
      case "abgelaufen": return "Abgelaufen";
    }
  };

  // ── Render ────────────────────────────────────
  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Kunden & Gutscheine</h1>
          <p className="text-sm text-gray-500 mt-1">{kunden.length} Kunden · {kunden.reduce((n, k) => n + k.gutscheine.filter(g => g.status === "aktiv").length, 0)} aktive Gutscheine</p>
        </div>
        <button
          onClick={() => setShowAddKunde(true)}
          className="bg-[#E63946] text-white px-4 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-red-500/20"
        >
          <Plus size={16} />
          Neuer Kunde
        </button>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Name, E-Mail oder Telefon suchen..."
          className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
        />
      </div>

      {/* Two-column layout: list + detail */}
      <div className="flex gap-4 items-start">
        {/* Customer List */}
        <div className="flex-1 space-y-2 min-w-0">
          {filteredKunden.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 p-10 text-center text-gray-400 text-sm">
              Keine Kunden gefunden.
            </div>
          )}
          {filteredKunden.map(k => {
            const activeGutscheine = k.gutscheine.filter(g => g.status === "aktiv").length;
            const isSelected = selectedKunde?.id === k.id;
            return (
              <button
                key={k.id}
                onClick={() => setSelectedKunde(isSelected ? null : k)}
                className={`w-full text-left rounded-2xl border p-4 transition-all ${
                  isSelected
                    ? "bg-red-50 border-[#E63946]"
                    : "bg-white border-gray-100 hover:border-gray-300"
                } shadow-sm`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <User size={18} className="text-gray-500" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-sm truncate">{k.name}</p>
                      <p className="text-xs text-gray-500 truncate">{k.email || k.phone || "–"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {activeGutscheine > 0 && (
                      <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {activeGutscheine} aktiv
                      </span>
                    )}
                    <button
                      onClick={e => { e.stopPropagation(); deleteKunde(k.id); }}
                      className="p-1.5 hover:bg-red-50 rounded-lg text-red-300 hover:text-red-500"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
                {k.note && <p className="text-[10px] text-gray-400 mt-1.5 pl-13">{k.note}</p>}
              </button>
            );
          })}
        </div>

        {/* Detail Panel */}
        {selectedKunde && (
          <div className="w-80 flex-shrink-0 bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden sticky top-0">
            {/* Kunde Info */}
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
              <div>
                <p className="font-black text-sm">{selectedKunde.name}</p>
                {selectedKunde.email && <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5"><Mail size={10} /> {selectedKunde.email}</p>}
                {selectedKunde.phone && <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5"><Phone size={10} /> {selectedKunde.phone}</p>}
              </div>
              <button onClick={() => setSelectedKunde(null)} className="p-1 hover:bg-gray-100 rounded-lg">
                <X size={16} />
              </button>
            </div>

            {/* Voucher Header */}
            <div className="px-4 pt-3 pb-2 flex items-center justify-between">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">Gutscheine</p>
              <button
                onClick={() => setShowAddGutschein(true)}
                className="text-[#E63946] text-xs font-bold flex items-center gap-1 hover:underline"
              >
                <Plus size={12} /> Hinzufügen
              </button>
            </div>

            {/* Vouchers */}
            <div className="px-4 pb-4 space-y-2 max-h-[60vh] overflow-y-auto">
              {selectedKunde.gutscheine.length === 0 && (
                <p className="text-xs text-gray-400 text-center py-4">Noch keine Gutscheine vergeben.</p>
              )}
              {selectedKunde.gutscheine.map(g => (
                <div key={g.id} className="rounded-xl border border-gray-100 p-3 bg-gray-50">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold truncate">{g.tierTitle}</p>
                      <p className="text-[10px] text-gray-500 truncate">{g.partnerName}</p>
                      {g.note && <p className="text-[10px] text-gray-400 mt-0.5 italic">"{g.note}"</p>}
                      {g.expiresAt && (
                        <p className="text-[10px] text-gray-400 mt-0.5">
                          Läuft ab: {new Date(g.expiresAt).toLocaleDateString("de-DE")}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-1.5">
                      <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${statusBadge(g.status)}`}>
                        {statusLabel(g.status)}
                      </span>
                    </div>
                  </div>
                  {g.status === "aktiv" && (
                    <div className="flex gap-1.5 mt-2">
                      <button
                        onClick={() => markEingeloest(selectedKunde.id, g.id)}
                        className="flex-1 py-1.5 bg-green-500 text-white rounded-lg text-[10px] font-bold flex items-center justify-center gap-1"
                      >
                        <CheckCircle2 size={10} /> Eingelöst
                      </button>
                      <button
                        onClick={() => deleteGutschein(selectedKunde.id, g.id)}
                        className="p-1.5 hover:bg-red-50 rounded-lg text-red-400"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── MODAL: Neuer Kunde ────────────────── */}
      {showAddKunde && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-black">Neuer Kunde</h2>
              <button onClick={() => setShowAddKunde(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Name *</label>
                <input
                  value={newKunde.name}
                  onChange={e => setNewKunde(f => ({ ...f, name: e.target.value }))}
                  placeholder="Max Mustermann"
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">E-Mail</label>
                <input
                  type="email"
                  value={newKunde.email}
                  onChange={e => setNewKunde(f => ({ ...f, email: e.target.value }))}
                  placeholder="max@example.com"
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Telefon</label>
                <input
                  value={newKunde.phone}
                  onChange={e => setNewKunde(f => ({ ...f, phone: e.target.value }))}
                  placeholder="+49 171 ..."
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Notiz</label>
                <input
                  value={newKunde.note}
                  onChange={e => setNewKunde(f => ({ ...f, note: e.target.value }))}
                  placeholder="z.B. Stammkunde, kam über Instagram..."
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAddKunde(false)} className="flex-1 py-3 border rounded-xl font-bold text-sm">Abbrechen</button>
              <button onClick={addKunde} disabled={!newKunde.name.trim()} className="flex-1 py-3 bg-[#E63946] text-white rounded-xl font-bold text-sm shadow-lg disabled:opacity-50">
                Hinzufügen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ── MODAL: Gutschein vergeben ─────────── */}
      {showAddGutschein && selectedKunde && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-lg font-black">Gutschein vergeben</h2>
                <p className="text-xs text-gray-500">An: {selectedKunde.name}</p>
              </div>
              <button onClick={() => setShowAddGutschein(false)} className="p-2 hover:bg-gray-100 rounded-full"><X size={18} /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Partner *</label>
                <select
                  value={gutscheinForm.partnerId}
                  onChange={e => setGutscheinForm(f => ({ ...f, partnerId: e.target.value, tierId: "" }))}
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                >
                  <option value="">Partner wählen...</option>
                  {MOCK_PARTNERS.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>

              {selectedPartner && (
                <div>
                  <label className="text-xs font-bold text-gray-500 uppercase">Gutschein-Typ *</label>
                  <div className="mt-1 space-y-2">
                    {selectedPartner.tiers.map(tier => (
                      <button
                        key={tier.id}
                        onClick={() => setGutscheinForm(f => ({ ...f, tierId: tier.id }))}
                        className={`w-full p-3 rounded-xl border text-left transition-all text-sm ${
                          gutscheinForm.tierId === tier.id
                            ? "border-[#E63946] bg-red-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <p className="font-bold">{tier.title}</p>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            tier.type === "premium"
                              ? "bg-pink-100 text-pink-600"
                              : "bg-green-100 text-green-600"
                          }`}>{tier.type}</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-0.5">{tier.description}</p>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Ablaufdatum (optional)</label>
                <input
                  type="date"
                  value={gutscheinForm.expiresAt}
                  onChange={e => setGutscheinForm(f => ({ ...f, expiresAt: e.target.value }))}
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Notiz (optional)</label>
                <input
                  value={gutscheinForm.note}
                  onChange={e => setGutscheinForm(f => ({ ...f, note: e.target.value }))}
                  placeholder="z.B. Geburtstags-Gutschein"
                  className="w-full mt-1 p-3 border rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setShowAddGutschein(false)} className="flex-1 py-3 border rounded-xl font-bold text-sm">Abbrechen</button>
              <button
                onClick={addGutschein}
                disabled={!gutscheinForm.partnerId || !gutscheinForm.tierId}
                className="flex-1 py-3 bg-[#E63946] text-white rounded-xl font-bold text-sm shadow-lg disabled:opacity-50"
              >
                Vergeben
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminKunden;
