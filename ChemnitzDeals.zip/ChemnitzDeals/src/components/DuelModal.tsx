import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, 
  Trophy, 
  Flame, 
  Clock, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  Gamepad2,
  Info,
  Gift,
  TrendingUp,
  MapPin,
  Sparkles
} from "lucide-react";
import { useUser } from "../context/UserContext";
import { useLanguage } from "../context/LanguageContext";
import { MOCK_PARTNERS, BRAND_COLORS, COIN_CONFIG } from "../constants";
import { Partner } from "../types";
import KarlMarxCoin from "./KarlMarxCoin";

interface DuelModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type Screen = "select" | "brief" | "game";

const CATEGORY_EMOJIS: Record<string, string> = {
  food: "🍔",
  cafe: "☕",
  fitness: "💪",
  shopping: "🛍️",
  beauty: "💅",
  culture: "🎭",
  entertainment: "🎮",
  services: "🔧"
};

const TicTacToe: React.FC<{ 
  onFinish: (result: "win" | "draw" | "lose") => void,
  partnerName: string
}> = ({ onFinish, partnerName }) => {
  const [board, setBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [isPlayerTurn, setIsPlayerTurn] = useState(true);
  const [winner, setWinner] = useState<string | null>(null);
  const [winLine, setWinLine] = useState<number[] | null>(null);
  const [isAiThinking, setIsAiThinking] = useState(false);

  const checkWinner = useCallback((currentBoard: (string | null)[]) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
      [0, 3, 6], [1, 4, 7], [2, 5, 8], // cols
      [0, 4, 8], [2, 4, 6]             // diags
    ];
    for (const [a, b, c] of lines) {
      if (currentBoard[a] && currentBoard[a] === currentBoard[b] && currentBoard[a] === currentBoard[c]) {
        return { winner: currentBoard[a], line: [a, b, c] };
      }
    }
    return null;
  }, []);

  const makeAiMove = useCallback(() => {
    setIsAiThinking(true);
    setTimeout(() => {
      const newBoard = [...board];
      const lines = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8],
        [0, 3, 6], [1, 4, 7], [2, 5, 8],
        [0, 4, 8], [2, 4, 6]
      ];

      const findBestMove = (symbol: string) => {
        for (const [a, b, c] of lines) {
          const vals = [newBoard[a], newBoard[b], newBoard[c]];
          if (vals.filter(v => v === symbol).length === 2 && vals.filter(v => v === null).length === 1) {
            return [a, b, c].find(idx => newBoard[idx] === null);
          }
        }
        return null;
      };

      // 1. Win
      let move = findBestMove("O");
      // 2. Block
      if (move === undefined || move === null) move = findBestMove("X");
      // 3. Center
      if ((move === undefined || move === null) && newBoard[4] === null) move = 4;
      // 4. Corners
      if (move === undefined || move === null) {
        const corners = [0, 2, 6, 8].filter(idx => newBoard[idx] === null);
        if (corners.length > 0) move = corners[Math.floor(Math.random() * corners.length)];
      }
      // 5. Random
      if (move === undefined || move === null) {
        const available = newBoard.map((v, i) => v === null ? i : null).filter(v => v !== null);
        if (available.length > 0) move = available[Math.floor(Math.random() * available.length)] as number;
      }

      if (move !== null && move !== undefined) {
        newBoard[move] = "O";
        setBoard(newBoard);
        const res = checkWinner(newBoard);
        if (res) {
          setWinner(res.winner);
          setWinLine(res.line);
          setTimeout(() => onFinish("lose"), 1500);
        } else if (newBoard.every(v => v !== null)) {
          setWinner("draw");
          setTimeout(() => onFinish("draw"), 1500);
        } else {
          setIsPlayerTurn(true);
        }
      }
      setIsAiThinking(false);
    }, 600);
  }, [board, checkWinner, onFinish]);

  useEffect(() => {
    if (!isPlayerTurn && !winner) {
      makeAiMove();
    }
  }, [isPlayerTurn, winner, makeAiMove]);

  const handleCellClick = (index: number) => {
    if (board[index] || !isPlayerTurn || winner) return;

    const newBoard = [...board];
    newBoard[index] = "X";
    setBoard(newBoard);
    
    const res = checkWinner(newBoard);
    if (res) {
      setWinner(res.winner);
      setWinLine(res.line);
      setTimeout(() => onFinish("win"), 1500);
    } else if (newBoard.every(v => v !== null)) {
      setWinner("draw");
      setTimeout(() => onFinish("draw"), 1500);
    } else {
      setIsPlayerTurn(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-8">
      <div className="flex flex-col items-center gap-2 text-center">
        <h3 className="text-xl font-black text-text-primary tracking-tight">Tic-Tac-Toe</h3>
        <p className="text-xs font-bold text-text-secondary uppercase tracking-widest">
          {isAiThinking ? "AI überlegt..." : isPlayerTurn ? "Du bist dran (X)" : `${partnerName} ist dran (O)`}
        </p>
      </div>

      <div className="grid grid-cols-3 gap-3 bg-secondary p-3 rounded-[32px] border border-border shadow-inner">
        {board.map((cell, i) => (
          <motion.button
            key={i}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleCellClick(i)}
            className={`w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-black transition-all ${
              winLine?.includes(i) ? "bg-yellow-400 text-white shadow-lg" : "bg-white text-text-primary shadow-sm"
            }`}
          >
            {cell === "X" && <span className="text-blue-500">X</span>}
            {cell === "O" && <span className="text-[#E63946]">O</span>}
          </motion.button>
        ))}
      </div>

      {isAiThinking && (
        <motion.div 
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ repeat: Infinity, duration: 1 }}
          className="flex items-center gap-2 text-[#E63946] font-black text-[10px] uppercase tracking-widest"
        >
          <div className="w-2 h-2 rounded-full bg-[#E63946]" />
          AI überlegt...
        </motion.div>
      )}
    </div>
  );
};

const DuelModal: React.FC<DuelModalProps> = ({ isOpen, onClose }) => {
  const { user, addCoins, incrementDuelCount } = useUser();
  const { t } = useLanguage();
  const [screen, setScreen] = useState<Screen>("select");
  const [selectedPartner, setSelectedPartner] = useState<Partner | null>(null);
  const [countdown, setCountdown] = useState(15);
  const [dailyDuels, setDailyDuels] = useState(0);
  const [winStreak, setWinStreak] = useState(0);
  const [result, setResult] = useState<{ type: "win" | "draw" | "lose", coins: number, jackpot: boolean, bonus: number } | null>(null);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (screen === "brief" && countdown > 0) {
      timer = setInterval(() => setCountdown(prev => prev - 1), 1000);
    }
    return () => clearInterval(timer);
  }, [screen, countdown]);

  const handlePartnerSelect = (partner: Partner) => {
    if (dailyDuels >= 5) return;
    setSelectedPartner(partner);
    setCountdown(15);
    setScreen("brief");
  };

  const handleGameFinish = (res: "win" | "draw" | "lose") => {
    let coins = 0;
    let jackpot = false;
    let bonus = 0;

    if (res === "win") {
      coins = Math.floor(Math.random() * (COIN_CONFIG.DUEL_WIN_MAX - COIN_CONFIG.DUEL_WIN_MIN + 1)) + COIN_CONFIG.DUEL_WIN_MIN;
      jackpot = Math.random() < 0.08;
      if (jackpot) coins += 50;
      if (winStreak >= 2) bonus = 5;
      setWinStreak(prev => prev + 1);
      addCoins(coins + bonus, `Duell gewonnen! 🏆`);
      incrementDuelCount();
    } else if (res === "draw") {
      coins = Math.floor(Math.random() * (COIN_CONFIG.DUEL_DRAW_MAX - COIN_CONFIG.DUEL_DRAW_MIN + 1)) + COIN_CONFIG.DUEL_DRAW_MIN;
      addCoins(coins, `Duell unentschieden 🤝`);
      incrementDuelCount();
    } else {
      coins = Math.floor(Math.random() * 3) + 1;
      setWinStreak(0);
      // Lose coins are motivation, not credited as per request (or small credit, I'll skip for now as per "Motivation")
    }

    setResult({ type: res, coins, jackpot, bonus });
    setDailyDuels(prev => prev + 1);
  };

  const resetDuel = () => {
    setResult(null);
    setScreen("select");
    setSelectedPartner(null);
  };

  const renderSelect = () => (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xl font-black text-text-primary tracking-tight">Wähle dein Team</h3>
          <div className="flex gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <div 
                key={i} 
                className={`w-2 h-2 rounded-full ${i < dailyDuels ? "bg-[#E63946]" : "bg-gray-200"}`} 
              />
            ))}
          </div>
        </div>
        <p className="text-xs font-medium text-text-secondary">
          Spiele für einen lokalen Partner und gewinne Coins! (Limit: 5/Tag)
        </p>
      </div>

      {winStreak >= 2 && (
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-red-50 border border-red-100 p-3 rounded-2xl flex items-center gap-3"
        >
          <Flame size={20} className="text-[#E63946]" />
          <span className="text-[10px] font-black text-[#E63946] uppercase tracking-widest">
            🔥 {winStreak}er Siegesserie – Bonus aktiv (+30 Coins)
          </span>
        </motion.div>
      )}

      <div className="grid grid-cols-2 gap-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
        {MOCK_PARTNERS.map(partner => (
          <button
            key={partner.id}
            disabled={dailyDuels >= 5}
            onClick={() => handlePartnerSelect(partner)}
            className={`p-4 rounded-3xl border-2 transition-all flex flex-col items-center gap-3 text-center ${
              dailyDuels >= 5 ? "opacity-50 grayscale cursor-not-allowed" : "hover:border-[#E63946] border-border bg-white"
            }`}
          >
            <span className="text-3xl">{CATEGORY_EMOJIS[partner.category] || "📍"}</span>
            <div className="flex flex-col">
              <span className="text-xs font-black text-text-primary truncate w-full">{partner.name}</span>
              <span className="text-[8px] font-bold text-text-secondary uppercase tracking-widest">{partner.category}</span>
            </div>
          </button>
        ))}
      </div>

      {dailyDuels >= 5 && (
        <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex gap-3">
          <AlertCircle size={20} className="text-amber-600 shrink-0" />
          <p className="text-[10px] font-bold text-amber-700 leading-tight">
            Du hast dein tägliches Limit von 5 Duellen erreicht. Komm morgen wieder für neue Belohnungen!
          </p>
        </div>
      )}
    </div>
  );

  const renderBrief = () => (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col items-center text-center gap-4">
        <span className="text-5xl">{CATEGORY_EMOJIS[selectedPartner?.category || ""] || "📍"}</span>
        <div className="flex flex-col gap-1">
          <h3 className="text-2xl font-black text-text-primary tracking-tight">{selectedPartner?.name}</h3>
          <div className="flex items-center justify-center gap-1 text-text-secondary">
            <MapPin size={12} />
            <span className="text-[10px] font-bold uppercase tracking-widest">{selectedPartner?.location}</span>
          </div>
        </div>
        <p className="text-sm font-medium text-text-secondary leading-relaxed italic px-4">
          "{selectedPartner?.description}"
        </p>
      </div>

      <div className="bg-secondary rounded-[32px] p-6 flex flex-col gap-4 border border-border">
        <div className="flex items-center gap-2 text-[#E63946]">
          <Info size={16} />
          <span className="text-[10px] font-black uppercase tracking-widest">Schon gewusst?</span>
        </div>
        <ul className="flex flex-col gap-3">
          {selectedPartner?.briefFacts?.map((fact, i) => (
            <li key={i} className="flex gap-3 text-xs font-bold text-text-primary leading-tight">
              <div className="w-1.5 h-1.5 rounded-full bg-[#E63946] mt-1.5 shrink-0" />
              {fact}
            </li>
          ))}
        </ul>
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between px-2">
          <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">Deine Belohnung</span>
          <div className="flex items-center gap-1">
            <Gift size={12} className="text-amber-500" />
            <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Wenn du gewinnst</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {selectedPartner?.tiers.slice(0, 2).map(tier => (
            <div key={tier.id} className="bg-white border border-border p-3 rounded-2xl flex flex-col gap-1">
              <span className="text-[8px] font-black text-[#E63946] uppercase tracking-widest">{tier.title}</span>
              <span className="text-[10px] font-medium text-text-secondary line-clamp-1">{tier.description}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <button
          disabled={countdown > 0}
          onClick={() => setScreen("game")}
          className={`w-full py-5 rounded-2xl font-black uppercase tracking-widest shadow-lg transition-all flex items-center justify-center gap-3 ${
            countdown > 0 
              ? "bg-gray-100 text-gray-400 border border-gray-200" 
              : "bg-[#E63946] text-white shadow-red-500/20 animate-pulse"
          }`}
        >
          <Gamepad2 size={20} />
          {countdown > 0 ? `Bitte ${countdown}s lesen...` : `Für ${selectedPartner?.name} spielen!`}
        </button>
      </div>
    </div>
  );

  const renderResult = () => (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center gap-8"
    >
      <div className="flex flex-col items-center gap-4">
        <div className={`w-24 h-24 rounded-full flex items-center justify-center text-white shadow-xl ${
          result?.type === "win" ? "bg-green-500" : result?.type === "draw" ? "bg-amber-500" : "bg-[#E63946]"
        }`}>
          {result?.type === "win" ? <Trophy size={48} /> : result?.type === "draw" ? <TrendingUp size={48} /> : <AlertCircle size={48} />}
        </div>
        <div className="flex flex-col gap-1">
          <h3 className="text-3xl font-black text-text-primary tracking-tight uppercase">
            {result?.type === "win" ? "Sieg!" : result?.type === "draw" ? "Unentschieden" : "Verloren"}
          </h3>
          <p className="text-sm font-bold text-text-secondary">
            {result?.type === "win" ? "Großartige Leistung!" : result?.type === "draw" ? "Ein faires Duell!" : "So knapp! Revanche?"}
          </p>
        </div>
      </div>

      <div className="bg-secondary rounded-[32px] p-8 w-full flex flex-col gap-4 border border-border">
        <div className="flex flex-col items-center gap-2">
          <span className="text-[10px] font-black text-text-secondary uppercase tracking-widest">Gewonnene Coins</span>
          <div className="flex items-center gap-3">
            <span className="text-4xl font-black text-text-primary">{result?.coins}</span>
            <KarlMarxCoin size={32} />
          </div>
        </div>

        {(result?.jackpot || result?.bonus > 0) && (
          <div className="flex flex-col gap-2 pt-4 border-t border-border">
            {result.jackpot && (
              <div className="flex items-center justify-center gap-2 text-amber-500 font-black text-xs uppercase tracking-widest">
                <Sparkles size={16} />
                Jackpot Bonus! (+200)
              </div>
            )}
            {result.bonus > 0 && (
              <div className="flex items-center justify-center gap-2 text-[#E63946] font-black text-xs uppercase tracking-widest">
                <Flame size={16} />
                Streak Bonus! (+30)
              </div>
            )}
          </div>
        )}
      </div>

      <div className="flex flex-col gap-3 w-full">
        <button
          onClick={() => {
            setResult(null);
            setCountdown(5);
            setScreen("brief");
          }}
          className="w-full bg-[#E63946] text-white py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-red-500/20"
        >
          {result?.type === "lose" ? "Revanche!" : "Nochmal spielen"}
        </button>
        <button
          onClick={resetDuel}
          className="w-full bg-white text-text-primary border-2 border-border py-4 rounded-2xl font-black uppercase tracking-widest"
        >
          Anderes Team
        </button>
      </div>
    </motion.div>
  );

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[110]"
          />
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 bg-white rounded-t-[40px] p-8 z-[120] max-h-[90vh] overflow-y-auto"
          >
            <div className="flex justify-center mb-6">
              <div className="w-12 h-1.5 bg-gray-200 rounded-full" />
            </div>

            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center text-[#E63946]">
                  <Gamepad2 size={20} />
                </div>
                <h2 className="text-xl font-black text-text-primary tracking-tight">Team-Duell</h2>
              </div>
              <button onClick={onClose} className="p-2 hover:bg-secondary rounded-full">
                <X size={24} />
              </button>
            </div>

            <div className="relative min-h-[400px]">
              {screen === "select" && renderSelect()}
              {screen === "brief" && renderBrief()}
              {screen === "game" && (
                <TicTacToe 
                  partnerName={selectedPartner?.name || "AI"} 
                  onFinish={handleGameFinish} 
                />
              )}
              {result && renderResult()}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default DuelModal;
