import React, { useState } from "react";
import { Plus, Edit2, Trash2, X, AlertCircle, ChevronDown, ChevronUp } from "lucide-react";
import { LevelDefinition, LevelChallenge, ChallengeType, Category } from "../types";
import { MOCK_LEVELS, MOCK_PARTNERS } from "../constants";

const CHALLENGE_TYPES: { value: ChallengeType; label: string }[] = [
  { value: "visit", label: "Besuch" },
  { value: "multi_visit", label: "Multi-Besuch" },
  { value: "story", label: "Story posten" },
  { value: "review", label: "Bewertung" },
  { value: "social", label: "Social Follow" },
  { value: "streak", label: "Streak" },
  { value: "explore_category", label: "Kategorie erkunden" },
  { value: "spend_coins", label: "Coins ausgeben" },
];

const DIFFICULTY_OPTIONS: { value: 1 | 2 | 3; label: string }[] = [
  { value: 1, label: "⭐ Leicht" },
  { value: 2, label: "⭐⭐ Mittel" },
  { value: 3, label: "⭐⭐⭐ Schwer" },
];

const AdminActivities: React.FC = () => {
  const [levels, setLevels] = useState<LevelDefinition[]>(MOCK_LEVELS);
  const [expandedLevel, setExpandedLevel] = useState<number | null>(1);
  const [editingChallenge, setEditingChallenge] = useState<LevelChallenge | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalLevel, setModalLevel] = useState(1);

  const [form, setForm] = useState({
    title: "",
    description: "",
    challengeType: "visit" as ChallengeType,
    icon: "📍",
    reward: 15,
    partnerId: "",
    partnerCategory: "" as Category | "",
    maxProgress: 1,
    coinPowerBonus: 3,
    difficulty: 1 as 1 | 2 | 3,
  });

  const openCreate = (level: number) => {
    setEditingChallenge(null);
    setModalLevel(level);
    setForm({
      title: "", description: "", challengeType: "visit", icon: "📍",
      reward: 15, partnerId: "", partnerCategory: "", maxProgress: 1,
      coinPowerBonus: 3, difficulty: 1,
    });
    setIsModalOpen(true);
  };

  const openEdit = (challenge: LevelChallenge) => {
    setEditingChallenge(challenge);
    setModalLevel(challenge.level);
    setForm({
      title: challenge.title,
      description: challenge.description,
      challengeType: challenge.challengeType,
      icon: challenge.icon,
      reward: challenge.reward,
      partnerId: challenge.partnerId || "",
      partnerCategory: challenge.partnerCategory || "",
      maxProgress: challenge.maxProgress,
      coinPowerBonus: challenge.coinPowerBonus,
      difficulty: challenge.difficulty,
    });
    setIsModalOpen(true);
  };

  const handleSave = () => {
    setLevels(prev => prev.map(lvl => {
      if (lvl.level !== modalLevel) return lvl;

      if (editingChallenge) {
        return {
          ...lvl,
          challenges: lvl.challenges.map(c =>
            c.id === editingChallenge.id
              ? {
                  ...c,
                  ...form,
                  partnerId: form.partnerId || undefined,
                  partnerCategory: (form.partnerCategory || undefined) as Category | undefined,
                }
              : c
          )
        };
      } else {
        const newChallenge: LevelChallenge = {
          id: `lc${Date.now()}`,
          ...form,
          partnerId: form.partnerId || undefined,
          partnerCategory: (form.partnerCategory || undefined) as Category | undefined,
          progress: 0,
          status: lvl.level === 1 ? "active" : "locked",
          level: modalLevel,
        };
        return { ...lvl, challenges: [...lvl.challenges, newChallenge] };
      }
    }));
    setIsModalOpen(false);
  };

  const handleDelete = (levelNum: number, challengeId: string) => {
    if (confirm("Challenge wirklich löschen?")) {
      setLevels(prev => prev.map(lvl =>
        lvl.level === levelNum
          ? { ...lvl, challenges: lvl.challenges.filter(c => c.id !== challengeId) }
          : lvl
      ));
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Level-Challenges</h1>
          <p className="text-sm text-gray-500 mt-1">Partner-Visit-Challenges pro Level verwalten</p>
        </div>
      </div>

      {/* Economy Info */}
      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
        <div className="flex items-start gap-3">
          <AlertCircle size={20} className="text-blue-500 mt-0.5" />
          <div>
            <h3 className="font-bold text-sm text-blue-800">Challenge-Economy</h3>
            <p className="text-xs text-blue-700 mt-1">
              Alle Challenges drehen sich um <strong>Partner-Besuche, Stories, Reviews und Social Actions</strong>.
              Jede Challenge gibt Coins + CoinPower. Höhere Difficulty = höhere Belohnung.
            </p>
            <div className="mt-2 grid grid-cols-3 gap-2 text-[10px]">
              <div className="bg-white/60 rounded-lg p-2">
                <p className="font-bold">⭐ Leicht</p>
                <p>10-20 Coins</p>
              </div>
              <div className="bg-white/60 rounded-lg p-2">
                <p className="font-bold">⭐⭐ Mittel</p>
                <p>25-50 Coins</p>
              </div>
              <div className="bg-white/60 rounded-lg p-2">
                <p className="font-bold">⭐⭐⭐ Schwer</p>
                <p>50-100 Coins</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Level Accordion */}
      <div className="space-y-3">
        {levels.map(lvl => (
          <div key={lvl.level} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            {/* Level Header */}
            <button
              onClick={() => setExpandedLevel(expandedLevel === lvl.level ? null : lvl.level)}
              className="w-full flex items-center justify-between p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{lvl.icon}</span>
                <div className="text-left">
                  <h3 className="font-bold text-sm">Level {lvl.level}: {lvl.title}</h3>
                  <p className="text-xs text-gray-500">
                    {lvl.challenges.length} Challenges · Ab Level {lvl.requiredLevel}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => { e.stopPropagation(); openCreate(lvl.level); }}
                  className="bg-[#E63946] text-white p-1.5 rounded-lg"
                >
                  <Plus size={14} />
                </button>
                {expandedLevel === lvl.level ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
              </div>
            </button>

            {/* Challenges Table */}
            {expandedLevel === lvl.level && (
              <div className="border-t border-gray-100">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-50">
                      <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Challenge</th>
                      <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Typ</th>
                      <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Coins</th>
                      <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">CP+</th>
                      <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Diff</th>
                      <th className="text-right p-3 text-[10px] font-bold text-gray-400 uppercase">Aktionen</th>
                    </tr>
                  </thead>
                  <tbody>
                    {lvl.challenges.map(ch => (
                      <tr key={ch.id} className="border-b border-gray-50 hover:bg-gray-50">
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{ch.icon}</span>
                            <div>
                              <p className="font-bold text-xs">{ch.title}</p>
                              <p className="text-[10px] text-gray-500">{ch.description}</p>
                            </div>
                          </div>
                        </td>
                        <td className="p-3">
                          <span className="text-[10px] font-mono bg-gray-100 px-1.5 py-0.5 rounded">
                            {ch.challengeType}
                          </span>
                        </td>
                        <td className="p-3 text-xs font-bold">{ch.reward}</td>
                        <td className="p-3 text-xs font-bold text-yellow-600">+{ch.coinPowerBonus}</td>
                        <td className="p-3 text-xs">{"⭐".repeat(ch.difficulty)}</td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            <button onClick={() => openEdit(ch)} className="p-1.5 hover:bg-gray-100 rounded-lg">
                              <Edit2 size={14} className="text-gray-500" />
                            </button>
                            <button onClick={() => handleDelete(lvl.level, ch.id)} className="p-1.5 hover:bg-red-50 rounded-lg">
                              <Trash2 size={14} className="text-red-400" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                    {lvl.challenges.length === 0 && (
                      <tr>
                        <td colSpan={6} className="p-6 text-center text-sm text-gray-400">
                          Noch keine Challenges. Klicke + um eine zu erstellen.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Edit/Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-black">
                {editingChallenge ? "Challenge bearbeiten" : `Neue Challenge (Level ${modalLevel})`}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-600 uppercase">Titel</label>
                <input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                  className="w-full mt-1 p-3 border rounded-xl text-sm" placeholder="z.B. Döner testen" />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-600 uppercase">Beschreibung</label>
                <input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  className="w-full mt-1 p-3 border rounded-xl text-sm" placeholder="z.B. Check-in beim Döner Palace" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase">Challenge-Typ</label>
                  <select value={form.challengeType} onChange={e => setForm(f => ({ ...f, challengeType: e.target.value as ChallengeType }))}
                    className="w-full mt-1 p-3 border rounded-xl text-sm">
                    {CHALLENGE_TYPES.map(ct => (
                      <option key={ct.value} value={ct.value}>{ct.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase">Schwierigkeit</label>
                  <select value={form.difficulty} onChange={e => setForm(f => ({ ...f, difficulty: Number(e.target.value) as 1 | 2 | 3 }))}
                    className="w-full mt-1 p-3 border rounded-xl text-sm">
                    {DIFFICULTY_OPTIONS.map(d => (
                      <option key={d.value} value={d.value}>{d.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase">Icon</label>
                  <input value={form.icon} onChange={e => setForm(f => ({ ...f, icon: e.target.value }))}
                    className="w-full mt-1 p-3 border rounded-xl text-sm text-center text-2xl" />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase">Coins</label>
                  <input type="number" value={form.reward} onChange={e => setForm(f => ({ ...f, reward: Number(e.target.value) }))}
                    className="w-full mt-1 p-3 border rounded-xl text-sm" />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase">CoinPower</label>
                  <input type="number" value={form.coinPowerBonus} onChange={e => setForm(f => ({ ...f, coinPowerBonus: Number(e.target.value) }))}
                    className="w-full mt-1 p-3 border rounded-xl text-sm" />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-600 uppercase">Ziel (max. Fortschritt)</label>
                <input type="number" value={form.maxProgress} onChange={e => setForm(f => ({ ...f, maxProgress: Number(e.target.value) }))}
                  className="w-full mt-1 p-3 border rounded-xl text-sm" />
              </div>

              <div>
                <label className="text-xs font-bold text-gray-600 uppercase">Partner zuweisen (optional)</label>
                <select value={form.partnerId} onChange={e => setForm(f => ({ ...f, partnerId: e.target.value }))}
                  className="w-full mt-1 p-3 border rounded-xl text-sm">
                  <option value="">Beliebiger Partner</option>
                  {MOCK_PARTNERS.map(p => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button onClick={() => setIsModalOpen(false)}
                className="flex-1 py-3 border rounded-xl font-bold text-sm">Abbrechen</button>
              <button onClick={handleSave}
                className="flex-1 py-3 bg-[#E63946] text-white rounded-xl font-bold text-sm">Speichern</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminActivities;
