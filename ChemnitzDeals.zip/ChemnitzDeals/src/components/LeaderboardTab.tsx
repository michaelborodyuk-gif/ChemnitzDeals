import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Trophy, Swords, ArrowUp, ArrowDown, Minus, Search, UserPlus, Sparkles, Coins, Flame, Footprints, Gamepad2 } from "lucide-react";
import { useUser } from "../context/UserContext";
import { useLanguage } from "../context/LanguageContext";
import { MOCK_LEADERBOARD } from "../constants";
import ChemnitzMoji from "./ChemnitzMoji";
import KarlMarxCoin from "./KarlMarxCoin";
import DuelModal from "./DuelModal";
import StepDuelModal from "./StepDuelModal";

const LeaderboardTab: React.FC = () => {
  const { user, joinLeaderboard } = useUser();
  const { t } = useLanguage();
  const [activeSubTab, setActiveSubTab] = useState<"thisWeek" | "allTime">("thisWeek");
  const [isDuelOpen, setIsDuelOpen] = useState(false);
  const [isStepDuelOpen, setIsStepDuelOpen] = useState(false);
  const [showDuelPicker, setShowDuelPicker] = useState(false);

  const topThree = MOCK_LEADERBOARD.slice(0, 3);
  const others = MOCK_LEADERBOARD.slice(3);

  if (!user.leaderboardJoined) {
    return (
      <div className="px-6 py-12 flex flex-col items-center text-center gap-8 max-w-md mx-auto">
        <div className="w-24 h-24 rounded-full bg-red-50 flex items-center justify-center text-[#E63946]">
          <Trophy size={48} />
        </div>
        <div className="flex flex-col gap-2">
          <h2 className="text-2xl font-black text-text-primary tracking-tight">
            {t("joinLeaderboard")}
          </h2>
          <p className="text-xs font-medium text-text-secondary leading-relaxed">
            {t("leaderboardDescription")}
          </p>
        </div>
        <button 
          onClick={joinLeaderboard}
          className="bg-[#E63946] text-white w-full py-4 rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
        >
          <UserPlus size={20} />
          {t("joinLeaderboard")}
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-full">
      {/* Header & Sub-tabs */}
      <div className="px-6 pt-8 pb-4 flex flex-col gap-6 sticky top-16 bg-white/80 backdrop-blur-md z-40 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-black text-text-primary tracking-tight">
            {t("leaderboard")}
          </h2>
          <button
            onClick={() => setShowDuelPicker(true)}
            className="bg-[#E63946] text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-500/20 flex items-center gap-2"
          >
            <Swords size={14} />
            {t("duel")}
          </button>
        </div>

        <div className="flex gap-2 p-1 bg-secondary rounded-2xl border border-border">
          {(["thisWeek", "allTime"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveSubTab(tab)}
              className={`flex-1 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                activeSubTab === tab ? "bg-white text-text-primary shadow-sm" : "text-text-secondary"
              }`}
            >
              {t(tab)}
            </button>
          ))}
        </div>
      </div>

      {/* Podium */}
      <div className="px-6 py-8 flex items-end justify-center gap-4 max-w-md mx-auto w-full">
        {/* 2nd Place */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="flex flex-col items-center gap-2 flex-1"
        >
          <div className="w-16 h-16 rounded-full bg-white border-4 border-gray-200 shadow-lg flex items-center justify-center overflow-hidden">
            <ChemnitzMoji config={topThree[1].moji} size={50} />
          </div>
          <div className="bg-gray-200 w-full h-24 rounded-t-2xl flex flex-col items-center justify-center p-2">
            <span className="text-xs font-black text-text-primary truncate w-full text-center">
              {topThree[1].username}
            </span>
            <span className="text-[10px] font-bold text-text-secondary">
              {topThree[1].coins}
            </span>
            <div className="mt-2 w-6 h-6 rounded-full bg-white text-[10px] font-black flex items-center justify-center">
              2
            </div>
          </div>
        </motion.div>

        {/* 1st Place */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="flex flex-col items-center gap-2 flex-1"
        >
          <div className="w-20 h-20 rounded-full bg-white border-4 border-yellow-400 shadow-xl flex items-center justify-center overflow-hidden relative">
            <ChemnitzMoji config={topThree[0].moji} size={60} />
            <div className="absolute -top-1 -right-1 bg-yellow-400 p-1 rounded-full text-white">
              <Trophy size={12} />
            </div>
          </div>
          <div className="bg-yellow-400 w-full h-32 rounded-t-2xl flex flex-col items-center justify-center p-2">
            <span className="text-xs font-black text-white truncate w-full text-center">
              {topThree[0].username}
            </span>
            <span className="text-[10px] font-bold text-white/90">
              {topThree[0].coins}
            </span>
            <div className="mt-2 w-8 h-8 rounded-full bg-white text-[12px] font-black text-yellow-500 flex items-center justify-center">
              1
            </div>
          </div>
        </motion.div>

        {/* 3rd Place */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="flex flex-col items-center gap-2 flex-1"
        >
          <div className="w-16 h-16 rounded-full bg-white border-4 border-orange-300 shadow-lg flex items-center justify-center overflow-hidden">
            <ChemnitzMoji config={topThree[2].moji} size={50} />
          </div>
          <div className="bg-orange-300 w-full h-20 rounded-t-2xl flex flex-col items-center justify-center p-2">
            <span className="text-xs font-black text-text-primary truncate w-full text-center">
              {topThree[2].username}
            </span>
            <span className="text-[10px] font-bold text-text-secondary">
              {topThree[2].coins}
            </span>
            <div className="mt-2 w-6 h-6 rounded-full bg-white text-[10px] font-black flex items-center justify-center">
              3
            </div>
          </div>
        </motion.div>
      </div>

      {/* List */}
      <div className="px-6 py-4 flex flex-col gap-3 max-w-md mx-auto w-full">
        {others.map((item, i) => (
          <motion.div
            key={item.username}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 + i * 0.1 }}
            className="bg-white rounded-2xl p-4 flex items-center justify-between border border-border"
          >
            <div className="flex items-center gap-4">
              <span className="text-xs font-black text-text-secondary w-4">
                {item.rank}
              </span>
              <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center overflow-hidden">
                <ChemnitzMoji config={item.moji} size={30} />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold text-text-primary">
                  {item.username}
                </span>
                <span className="text-[10px] font-bold text-text-secondary uppercase tracking-widest">
                  {item.quests} Quests
                </span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-black text-text-primary">
                {item.coins}
              </span>
              <KarlMarxCoin size={14} />
            </div>
          </motion.div>
        ))}
      </div>

      {/* Duel Type Picker */}
      <AnimatePresence>
        {showDuelPicker && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowDuelPicker(false)}
              className="fixed inset-0 bg-black/40 z-[60]"
            />
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed bottom-0 left-0 right-0 bg-white rounded-t-3xl z-[70] p-6 pb-10"
            >
              <div className="w-12 h-1.5 bg-gray-200 rounded-full mx-auto mb-6" />
              <h3 className="text-xl font-black mb-4 text-center">Duell-Modus wählen</h3>
              <div className="space-y-3">
                <button
                  onClick={() => { setShowDuelPicker(false); setIsStepDuelOpen(true); }}
                  className="w-full flex items-center gap-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-2xl border border-green-200"
                >
                  <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center">
                    <Footprints size={28} className="text-green-600" />
                  </div>
                  <div className="text-left flex-1">
                    <span className="font-black text-sm">Schritte-Duell</span>
                    <p className="text-xs text-gray-500">24h Schritte-Battle gegen einen Gegner</p>
                  </div>
                </button>
                <button
                  onClick={() => { setShowDuelPicker(false); setIsDuelOpen(true); }}
                  className="w-full flex items-center gap-4 p-4 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl border border-purple-200"
                >
                  <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center">
                    <Gamepad2 size={28} className="text-purple-600" />
                  </div>
                  <div className="text-left flex-1">
                    <span className="font-black text-sm">Partner-Duell</span>
                    <p className="text-xs text-gray-500">Tic-Tac-Toe für Coins</p>
                  </div>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Duel Modals */}
      <DuelModal isOpen={isDuelOpen} onClose={() => setIsDuelOpen(false)} />
      <StepDuelModal
        isOpen={isStepDuelOpen}
        onClose={() => setIsStepDuelOpen(false)}
        userBalance={user.balance}
        username={user.username}
        userMoji={user.mojiConfig}
        onDuelComplete={(won, coins) => {
          console.log("Step duel:", won ? "Won" : "Lost", coins);
        }}
      />

      <div className="h-20" />
    </div>
  );
};

export default LeaderboardTab;
