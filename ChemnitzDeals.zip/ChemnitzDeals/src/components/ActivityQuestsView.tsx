import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, ChevronRight, Lock, Check, ChevronLeft, Zap } from "lucide-react";
import { LevelDefinition, LevelChallenge } from "../types";
import { MOCK_LEVELS, MOCK_PARTNERS } from "../constants";
import KarlMarxCoin from "./KarlMarxCoin";

interface LevelChallengesViewProps {
  userLevel: number;
  coinPower: number;
  onComplete?: (challenge: LevelChallenge, coins: number) => void;
}

export default function LevelChallengesView({ userLevel, coinPower, onComplete }: LevelChallengesViewProps) {
  const [levels] = useState<LevelDefinition[]>(() =>
    MOCK_LEVELS.map(l => ({
      ...l,
      isUnlocked: l.requiredLevel <= userLevel,
      challenges: l.challenges.map(c => ({
        ...c,
        status: l.requiredLevel <= userLevel ? c.status === "locked" ? "active" as const : c.status : "locked" as const,
      }))
    }))
  );
  const [selectedLevel, setSelectedLevel] = useState<LevelDefinition | null>(null);
  const [selectedChallenge, setSelectedChallenge] = useState<LevelChallenge | null>(null);

  const getTypeColor = (type: string) => {
    switch (type) {
      case "visit": return "from-green-100 to-emerald-50";
      case "multi_visit": return "from-blue-100 to-cyan-50";
      case "story": return "from-pink-100 to-rose-50";
      case "review": return "from-yellow-100 to-amber-50";
      case "social": return "from-purple-100 to-violet-50";
      case "streak": return "from-orange-100 to-red-50";
      case "explore_category": return "from-teal-100 to-cyan-50";
      case "spend_coins": return "from-amber-100 to-yellow-50";
      default: return "from-gray-100 to-gray-50";
    }
  };

  const getTypeBgColor = (type: string) => {
    switch (type) {
      case "visit": return "bg-green-50";
      case "multi_visit": return "bg-blue-50";
      case "story": return "bg-pink-50";
      case "review": return "bg-yellow-50";
      case "social": return "bg-purple-50";
      case "streak": return "bg-orange-50";
      case "explore_category": return "bg-teal-50";
      case "spend_coins": return "bg-amber-50";
      default: return "bg-gray-50";
    }
  };

  const getPartnerName = (id?: string) => {
    if (!id) return "Beliebiger Partner";
    return MOCK_PARTNERS.find(p => p.id === id)?.name || "Partner";
  };

  // ========== LEVEL GRID (Bild 1: Challenges pro Level) ==========
  if (selectedLevel) {
    return (
      <>
        {/* Back + Level Header */}
        <div className="px-4 mb-4">
          <button onClick={() => { setSelectedLevel(null); setSelectedChallenge(null); }}
            className="flex items-center gap-1 text-xs font-bold text-gray-500 mb-3">
            <ChevronLeft size={16} /> Zurück
          </button>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-200 to-yellow-400 rounded-2xl flex items-center justify-center text-2xl shadow-sm">
              {selectedLevel.icon}
            </div>
            <div>
              <h2 className="font-black text-lg">Level {selectedLevel.level}: {selectedLevel.title}</h2>
              <p className="text-xs text-gray-500">{selectedLevel.description}</p>
            </div>
          </div>
        </div>

        {/* Inventory Banner */}
        <div className="mx-4 mb-4 bg-gradient-to-r from-[#FFFBEB] to-[#FEF3C7] rounded-2xl p-3 flex items-center gap-3 border border-yellow-200">
          <div className="w-10 h-10 bg-yellow-200 rounded-full flex items-center justify-center">
            <span className="text-lg font-black text-yellow-700">{coinPower}</span>
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-sm text-yellow-900">CoinPower</h3>
            <p className="text-[10px] text-yellow-700">Steigt mit jeder Challenge!</p>
          </div>
          <ChevronRight size={16} className="text-yellow-600" />
        </div>

        {/* Challenge Grid (Yu-style 2-column) */}
        <div className="grid grid-cols-2 gap-3 px-4">
          {selectedLevel.challenges.map((challenge) => {
            const isLocked = challenge.status === "locked";
            const isCompleted = challenge.status === "completed";

            return (
              <motion.button
                key={challenge.id}
                whileTap={{ scale: isLocked ? 1 : 0.96 }}
                onClick={() => !isLocked && setSelectedChallenge(challenge)}
                className={`relative bg-gradient-to-b ${getTypeColor(challenge.challengeType)} rounded-2xl p-4 text-left overflow-hidden border border-white/50 shadow-sm ${
                  isLocked ? "opacity-40" : ""
                } ${isCompleted ? "ring-2 ring-green-400" : ""}`}
              >
                {/* Icon */}
                <div className="text-4xl mb-3 mt-1">{challenge.icon}</div>

                {/* Title */}
                <h3 className="font-bold text-sm text-gray-900 leading-tight">{challenge.title}</h3>

                {/* Reward */}
                <div className="flex items-center gap-1 mt-2">
                  <span className="font-bold text-sm">{challenge.reward}</span>
                  <KarlMarxCoin size={14} />
                </div>

                {/* Locked Overlay */}
                {isLocked && (
                  <div className="absolute inset-0 bg-white/30 flex items-center justify-center">
                    <Lock size={24} className="text-gray-400" />
                  </div>
                )}
                {isCompleted && (
                  <div className="absolute top-2 left-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                    <Check size={14} className="text-white" />
                  </div>
                )}

                {/* Arrow */}
                {!isLocked && !isCompleted && (
                  <div className="absolute bottom-3 right-3 w-7 h-7 bg-[#E63946] rounded-full flex items-center justify-center">
                    <ChevronRight size={14} className="text-white" />
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* ========== CHALLENGE DETAIL (Bild 2: Detail-View) ========== */}
        <AnimatePresence>
          {selectedChallenge && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-[60]"
              onClick={() => setSelectedChallenge(null)}
            >
              <motion.div
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: "spring", damping: 25, stiffness: 300 }}
                className="absolute bottom-0 left-0 right-0 bg-white rounded-t-3xl max-h-[80vh] overflow-hidden"
                onClick={e => e.stopPropagation()}
              >
                {/* Header */}
                <div className="flex justify-between items-center p-4">
                  <button onClick={() => setSelectedChallenge(null)}>
                    <ChevronLeft size={20} className="text-gray-400" />
                  </button>
                  <h3 className="font-black text-lg">{selectedChallenge.title}</h3>
                  <button onClick={() => setSelectedChallenge(null)}>
                    <X size={20} className="text-gray-400" />
                  </button>
                </div>

                {/* Challenge Hero (like Yu Short Stroll) */}
                <div className={`mx-4 rounded-2xl ${getTypeBgColor(selectedChallenge.challengeType)} p-6 relative overflow-hidden`}>
                  {/* Decorative path */}
                  <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 300 150">
                    <path d="M 10 120 C 60 80, 100 130, 150 90 C 200 50, 240 110, 290 70"
                      stroke="#888" strokeWidth="3" strokeDasharray="8,6" fill="none" />
                    <circle cx="10" cy="120" r="6" fill="#E63946" />
                    <circle cx="290" cy="70" r="6" fill="#22C55E" />
                  </svg>

                  <div className="relative z-10 text-center">
                    <div className="text-6xl mb-2">{selectedChallenge.icon}</div>
                  </div>
                </div>

                {/* Stats Card */}
                <div className="mx-4 mt-4 bg-white rounded-xl border p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">{selectedChallenge.description}</p>
                      {selectedChallenge.partnerId && (
                        <p className="text-xs text-[#E63946] font-bold mt-1">
                          📍 {getPartnerName(selectedChallenge.partnerId)}
                        </p>
                      )}
                      <p className="text-xs text-gray-400 mt-1">
                        {selectedChallenge.progress}/{selectedChallenge.maxProgress}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-lg">{selectedChallenge.reward}</span>
                      <KarlMarxCoin size={18} />
                    </div>
                  </div>

                  {/* Difficulty Stars */}
                  <div className="flex items-center gap-1 mt-3">
                    {[1, 2, 3].map(s => (
                      <span key={s} className={`text-lg ${s <= selectedChallenge.difficulty ? "text-yellow-400" : "text-gray-300"}`}>★</span>
                    ))}
                  </div>
                </div>

                {/* CoinPower Banner */}
                {selectedChallenge.coinPowerBonus > 0 && (
                  <div className="mx-4 mt-3 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-2xl p-3 flex items-center gap-3">
                    <div className="w-10 h-10 bg-yellow-200 rounded-full flex items-center justify-center">
                      <Zap size={18} className="text-yellow-700" />
                    </div>
                    <div className="flex-1">
                      <span className="font-bold text-yellow-900 text-sm">+{selectedChallenge.coinPowerBonus} CoinPower</span>
                      <p className="text-[10px] text-yellow-800">Verbessert deine Challenge-Rewards!</p>
                    </div>
                    <ChevronRight size={16} className="text-yellow-700" />
                  </div>
                )}

                {/* Action Button */}
                <div className="p-4 pb-8">
                  {selectedChallenge.status === "completed" ? (
                    <div className="w-full py-4 bg-green-100 text-green-700 rounded-full text-center font-bold">
                      ✓ Abgeschlossen
                    </div>
                  ) : (
                    <motion.button
                      whileTap={{ scale: 0.96 }}
                      onClick={() => {
                        onComplete?.(selectedChallenge, selectedChallenge.reward);
                        setSelectedChallenge(null);
                      }}
                      className="w-full py-4 rounded-full font-bold text-white text-sm bg-[#E63946]"
                    >
                      Challenge annehmen
                    </motion.button>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </>
    );
  }

  // ========== LEVEL SELECTION (Node Map Levels → klick öffnet Challenges) ==========
  return (
    <div className="px-4 space-y-3">
      {levels.map((level) => {
        const completedCount = level.challenges.filter(c => c.status === "completed").length;
        const totalCount = level.challenges.length;
        const isLocked = !level.isUnlocked;

        return (
          <motion.button
            key={level.level}
            whileTap={{ scale: isLocked ? 1 : 0.98 }}
            onClick={() => !isLocked && setSelectedLevel(level)}
            className={`w-full flex items-center gap-4 p-4 rounded-2xl border transition-all text-left ${
              isLocked
                ? "bg-gray-50 border-gray-200 opacity-50"
                : completedCount === totalCount
                  ? "bg-green-50 border-green-200"
                  : "bg-white border-gray-200 hover:border-[#E63946] hover:shadow-sm"
            }`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-sm ${
              isLocked ? "bg-gray-200" : "bg-gradient-to-br from-yellow-200 to-yellow-400"
            }`}>
              {isLocked ? <Lock size={24} className="text-gray-400" /> : level.icon}
            </div>

            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-black text-sm">Level {level.level}</span>
                <span className="text-xs text-gray-500">· {level.title}</span>
              </div>
              <p className="text-xs text-gray-400 mt-0.5">{level.description}</p>

              {/* Progress bar */}
              {!isLocked && (
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#E63946] rounded-full transition-all"
                      style={{ width: `${(completedCount / totalCount) * 100}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-bold text-gray-500">{completedCount}/{totalCount}</span>
                </div>
              )}
            </div>

            {!isLocked && (
              <ChevronRight size={18} className="text-gray-400" />
            )}
          </motion.button>
        );
      })}
    </div>
  );
}
