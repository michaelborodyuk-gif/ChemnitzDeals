import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { motion, AnimatePresence, useMotionValue, animate, useTransform } from "motion/react";
import { Menu, Bell, Coins, Trophy, Gift, User, LayoutGrid, Map } from "lucide-react";
import Sidebar from "./components/Sidebar";
import YuCoinTab from "./components/YuCoinTab";
import QuestsTab from "./components/QuestsTab";
import RewardsTab from "./components/RewardsTab";
import ProfileTab from "./components/ProfileTab";
import LeaderboardTab from "./components/LeaderboardTab";
import Logo from "./components/Logo";
import KarlMarxCoin from "./components/KarlMarxCoin";
import { ThemeProvider } from "./context/ThemeContext";
import { LanguageProvider, useLanguage } from "./context/LanguageContext";
import { AuthProvider } from "./context/AuthContext";
import { UserProvider, useUser } from "./context/UserContext";

// Admin imports
import AdminLayout from "./admin/AdminLayout";
import AdminLogin from "./admin/AdminLogin";
import AdminDashboard from "./admin/AdminDashboard";
import AdminPartners from "./admin/AdminPartners";
import AdminRewards from "./admin/AdminRewards";
import AdminQuests from "./admin/AdminQuests";
import AdminUsers from "./admin/AdminUsers";
import AdminClaims from "./admin/AdminClaims";
import AdminPowerUps from "./admin/AdminPowerUps";
import AdminActivities from "./admin/AdminActivities";
import AdminKunden from "./admin/AdminKunden";
import OnboardingSlides from "./components/OnboardingSlides";

function UserAppContent() {
  const [showOnboarding, setShowOnboarding] = useState(() => {
    return !localStorage.getItem("chemnitz_deals_onboarded");
  });

  const handleOnboardingComplete = () => {
    localStorage.setItem("chemnitz_deals_onboarded", "true");
    setShowOnboarding(false);
  };

  const [activeTab, setActiveTab] = useState("coins");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { user } = useUser();
  const { t } = useLanguage();

  // Animation for balance
  const motionBalance = useMotionValue(user.balance);
  const displayBalance = useTransform(motionBalance, (latest: number) => Math.floor(latest));

  useEffect(() => {
    const controls = animate(motionBalance, user.balance, {
      duration: 1,
      ease: "easeOut"
    });
    return controls.stop;
  }, [user.balance, motionBalance]);

  const getTabBackground = () => {
    switch (activeTab) {
      case "coins": return "bg-[#FFFBEB]"; // Warm yellow
      case "quests": return "bg-[#F0FDFA]"; // Soft teal
      case "rewards": return "bg-white";
      case "profile": return "bg-[#FDF2F8]"; // Soft pink
      case "leaderboard": return "bg-[#EFF6FF]"; // Light blue
      default: return "bg-background";
    }
  };

  const navItems = [
    { id: "coins", label: "COINS", icon: KarlMarxCoin },
    { id: "quests", label: "QUESTS", icon: Map },
    { id: "rewards", label: "REWARDS", icon: Gift },
    { id: "profile", label: "PROFIL", icon: User },
    { id: "leaderboard", label: "RANGLISTE", icon: Trophy }
  ];

  if (showOnboarding) {
    return <OnboardingSlides onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className={`min-h-screen ${getTabBackground()} transition-colors duration-500 flex flex-col font-sans text-text-primary overflow-x-hidden`}>
      {/* Top Bar */}
      <header className="fixed top-0 left-0 right-0 h-16 bg-white/80 backdrop-blur-md border-b border-border z-50 px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsSidebarOpen(true)}
            className="p-2 hover:bg-secondary rounded-full transition-colors"
          >
            <Menu size={24} className="text-text-primary" />
          </button>
          <div className="relative">
            <button className="p-2 hover:bg-secondary rounded-full transition-colors">
              <Bell size={24} className="text-text-primary" />
            </button>
            <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-[#E63946] border-2 border-white rounded-full" />
          </div>
        </div>

        <div className="flex-1 flex justify-center">
          <Logo size="sm" />
        </div>

        <div className="flex items-center gap-2 bg-secondary px-3 py-1.5 rounded-full border border-border shadow-sm">
          <motion.span className="text-sm font-black text-text-primary">
            {displayBalance}
          </motion.span>
          <KarlMarxCoin size={20} />
        </div>
      </header>

      <Sidebar
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <main className="flex-1 pt-16 pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {activeTab === "coins" && <YuCoinTab />}
            {activeTab === "quests" && <QuestsTab />}
            {activeTab === "rewards" && <RewardsTab />}
            {activeTab === "profile" && <ProfileTab />}
            {activeTab === "leaderboard" && <LeaderboardTab />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 h-20 bg-white border-t border-border z-50 flex items-center justify-around px-2 pb-safe">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center gap-1 flex-1 transition-all duration-300 ${
              activeTab === item.id ? "text-[#E63946] scale-110" : "text-gray-400"
            }`}
          >
            <div className="w-6 h-6 flex items-center justify-center">
              {item.icon === KarlMarxCoin ? (
                <KarlMarxCoin size={24} className={activeTab === item.id ? "" : "grayscale opacity-50"} />
              ) : (
                <item.icon size={24} strokeWidth={activeTab === item.id ? 2.5 : 2} />
              )}
            </div>
            <span className="text-[8px] font-black uppercase tracking-widest">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

function UserApp() {
  return (
    <UserProvider>
      <UserAppContent />
    </UserProvider>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ThemeProvider>
        <LanguageProvider>
          <AuthProvider>
            <Routes>
              {/* User App */}
              <Route path="/" element={<UserApp />} />

              {/* Admin Panel */}
              <Route path="/admin/login" element={<AdminLogin />} />
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<AdminDashboard />} />
                <Route path="partners" element={<AdminPartners />} />
                <Route path="rewards" element={<AdminRewards />} />
                <Route path="quests" element={<AdminQuests />} />
                <Route path="activities" element={<AdminActivities />} />
                <Route path="powerups" element={<AdminPowerUps />} />
                <Route path="kunden" element={<AdminKunden />} />
                <Route path="users" element={<AdminUsers />} />
                <Route path="claims" element={<AdminClaims />} />
              </Route>
            </Routes>
          </AuthProvider>
        </LanguageProvider>
      </ThemeProvider>
    </BrowserRouter>
  );
}
