import React, { useState } from "react";
import { Gift, Clock, CheckCircle2 } from "lucide-react";

interface ClaimRow {
  id: string;
  username: string;
  partnerName: string;
  tierTitle: string;
  tierType: "basis" | "premium";
  isClaimed: boolean;
  isUnlocked: boolean;
  claimedAt: string | null;
  createdAt: string;
}

const MOCK_CLAIMS: ClaimRow[] = [
  { id: "c1", username: "Max Mustermann", partnerName: "Roter Turm Döner", tierTitle: "Döner für 1€", tierType: "premium", isUnlocked: true, isClaimed: true, claimedAt: "2026-04-12", createdAt: "2026-04-10" },
  { id: "c2", username: "Lisa Meyer", partnerName: "Feuerbiss", tierTitle: "Burger für 3€", tierType: "premium", isUnlocked: true, isClaimed: false, claimedAt: null, createdAt: "2026-04-11" },
  { id: "c3", username: "Tom Schneider", partnerName: "Hychinka Chemnitz", tierTitle: "5€ Rabatt", tierType: "premium", isUnlocked: true, isClaimed: false, claimedAt: null, createdAt: "2026-04-11" },
  { id: "c4", username: "Anna Braun", partnerName: "Eisfenster Gloesa", tierTitle: "2. Kugel gratis", tierType: "premium", isUnlocked: true, isClaimed: false, claimedAt: null, createdAt: "2026-04-12" },
  { id: "c5", username: "Paul Fischer", partnerName: "Döner Palace", tierTitle: "1€ Rabatt auf alles", tierType: "premium", isUnlocked: true, isClaimed: true, claimedAt: "2026-04-09", createdAt: "2026-04-08" },
  { id: "c6", username: "Tom Schneider", partnerName: "Döner Palace", tierTitle: "Gratis Soße", tierType: "basis", isUnlocked: true, isClaimed: true, claimedAt: "2026-04-05", createdAt: "2026-04-05" },
];

const AdminClaims: React.FC = () => {
  const [claims] = useState<ClaimRow[]>(MOCK_CLAIMS);
  const [filter, setFilter] = useState<"all" | "claimed" | "unlocked">("all");

  const filtered = claims.filter(c => {
    if (filter === "claimed") return c.isClaimed;
    if (filter === "unlocked") return c.isUnlocked && !c.isClaimed;
    return true;
  });

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-black text-gray-900 tracking-tight">Reward Claims</h1>
        <p className="text-sm text-gray-500 mt-1">Wer hat welchen Reward eingelöst</p>
      </div>

      <div className="flex gap-2">
        {(["all", "claimed", "unlocked"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase transition-all ${
              filter === f ? "bg-[#E63946] text-white" : "bg-white text-gray-500 border border-gray-200"
            }`}
          >
            {f === "all" ? `Alle (${claims.length})` : f === "claimed" ? `Eingelöst (${claims.filter(c => c.isClaimed).length})` : `Offen (${claims.filter(c => c.isUnlocked && !c.isClaimed).length})`}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Nutzer</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Partner</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Reward</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Status</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden lg:table-cell">Datum</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(c => (
              <tr key={c.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-bold">{c.username}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{c.partnerName}</td>
                <td className="px-4 py-3 text-sm text-gray-600 hidden md:table-cell">{c.tierTitle}</td>
                <td className="px-4 py-3">
                  {c.isClaimed ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-50 text-green-500">
                      <CheckCircle2 size={10} /> Eingelöst
                    </span>
                  ) : c.isUnlocked ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-500">
                      <Gift size={10} /> Offen
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-50 text-gray-400">
                      <Clock size={10} /> Gesperrt
                    </span>
                  )}
                </td>
                <td className="px-4 py-3 text-xs text-gray-400 hidden lg:table-cell">
                  {c.claimedAt || c.createdAt}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AdminClaims;
