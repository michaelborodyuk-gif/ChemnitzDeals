import React, { useState } from "react";
import { Store, Users, Gift, TrendingUp, Activity, CheckCircle2, Clock, Instagram, Star, AlertCircle, Eye } from "lucide-react";
import { MOCK_PARTNERS, MOCK_LEVELS } from "../constants";

// ── Mock Live Data ──────────────────────────────────
interface StoryEntry {
  id: string;
  kundenName: string;
  partnerName: string;
  instagram: string;
  postedAt: string | null;
  status: "gepostet" | "ausstehend" | "abgelaufen";
  screenshotUrl?: string;
}

interface GutscheinEntry {
  id: string;
  kundenName: string;
  partnerName: string;
  gutschein: string;
  status: "aktiv" | "eingeloest" | "abgelaufen";
  issuedAt: string;
  redeemedAt?: string;
}

interface ReviewEntry {
  id: string;
  kundenName: string;
  partnerName: string;
  platform: "google" | "instagram";
  status: "erledigt" | "ausstehend";
  postedAt?: string;
}

const MOCK_STORIES: StoryEntry[] = [
  { id: "s1", kundenName: "Max Mustermann", partnerName: "Roter Turm Döner", instagram: "@max_chemnitz", postedAt: "2026-04-12T14:30:00", status: "gepostet" },
  { id: "s2", kundenName: "Lisa Meyer", partnerName: "Feuerbiss", instagram: "@lisa_m", postedAt: null, status: "ausstehend" },
  { id: "s3", kundenName: "Tom Schneider", partnerName: "Hychinka Chemnitz", instagram: "@tom_s99", postedAt: "2026-04-11T18:00:00", status: "gepostet" },
  { id: "s4", kundenName: "Anna Braun", partnerName: "Eisfenster Gloesa", instagram: "@anna.b", postedAt: null, status: "ausstehend" },
  { id: "s5", kundenName: "Paul Fischer", partnerName: "Café Roter Turm", instagram: "@paul_f", postedAt: null, status: "abgelaufen" },
];

const MOCK_GUTSCHEINE: GutscheinEntry[] = [
  { id: "g1", kundenName: "Max Mustermann", partnerName: "Roter Turm Döner", gutschein: "Döner für 1€", status: "eingeloest", issuedAt: "2026-04-10", redeemedAt: "2026-04-12" },
  { id: "g2", kundenName: "Lisa Meyer", partnerName: "Feuerbiss", gutschein: "Burger für 3€", status: "aktiv", issuedAt: "2026-04-11" },
  { id: "g3", kundenName: "Tom Schneider", partnerName: "Hychinka Chemnitz", gutschein: "5€ Rabatt", status: "aktiv", issuedAt: "2026-04-11" },
  { id: "g4", kundenName: "Anna Braun", partnerName: "Eisfenster Gloesa", gutschein: "2. Kugel gratis", status: "aktiv", issuedAt: "2026-04-12" },
  { id: "g5", kundenName: "Paul Fischer", partnerName: "Döner Palace", gutschein: "1€ Rabatt auf alles", status: "eingeloest", issuedAt: "2026-04-08", redeemedAt: "2026-04-09" },
];

const MOCK_REVIEWS: ReviewEntry[] = [
  { id: "r1", kundenName: "Max Mustermann", partnerName: "Roter Turm Döner", platform: "google", status: "erledigt", postedAt: "2026-04-12" },
  { id: "r2", kundenName: "Tom Schneider", partnerName: "Hychinka Chemnitz", platform: "google", status: "ausstehend" },
  { id: "r3", kundenName: "Anna Braun", partnerName: "Eisfenster Gloesa", platform: "google", status: "ausstehend" },
];

// ── Component ───────────────────────────────────────
const AdminDashboard: React.FC = () => {
  const [storyFilter, setStoryFilter] = useState<"alle" | "gepostet" | "ausstehend">("alle");

  const totalPartners = MOCK_PARTNERS.length;
  const totalChallenges = MOCK_LEVELS.reduce((n, l) => n + l.challenges.length, 0);
  const totalGutscheineAktiv = MOCK_GUTSCHEINE.filter(g => g.status === "aktiv").length;
  const totalGutscheineEingeloest = MOCK_GUTSCHEINE.filter(g => g.status === "eingeloest").length;
  const totalStoriesGepostet = MOCK_STORIES.filter(s => s.status === "gepostet").length;
  const totalStoriesAusstehend = MOCK_STORIES.filter(s => s.status === "ausstehend").length;

  const filteredStories = storyFilter === "alle"
    ? MOCK_STORIES
    : MOCK_STORIES.filter(s => s.status === storyFilter);

  const storyStatusBadge = (status: StoryEntry["status"]) => {
    switch (status) {
      case "gepostet": return "bg-green-100 text-green-700";
      case "ausstehend": return "bg-yellow-100 text-yellow-700";
      case "abgelaufen": return "bg-red-100 text-red-500";
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-black text-gray-900 tracking-tight">Dashboard</h1>
        <p className="text-sm text-gray-500 mt-1">Live-Übersicht Chemnitz Deals</p>
      </div>

      {/* ── Stat Cards ─────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <Store size={20} className="text-blue-500 mb-2" />
          <p className="text-2xl font-black">{totalPartners}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Partner</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <Gift size={20} className="text-green-500 mb-2" />
          <p className="text-2xl font-black">{totalGutscheineAktiv}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Aktive Gutscheine</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <CheckCircle2 size={20} className="text-purple-500 mb-2" />
          <p className="text-2xl font-black">{totalGutscheineEingeloest}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Eingelöst</p>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
          <Instagram size={20} className="text-pink-500 mb-2" />
          <p className="text-2xl font-black">{totalStoriesGepostet}/{MOCK_STORIES.length}</p>
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Stories gepostet</p>
        </div>
      </div>

      {/* ── Warn-Banner: ausstehende Stories ───── */}
      {totalStoriesAusstehend > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 flex items-center gap-3">
          <AlertCircle size={20} className="text-yellow-500 flex-shrink-0" />
          <div>
            <p className="text-sm font-bold text-yellow-800">{totalStoriesAusstehend} Stories noch ausstehend</p>
            <p className="text-xs text-yellow-700">Kunden haben Gutschein erhalten, aber noch keine Story gepostet.</p>
          </div>
        </div>
      )}

      {/* ── Story-Tracking ─────────────────────── */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-sm font-black uppercase tracking-widest text-gray-700">Story-Tracking</h2>
          <div className="flex gap-1">
            {(["alle", "gepostet", "ausstehend"] as const).map(f => (
              <button
                key={f}
                onClick={() => setStoryFilter(f)}
                className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase transition-all ${
                  storyFilter === f ? "bg-[#E63946] text-white" : "bg-gray-100 text-gray-500"
                }`}
              >{f}</button>
            ))}
          </div>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-50">
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Kunde</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Partner</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Insta-Account</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Status</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Datum</th>
            </tr>
          </thead>
          <tbody>
            {filteredStories.map(s => (
              <tr key={s.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="p-3 text-sm font-bold">{s.kundenName}</td>
                <td className="p-3 text-sm text-gray-600">{s.partnerName}</td>
                <td className="p-3 text-sm text-blue-500 hidden md:table-cell">{s.instagram}</td>
                <td className="p-3">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${storyStatusBadge(s.status)}`}>
                    {s.status === "gepostet" ? "Gepostet" : s.status === "ausstehend" ? "Ausstehend" : "Abgelaufen"}
                  </span>
                </td>
                <td className="p-3 text-xs text-gray-400 hidden md:table-cell">
                  {s.postedAt ? new Date(s.postedAt).toLocaleDateString("de-DE") : "–"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Gutschein-Übersicht ────────────────── */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <h2 className="text-sm font-black uppercase tracking-widest text-gray-700">Gutschein-Status</h2>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-50">
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Kunde</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Partner</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Gutschein</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Status</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Eingelöst am</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_GUTSCHEINE.map(g => (
              <tr key={g.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="p-3 text-sm font-bold">{g.kundenName}</td>
                <td className="p-3 text-sm text-gray-600">{g.partnerName}</td>
                <td className="p-3 text-sm text-gray-700">{g.gutschein}</td>
                <td className="p-3">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    g.status === "aktiv" ? "bg-green-100 text-green-700"
                    : g.status === "eingeloest" ? "bg-gray-100 text-gray-500"
                    : "bg-red-100 text-red-500"
                  }`}>
                    {g.status === "aktiv" ? "Aktiv" : g.status === "eingeloest" ? "Eingelöst" : "Abgelaufen"}
                  </span>
                </td>
                <td className="p-3 text-xs text-gray-400 hidden md:table-cell">{g.redeemedAt || "–"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Google-Bewertungen ─────────────────── */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <h2 className="text-sm font-black uppercase tracking-widest text-gray-700">Google-Bewertungen</h2>
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-50">
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Kunde</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Partner</th>
              <th className="text-left p-3 text-[10px] font-bold text-gray-400 uppercase">Status</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_REVIEWS.map(r => (
              <tr key={r.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="p-3 text-sm font-bold">{r.kundenName}</td>
                <td className="p-3 text-sm text-gray-600">{r.partnerName}</td>
                <td className="p-3">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    r.status === "erledigt" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
                  }`}>
                    {r.status === "erledigt" ? "Erledigt" : "Ausstehend"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Quick-Links ────────────────────────── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <a href="/admin/kunden" className="bg-white p-4 rounded-xl border border-gray-200 hover:border-[#E63946] transition-colors flex items-center gap-3">
          <Users size={20} className="text-gray-400" />
          <div>
            <p className="text-sm font-bold">Kunden & Gutscheine</p>
            <p className="text-xs text-gray-500">Kunden hinzufügen, Gutscheine vergeben</p>
          </div>
        </a>
        <a href="/admin/partners" className="bg-white p-4 rounded-xl border border-gray-200 hover:border-[#E63946] transition-colors flex items-center gap-3">
          <Store size={20} className="text-gray-400" />
          <div>
            <p className="text-sm font-bold">Partner verwalten</p>
            <p className="text-xs text-gray-500">Hinzufügen, bearbeiten, entfernen</p>
          </div>
        </a>
        <a href="/admin/activities" className="bg-white p-4 rounded-xl border border-gray-200 hover:border-[#E63946] transition-colors flex items-center gap-3">
          <Activity size={20} className="text-gray-400" />
          <div>
            <p className="text-sm font-bold">Challenges bearbeiten</p>
            <p className="text-xs text-gray-500">Level-Challenges anpassen</p>
          </div>
        </a>
      </div>
    </div>
  );
};

export default AdminDashboard;
