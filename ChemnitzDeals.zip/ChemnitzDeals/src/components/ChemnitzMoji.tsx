import React from "react";
import { ChemnitzMojiConfig } from "../types";

interface ChemnitzMojiProps {
  config: ChemnitzMojiConfig;
  size?: number;
}

const ChemnitzMoji: React.FC<ChemnitzMojiProps> = ({ config, size = 100 }) => {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: size, height: size }}
    >
      {/* Base Layer: Karl Marx Cartoon Head */}
      <g id="base-karl">
        {/* Head Shape */}
        <path 
          d="M20 40 C20 20, 80 20, 80 40 C80 60, 70 85, 50 85 C30 85, 20 60, 20 40 Z" 
          fill="#9CA3AF" 
          stroke="#4B5563"
          strokeWidth="2"
        />
        
        {/* Wild Hair */}
        <path 
          d="M15 40 Q5 30 20 20 Q35 10 50 15 Q65 10 80 20 Q95 30 85 40" 
          fill="#E5E7EB" 
          stroke="#4B5563"
          strokeWidth="2"
        />

        {/* Big Beard */}
        <path 
          d="M25 55 C25 85, 75 85, 75 55 C75 65, 65 75, 50 75 C35 75, 25 65, 25 55 Z" 
          fill="#D1D5DB" 
          stroke="#4B5563"
          strokeWidth="2"
        />

        {/* Mustache */}
        <path 
          d="M35 55 Q50 50 65 55 Q50 65 35 55" 
          fill="#9CA3AF" 
          stroke="#4B5563"
          strokeWidth="1.5"
        />

        {/* Cute Eyes */}
        <circle cx="40" cy="42" r="4" fill="black" />
        <circle cx="60" cy="42" r="4" fill="black" />
        <circle cx="41" cy="41" r="1.5" fill="white" />
        <circle cx="61" cy="41" r="1.5" fill="white" />
      </g>

      {/* Hat Layer */}
      {config.hair === 1 && (
        <g id="baseball-cap">
          <path d="M25 35 Q50 15 75 35 L75 40 L25 40 Z" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
          <path d="M75 35 Q95 35 95 45 L75 45 Z" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
        </g>
      )}
      {config.hair === 2 && (
        <g id="winter-hat">
          <path d="M25 40 Q50 10 75 40" fill="#EF4444" stroke="#B91C1C" strokeWidth="4" strokeLinecap="round" />
          <circle cx="50" cy="15" r="5" fill="white" stroke="#B91C1C" strokeWidth="1" />
        </g>
      )}
      {config.hair === 3 && (
        <g id="crown">
          <path d="M30 35 L35 25 L50 35 L65 25 L70 35 L70 40 L30 40 Z" fill="#FCD34D" stroke="#B45309" strokeWidth="1.5" />
          <circle cx="50" cy="30" r="2" fill="#EF4444" />
        </g>
      )}

      {/* Glasses Layer */}
      {config.glasses === 1 && (
        <g id="round-glasses">
          <circle cx="40" cy="42" r="8" stroke="black" strokeWidth="2" fill="none" />
          <circle cx="60" cy="42" r="8" stroke="black" strokeWidth="2" fill="none" />
          <line x1="48" y1="42" x2="52" y2="42" stroke="black" strokeWidth="2" />
        </g>
      )}
      {config.glasses === 2 && (
        <g id="sunglasses">
          <rect x="30" y="38" width="18" height="10" rx="4" fill="black" />
          <rect x="52" y="38" width="18" height="10" rx="4" fill="black" />
          <line x1="48" y1="43" x2="52" y2="43" stroke="black" strokeWidth="2" />
        </g>
      )}
      {config.glasses === 3 && (
        <g id="nerd-glasses">
          <rect x="32" y="38" width="16" height="12" stroke="black" strokeWidth="3" fill="none" />
          <rect x="52" y="38" width="16" height="12" stroke="black" strokeWidth="3" fill="none" />
          <line x1="48" y1="44" x2="52" y2="44" stroke="black" strokeWidth="3" />
        </g>
      )}

      {/* Accessory Layer */}
      {config.accessory === 1 && (
        <g id="scarf">
          <path d="M30 75 Q50 85 70 75 L70 85 Q50 95 30 85 Z" fill="#EF4444" stroke="#B91C1C" strokeWidth="1" />
          <path d="M60 78 L65 95 L75 92 L70 75" fill="#EF4444" stroke="#B91C1C" strokeWidth="1" />
        </g>
      )}
      {config.accessory === 2 && (
        <g id="headphones">
          <path d="M20 45 Q20 15 50 15 Q80 15 80 45" fill="none" stroke="#374151" strokeWidth="4" />
          <rect x="15" y="40" width="10" height="15" rx="2" fill="#374151" />
          <rect x="75" y="40" width="10" height="15" rx="2" fill="#374151" />
        </g>
      )}
      {config.accessory === 3 && (
        <g id="chemnitz-pin">
          <circle cx="70" cy="65" r="4" fill="#FCD34D" stroke="#B45309" strokeWidth="1" />
          <rect x="68" y="63" width="4" height="2" fill="#111827" />
          <rect x="68" y="65" width="4" height="2" fill="#FCD34D" />
        </g>
      )}

      {/* Outfit Layer (Simplified as color accents on base) */}
      {config.outfit === 1 && (
        <path d="M30 85 Q50 95 70 85" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" opacity="0.5" />
      )}
      {config.outfit === 2 && (
        <path d="M30 85 Q50 95 70 85" stroke="#3B82F6" strokeWidth="4" strokeLinecap="round" opacity="0.5" />
      )}
      {config.outfit === 3 && (
        <path d="M30 85 Q50 95 70 85" stroke="#EC4899" strokeWidth="4" strokeLinecap="round" opacity="0.5" />
      )}
    </svg>
  );
};

export default ChemnitzMoji;
