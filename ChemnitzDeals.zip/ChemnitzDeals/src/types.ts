export type Category = "food" | "cafe" | "fitness" | "shopping" | "entertainment" | "beauty" | "culture" | "services";

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface RewardTier {
  id: string;
  title: string;
  description: string;
  type: "basis" | "premium";
  unlockMethod: "none" | "story" | "coins";
  coinCost?: number;
  isUnlocked: boolean;
  isClaimed: boolean;
}

export interface Reward {
  id: string;
  partnerId: string;
  title: string;
  description: string;
  category: Category;
  tiers: RewardTier[];
}

export interface Partner {
  id: string;
  name: string;
  category: Category;
  location: string;
  coordinates: Coordinates;
  image: string;
  description: string;
  rating: number;
  visitorCount: number;
  instagram: string;
  briefFacts?: string[];
  tiers: RewardTier[];
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  type: "visit" | "social" | "community" | "discovery" | "earn" | "special";
  reward: number;
  progress: number;
  maxProgress: number;
  deadline?: string; // ISO string or relative
  status: "locked" | "active" | "pending" | "completed";
  partnerId?: string;
  nodeNumber?: number;
  isRewardNode?: boolean;
  category?: "check-in" | "story" | "community" | "discovery";
}

export interface Transaction {
  id: string;
  type: "earn" | "spend" | "gift_send" | "gift_receive";
  amount: number;
  description: string;
  timestamp: string;
  status: "completed" | "pending";
}

export interface ChemnitzMojiConfig {
  hair: number;
  glasses: number;
  accessory: number;
  outfit: number;
}

export interface Challenge {
  id: string;
  title: string;
  progress: number;
  maxProgress: number;
  reward: number;
  deadline: string;
  isNew?: boolean;
}

export interface Supporter {
  partnerId: string;
  since: string; // ISO date
  bonusEarned: number;
}

export interface UserState {
  username: string;
  level: number;
  levelProgress: number;
  levelMax: number;
  balance: number;
  todayEarned: number;
  streak: number;
  streakAtRisk: boolean;
  mojiCreated: boolean;
  mojiConfig: ChemnitzMojiConfig;
  favorites: string[];
  leaderboardJoined: boolean;
  challenges: Challenge[];
  supportedPartner: Supporter | null;
  lastSupporterBonusDate: string | null;
  duelCount: number;
  blindBoxAvailable: boolean;
  lastScratchDate: string | null;
  socialFollowed: string[]; // partnerIds
  reviewedPartners: string[]; // partnerIds
  visitedPartnerIds: string[]; // partnerIds
  partnerBalances: Record<string, number>; // partnerId -> coins
}

export interface Duel {
  id: string;
  type: "step" | "prediction" | "partner";
  opponent: string;
  status: "pending" | "active" | "completed";
  myProgress: number;
  opponentProgress: number;
  deadline: string;
}

// ============================================================
// POWER-UP SYSTEM (Yu-Style Inventory)
// ============================================================
export type PowerUpType = "coin_boost" | "xp_boost" | "streak_shield" | "double_reward" | "lucky_charm";

export interface PowerUp {
  id: string;
  type: PowerUpType;
  name: string;
  description: string;
  icon: string; // emoji
  duration: number; // minutes, 0 = instant
  multiplier?: number; // e.g. 1.5 = +50%
  rarity: "common" | "rare" | "epic";
  isActive: boolean;
  expiresAt?: string; // ISO string when active
  quantity: number;
  // How to get this power-up
  coinCost?: number; // buy with coins
  streakRequired?: number; // unlock at streak X
  watchAd?: boolean; // unlock by watching ad
}

export interface InventoryState {
  powerUps: PowerUp[];
  coinPower: number; // 0-100, improves challenge rewards
}

// ============================================================
// LEVEL CHALLENGE SYSTEM (Partner-Visit Based)
// ============================================================
// Jedes Level hat mehrere Challenges. Alle drehen sich um
// Partner-Besuche, Check-ins, Social Actions — Dinge die dem
// Laden direkt nutzen. Keine Spaziergänge/Meditation.
// ============================================================
export type ChallengeType = "visit" | "multi_visit" | "story" | "review" | "social" | "streak" | "explore_category" | "spend_coins";

export interface LevelChallenge {
  id: string;
  title: string;
  description: string;
  challengeType: ChallengeType;
  icon: string; // emoji
  reward: number;
  partnerId?: string; // specific partner, or undefined = any
  partnerCategory?: Category; // e.g. "food", "cafe"
  progress: number;
  maxProgress: number;
  status: "locked" | "active" | "completed";
  coinPowerBonus: number;
  difficulty: 1 | 2 | 3; // star rating
  level: number; // which level this belongs to
}

export interface LevelDefinition {
  level: number;
  title: string;
  description: string;
  icon: string;
  challenges: LevelChallenge[];
  isUnlocked: boolean;
  requiredLevel: number; // user level needed
}

// ============================================================
// STEP DUEL (Yu-Style 24h Challenge)
// ============================================================
export interface StepDuel {
  id: string;
  challengerId: string;
  challengerName: string;
  opponentId: string;
  opponentName: string;
  wagerAmount: number; // coins wagered (0 = bragging rights)
  wagerType: "coins" | "bragging";
  challengerSteps: number;
  opponentSteps: number;
  status: "pending" | "active" | "completed";
  winnerId?: string;
  startTime: string; // ISO
  endTime: string; // ISO, 24h after start
}

// Extended UserState
export interface PowerUpSlot {
  powerUpId: string;
  activatedAt: string;
}

export interface UserInventory {
  powerUps: PowerUp[];
  coinPower: number;
  activePowerUps: PowerUpSlot[];
}

export interface SeasonalRewardPath {
  currentTier: number;
  maxTier: number;
  xp: number;
  xpToNext: number;
  rewards: SeasonalReward[];
}

export interface SeasonalReward {
  tier: number;
  type: "powerup" | "coins" | "cosmetic";
  item: string; // powerUp id or coin amount or cosmetic id
  claimed: boolean;
}
