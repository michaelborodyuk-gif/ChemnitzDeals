import React, { useState } from "react";
import { Plus, Pencil, Trash2, X, Save } from "lucide-react";
import { MOCK_PARTNERS } from "../constants";
import { Partner, RewardTier } from "../types";

const AdminRewards: React.FC = () => {
  const [partners] = useState<Partner[]>([...MOCK_PARTNERS]);
  const [filterPartner, setFilterPartner] = useState<string>("all");
  const [editing, setEditing] = useState<{ tier: RewardTier; partnerName: string; partnerId: string } | null>(null);

  // Flatten all tiers across partners
  const allTiers = partners.flatMap(p =>
    p.tiers.map(t => ({ ...t, partnerId: p.id, partnerName: p.name }))
  );

  const filtered = filterPartner === "all" ? allTiers : allTiers.filter(t => t.partnerId === filterPartner);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">Reward-Übersicht</h1>
          <p className="text-sm text-gray-500 mt-1">{allTiers.length} Rewards bei {partners.length} Partnern</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <label className="text-xs font-bold text-gray-500 uppercase">Filter:</label>
        <select
          value={filterPartner}
          onChange={e => setFilterPartner(e.target.value)}
          className="px-4 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
        >
          <option value="all">Alle Partner</option>
          {partners.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Reward</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Partner</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Typ</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Bedingung</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden lg:table-cell">Kosten</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => (
              <tr key={t.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-3">
                  <p className="text-sm font-bold">{t.title}</p>
                  <p className="text-[10px] text-gray-500">{t.description}</p>
                </td>
                <td className="px-4 py-3 text-sm text-gray-600 hidden md:table-cell">{t.partnerName}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    t.type === "premium" ? "bg-pink-50 text-pink-500" : "bg-green-50 text-green-500"
                  }`}>
                    {t.type}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-gray-600">
                  {t.unlockMethod === "none" ? "Gratis" : t.unlockMethod === "story" ? "Story + Review" : "Coins"}
                </td>
                <td className="px-4 py-3 text-xs text-gray-600 hidden lg:table-cell">
                  {t.unlockMethod === "coins" && t.coinCost ? `${t.coinCost} Coins` : "–"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-sm text-blue-700">
        <p className="font-bold">Rewards bearbeiten?</p>
        <p className="text-xs mt-1">Gehe zu <a href="/admin/partners" className="underline font-bold">Partner-Verwaltung</a> → Partner bearbeiten → dort kannst du die Gutschein-Tiers direkt beim Partner ändern.</p>
      </div>
    </div>
  );
};

export default AdminRewards;
