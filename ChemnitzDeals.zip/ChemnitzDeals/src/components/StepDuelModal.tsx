import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Swords, Clock, Trophy, Coins, Users, ChevronRight } from "lucide-react";
import { StepDuel, ChemnitzMojiConfig } from "../types";
import { MOCK_DUEL_OPPONENTS } from "../constants";
import ChemnitzMoji from "./ChemnitzMoji";
import KarlMarxCoin from "./KarlMarxCoin";

interface StepDuelModalProps {
  isOpen: boolean;
  onClose: () => void;
  userBalance: number;
  username: string;
  userMoji: ChemnitzMojiConfig;
  onDuelComplete?: (won: boolean, coinsChange: number) => void;
}

type DuelPhase = "select" | "wager" | "countdown" | "active" | "result";

interface Opponent {
  id: string;
  name: string;
  avgSteps: number;
  moji: ChemnitzMojiConfig;
}

export default function StepDuelModal({
  isOpen,
  onClose,
  userBalance,
  username,
  userMoji,
  onDuelComplete
}: StepDuelModalProps) {
  const [phase, setPhase] = useState<DuelPhase>("select");
  const [selectedOpponent, setSelectedOpponent] = useState<Opponent | null>(null);
  const [wagerType, setWagerType] = useState<"bragging" | "coins">("bragging");
  const [wagerAmount, setWagerAmount] = useState(10);
  const [mySteps, setMySteps] = useState(0);
  const [opponentSteps, setOpponentSteps] = useState(0);
  const [timeLeft, setTimeLeft] = useState(10); // Simulated 10s countdown
  const [won, setWon] = useState<boolean | null>(null);
  const [slideIndex, setSlideIndex] = useState(0);

  // Onboarding slides (like Yu)
  const onboardingSlides = [
    {
      title: "Fordere einen Freund heraus!",
      description: "Wähle einen Gegner aus der Rangliste und starte ein Duell!",
      icon: "📱"
    },
    {
      title: "Setze den Einsatz",
      description: "Spiele um Coins oder nur um die Ehre!",
      icon: "🏆"
    },
    {
      title: "Übertreffe deinen Gegner",
      description: "Dein Duell startet sofort und du hast 24 Stunden, um so viele Schritte wie möglich zu sammeln!",
      icon: "⏰"
    }
  ];

  const resetDuel = useCallback(() => {
    setPhase("select");
    setSelectedOpponent(null);
    setWagerType("bragging");
    setWagerAmount(10);
    setMySteps(0);
    setOpponentSteps(0);
    setTimeLeft(10);
    setWon(null);
    setSlideIndex(0);
  }, []);

  useEffect(() => {
    if (!isOpen) resetDuel();
  }, [isOpen, resetDuel]);

  // Simulate 24h duel in 10 seconds
  useEffect(() => {
    if (phase !== "active") return;

    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          // Determine winner
          const finalMySteps = mySteps + Math.floor(Math.random() * 800) + 400;
          const finalOpSteps = opponentSteps + Math.floor(Math.random() * 600) + 300;
          setMySteps(finalMySteps);
          setOpponentSteps(finalOpSteps);
          const didWin = finalMySteps > finalOpSteps;
          setWon(didWin);
          setPhase("result");
          return 0;
        }
        // Simulate step accumulation
        setMySteps(s => s + Math.floor(Math.random() * 500) + 200);
        setOpponentSteps(s => s + Math.floor(Math.random() * 400) + 150);
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [phase]);

  const handleStartDuel = () => {
    setPhase("active");
    setTimeLeft(10);
    setMySteps(0);
    setOpponentSteps(0);
  };

  const handleDuelEnd = () => {
    if (won !== null) {
      const coinsChange = won
        ? (wagerType === "coins" ? wagerAmount : 15)
        : (wagerType === "coins" ? -wagerAmount : 0);
      onDuelComplete?.(won, coinsChange);
    }
    onClose();
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white rounded-3xl w-[90%] max-w-md max-h-[85vh] overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <h2 className="font-black text-lg">
              {phase === "select" ? "Duell" : phase === "wager" ? "Einsatz" : phase === "active" ? "Live!" : "Ergebnis"}
            </h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
              <X size={20} />
            </button>
          </div>

          <div className="p-4 overflow-y-auto max-h-[70vh]">
            {/* ============ PHASE: SELECT OPPONENT ============ */}
            {phase === "select" && (
              <>
                {/* Onboarding Carousel (Yu-style) */}
                <div className="mb-6">
                  <div className="text-center py-6">
                    <div className="text-6xl mb-4">{onboardingSlides[slideIndex].icon}</div>
                    <h3 className="text-xl font-black mb-2">{onboardingSlides[slideIndex].title}</h3>
                    <p className="text-sm text-gray-500 px-4">{onboardingSlides[slideIndex].description}</p>
                  </div>

                  {/* Dots + Navigation */}
                  <div className="flex items-center justify-between px-2">
                    {slideIndex > 0 ? (
                      <button
                        onClick={() => setSlideIndex(s => s - 1)}
                        className="text-[#E63946] font-bold text-sm"
                      >
                        Zurück
                      </button>
                    ) : <div />}

                    <div className="flex gap-2">
                      {onboardingSlides.map((_, i) => (
                        <div
                          key={i}
                          className={`w-2.5 h-2.5 rounded-full transition-all ${
                            i === slideIndex ? "bg-[#E63946] scale-125" : "bg-gray-300"
                          }`}
                        />
                      ))}
                    </div>

                    {slideIndex < onboardingSlides.length - 1 ? (
                      <button
                        onClick={() => setSlideIndex(s => s + 1)}
                        className="text-[#E63946] font-bold text-sm"
                      >
                        Weiter
                      </button>
                    ) : (
                      <div />
                    )}
                  </div>
                </div>

                {/* Opponent List */}
                {slideIndex === onboardingSlides.length - 1 && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-2"
                  >
                    <h4 className="font-bold text-sm text-gray-600 mb-2">Gegner wählen</h4>
                    {MOCK_DUEL_OPPONENTS.map(opponent => (
                      <motion.button
                        key={opponent.id}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => {
                          setSelectedOpponent(opponent);
                          setPhase("wager");
                        }}
                        className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                      >
                        <div className="w-10 h-10 rounded-full overflow-hidden bg-gradient-to-b from-yellow-200 to-yellow-300 flex items-center justify-center">
                          <ChemnitzMoji config={opponent.moji} size={32} />
                        </div>
                        <div className="flex-1 text-left">
                          <span className="font-bold text-sm">{opponent.name}</span>
                          <p className="text-xs text-gray-500">~{opponent.avgSteps.toLocaleString()} Schritte/Tag</p>
                        </div>
                        <ChevronRight size={16} className="text-gray-400" />
                      </motion.button>
                    ))}
                  </motion.div>
                )}
              </>
            )}

            {/* ============ PHASE: SET WAGER ============ */}
            {phase === "wager" && selectedOpponent && (
              <div className="text-center">
                {/* VS Display */}
                <div className="flex items-center justify-center gap-6 mb-6">
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-b from-yellow-200 to-yellow-300 mx-auto flex items-center justify-center">
                      <ChemnitzMoji config={userMoji} size={48} />
                    </div>
                    <p className="text-xs font-bold mt-1">{username}</p>
                  </div>
                  <div className="text-2xl font-black text-[#E63946]">VS</div>
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-b from-blue-200 to-blue-300 mx-auto flex items-center justify-center">
                      <ChemnitzMoji config={selectedOpponent.moji} size={48} />
                    </div>
                    <p className="text-xs font-bold mt-1">{selectedOpponent.name}</p>
                  </div>
                </div>

                {/* Wager Type */}
                <div className="space-y-3 mb-6">
                  <h3 className="font-bold text-lg">Worum spielen?</h3>

                  <button
                    onClick={() => setWagerType("bragging")}
                    className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center gap-3 ${
                      wagerType === "bragging"
                        ? "border-[#E63946] bg-red-50"
                        : "border-gray-200"
                    }`}
                  >
                    <Trophy size={24} className="text-yellow-500" />
                    <div className="text-left flex-1">
                      <span className="font-bold text-sm">Nur um die Ehre</span>
                      <p className="text-xs text-gray-500">Kein Risiko, nur Ruhm</p>
                    </div>
                  </button>

                  <button
                    onClick={() => setWagerType("coins")}
                    className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center gap-3 ${
                      wagerType === "coins"
                        ? "border-[#E63946] bg-red-50"
                        : "border-gray-200"
                    }`}
                  >
                    <Coins size={24} className="text-yellow-500" />
                    <div className="text-left flex-1">
                      <span className="font-bold text-sm">Um Coins spielen</span>
                      <p className="text-xs text-gray-500">Gewinner bekommt den Einsatz</p>
                    </div>
                  </button>
                </div>

                {/* Coin Wager Amount */}
                {wagerType === "coins" && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    className="mb-6"
                  >
                    <p className="text-sm text-gray-500 mb-3">Einsatz wählen</p>
                    <div className="flex justify-center gap-3">
                      {[10, 25, 50, 100].map(amount => (
                        <button
                          key={amount}
                          onClick={() => setWagerAmount(amount)}
                          disabled={userBalance < amount}
                          className={`px-4 py-2 rounded-full font-bold text-sm transition-all ${
                            wagerAmount === amount
                              ? "bg-[#E63946] text-white"
                              : userBalance < amount
                                ? "bg-gray-100 text-gray-300"
                                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                          }`}
                        >
                          {amount}
                        </button>
                      ))}
                    </div>
                    <p className="text-xs text-gray-400 mt-2">Dein Guthaben: {userBalance} Coins</p>
                  </motion.div>
                )}

                {/* Start Button */}
                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={handleStartDuel}
                  className="w-full py-4 bg-[#E63946] text-white rounded-full font-bold text-sm"
                >
                  Los geht's!
                </motion.button>
              </div>
            )}

            {/* ============ PHASE: ACTIVE DUEL ============ */}
            {phase === "active" && selectedOpponent && (
              <div className="text-center">
                {/* Timer */}
                <div className="relative w-32 h-32 mx-auto mb-6">
                  <svg className="w-32 h-32 -rotate-90" viewBox="0 0 120 120">
                    <circle cx="60" cy="60" r="54" fill="none" stroke="#E5E7EB" strokeWidth="8" />
                    <motion.circle
                      cx="60" cy="60" r="54"
                      fill="none"
                      stroke="#E63946"
                      strokeWidth="8"
                      strokeLinecap="round"
                      strokeDasharray={339.3}
                      animate={{ strokeDashoffset: 339.3 * (1 - timeLeft / 10) }}
                      transition={{ duration: 1 }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <Clock size={16} className="text-gray-400 mb-1" />
                    <span className="text-2xl font-black">{timeLeft}s</span>
                    <span className="text-[10px] text-gray-500">Simulation</span>
                  </div>
                </div>

                {/* Live Step Comparison */}
                <div className="space-y-4">
                  {/* My Steps */}
                  <div className="bg-green-50 rounded-2xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-sm">{username}</span>
                      <motion.span
                        key={mySteps}
                        initial={{ scale: 1.2 }}
                        animate={{ scale: 1 }}
                        className="font-black text-xl text-green-600"
                      >
                        {mySteps.toLocaleString()}
                      </motion.span>
                    </div>
                    <div className="w-full bg-green-200 rounded-full h-3">
                      <motion.div
                        className="bg-green-500 h-3 rounded-full"
                        animate={{ width: `${Math.min((mySteps / 5000) * 100, 100)}%` }}
                      />
                    </div>
                  </div>

                  {/* Opponent Steps */}
                  <div className="bg-blue-50 rounded-2xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold text-sm">{selectedOpponent.name}</span>
                      <motion.span
                        key={opponentSteps}
                        initial={{ scale: 1.2 }}
                        animate={{ scale: 1 }}
                        className="font-black text-xl text-blue-600"
                      >
                        {opponentSteps.toLocaleString()}
                      </motion.span>
                    </div>
                    <div className="w-full bg-blue-200 rounded-full h-3">
                      <motion.div
                        className="bg-blue-500 h-3 rounded-full"
                        animate={{ width: `${Math.min((opponentSteps / 5000) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Lead Indicator */}
                <div className="mt-4 text-sm font-bold">
                  {mySteps > opponentSteps ? (
                    <span className="text-green-600">Du führst! 💪</span>
                  ) : mySteps < opponentSteps ? (
                    <span className="text-red-500">Du liegst zurück! 🏃</span>
                  ) : (
                    <span className="text-gray-500">Gleichstand!</span>
                  )}
                </div>
              </div>
            )}

            {/* ============ PHASE: RESULT ============ */}
            {phase === "result" && selectedOpponent && won !== null && (
              <div className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 10 }}
                  className="mb-6"
                >
                  <div className="text-7xl mb-3">
                    {won ? "🏆" : "😤"}
                  </div>
                  <h3 className="text-2xl font-black">
                    {won ? "Du hast gewonnen!" : "Knapp verloren!"}
                  </h3>
                </motion.div>

                {/* Final Scores */}
                <div className="flex items-center justify-center gap-8 mb-6">
                  <div className={`text-center ${won ? "scale-110" : "opacity-60"}`}>
                    <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
                      won ? "bg-yellow-200 ring-4 ring-yellow-300" : "bg-gray-200"
                    }`}>
                      <ChemnitzMoji config={userMoji} size={48} />
                    </div>
                    <p className="font-bold text-sm mt-1">{mySteps.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">Schritte</p>
                  </div>
                  <span className="text-xl font-bold text-gray-300">vs</span>
                  <div className={`text-center ${!won ? "scale-110" : "opacity-60"}`}>
                    <div className={`w-16 h-16 rounded-full mx-auto flex items-center justify-center ${
                      !won ? "bg-blue-200 ring-4 ring-blue-300" : "bg-gray-200"
                    }`}>
                      <ChemnitzMoji config={selectedOpponent.moji} size={48} />
                    </div>
                    <p className="font-bold text-sm mt-1">{opponentSteps.toLocaleString()}</p>
                    <p className="text-xs text-gray-500">Schritte</p>
                  </div>
                </div>

                {/* Reward */}
                {won && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-yellow-50 rounded-2xl p-4 mb-4 flex items-center justify-center gap-2"
                  >
                    <span className="font-bold">
                      +{wagerType === "coins" ? wagerAmount : 15}
                    </span>
                    <KarlMarxCoin size={20} />
                    <span className="text-sm text-gray-500">gewonnen!</span>
                  </motion.div>
                )}
                {!won && wagerType === "coins" && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-red-50 rounded-2xl p-4 mb-4 text-center"
                  >
                    <span className="font-bold text-red-600">-{wagerAmount} Coins</span>
                    <p className="text-xs text-gray-500 mt-1">Nächstes Mal wird's besser!</p>
                  </motion.div>
                )}

                <motion.button
                  whileTap={{ scale: 0.96 }}
                  onClick={handleDuelEnd}
                  className="w-full py-4 bg-[#E63946] text-white rounded-full font-bold text-sm"
                >
                  Fertig
                </motion.button>
              </div>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
