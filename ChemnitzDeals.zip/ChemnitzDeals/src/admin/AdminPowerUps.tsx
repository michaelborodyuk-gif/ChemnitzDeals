import React, { useState } from "react";
import { Zap, Plus, Edit2, Trash2, Shield, Target, Clover, Sparkles, X } from "lucide-react";
import { PowerUp, PowerUpType } from "../types";
import { MOCK_POWERUPS } from "../constants";

const AdminPowerUps: React.FC = () => {
  const [powerUps, setPowerUps] = useState<PowerUp[]>(MOCK_POWERUPS);
  const [editingPU, setEditingPU] = useState<PowerUp | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [form, setForm] = useState({
    name: "",
    type: "coin_boost" as PowerUpType,
    description: "",
    icon: "🧲",
    duration: 30,
    multiplier: 1.5,
    rarity: "common" as "common" | "rare" | "epic",
  });

  const openCreate = () => {
    setEditingPU(null);
    setForm({ name: "", type: "coin_boost", description: "", icon: "🧲", duration: 30, multiplier: 1.5, rarity: "common" });
    setIsModalOpen(true);
  };

  const openEdit = (pu: PowerUp) => {
    setEditingPU(pu);
    setForm({
      name: pu.name,
      type: pu.type,
      description: pu.description,
      icon: pu.icon,
      duration: pu.duration,
      multiplier: pu.multiplier || 1,
      rarity: pu.rarity,
    });
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (editingPU) {
      setPowerUps(prev => prev.map(p =>
        p.id === editingPU.id
          ? { ...p, ...form, multiplier: form.multiplier }
          : p
      ));
    } else {
      const newPU: PowerUp = {
        id: `pu${Date.now()}`,
        ...form,
        isActive: false,
        quantity: 0,
      };
      setPowerUps(prev => [...prev, newPU]);
    }
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm("Power-Up wirklich löschen?")) {
      setPowerUps(prev => prev.filter(p => p.id !== id));
    }
  };

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case "common": return "bg-gray-100 text-gray-700";
      case "rare": return "bg-blue-100 text-blue-700";
      case "epic": return "bg-purple-100 text-purple-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Power-Ups</h1>
          <p className="text-sm text-gray-500 mt-1">Verwalte das Power-Up System</p>
        </div>
        <button
          onClick={openCreate}
          className="bg-[#E63946] text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-red-600 transition-colors"
        >
          <Plus size={16} />
          Neues Power-Up
        </button>
      </div>

      {/* Economy Info */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4">
        <h3 className="font-bold text-sm text-yellow-800 mb-2">Economy Hinweis</h3>
        <p className="text-xs text-yellow-700">
          Power-Ups werden über den Seasonal Reward Path verteilt. Epische Power-Ups sollten selten sein (max 1-2 pro Saison),
          um den Wert der Location-Besuche nicht zu untergraben. Coin Boost und XP Boost sind die häufigsten.
        </p>
      </div>

      {/* Power-Up List */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="text-left p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Power-Up</th>
              <th className="text-left p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Typ</th>
              <th className="text-left p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Seltenheit</th>
              <th className="text-left p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Dauer</th>
              <th className="text-left p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Multiplikator</th>
              <th className="text-right p-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Aktionen</th>
            </tr>
          </thead>
          <tbody>
            {powerUps.map(pu => (
              <tr key={pu.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                <td className="p-4">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">{pu.icon}</span>
                    <div>
                      <p className="font-bold text-sm text-gray-900">{pu.name}</p>
                      <p className="text-xs text-gray-500">{pu.description}</p>
                    </div>
                  </div>
                </td>
                <td className="p-4">
                  <span className="text-xs font-mono bg-gray-100 px-2 py-1 rounded">{pu.type}</span>
                </td>
                <td className="p-4">
                  <span className={`text-xs px-2 py-1 rounded-full font-bold ${getRarityBadge(pu.rarity)}`}>
                    {pu.rarity === "common" ? "Gewöhnlich" : pu.rarity === "rare" ? "Selten" : "Episch"}
                  </span>
                </td>
                <td className="p-4 text-sm text-gray-700">
                  {pu.duration > 0 ? `${pu.duration} Min` : "Sofort"}
                </td>
                <td className="p-4 text-sm font-bold text-gray-700">
                  {pu.multiplier ? `×${pu.multiplier}` : "-"}
                </td>
                <td className="p-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button onClick={() => openEdit(pu)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Edit2 size={16} className="text-gray-500" />
                    </button>
                    <button onClick={() => handleDelete(pu.id)} className="p-2 hover:bg-red-50 rounded-lg transition-colors">
                      <Trash2 size={16} className="text-red-400" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-black">{editingPU ? "Power-Up bearbeiten" : "Neues Power-Up"}</h2>
              <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-100 rounded-full">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Name</label>
                <input
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm"
                  placeholder="z.B. Coin Magnet"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Typ</label>
                  <select
                    value={form.type}
                    onChange={e => setForm(f => ({ ...f, type: e.target.value as PowerUpType }))}
                    className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm"
                  >
                    <option value="coin_boost">Coin Boost</option>
                    <option value="xp_boost">XP Boost</option>
                    <option value="streak_shield">Streak Shield</option>
                    <option value="double_reward">Double Reward</option>
                    <option value="lucky_charm">Lucky Charm</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Seltenheit</label>
                  <select
                    value={form.rarity}
                    onChange={e => setForm(f => ({ ...f, rarity: e.target.value as "common" | "rare" | "epic" }))}
                    className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm"
                  >
                    <option value="common">Gewöhnlich</option>
                    <option value="rare">Selten</option>
                    <option value="epic">Episch</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Beschreibung</label>
                <input
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                  className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm"
                  placeholder="z.B. +50% Coins für 30 Minuten"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Icon</label>
                  <input
                    value={form.icon}
                    onChange={e => setForm(f => ({ ...f, icon: e.target.value }))}
                    className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm text-center text-2xl"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Dauer (Min)</label>
                  <input
                    type="number"
                    value={form.duration}
                    onChange={e => setForm(f => ({ ...f, duration: Number(e.target.value) }))}
                    className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wider">Multiplier</label>
                  <input
                    type="number"
                    step="0.1"
                    value={form.multiplier}
                    onChange={e => setForm(f => ({ ...f, multiplier: Number(e.target.value) }))}
                    className="w-full mt-1 p-3 border border-gray-200 rounded-xl text-sm"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setIsModalOpen(false)}
                className="flex-1 py-3 border border-gray-200 rounded-xl font-bold text-sm text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Abbrechen
              </button>
              <button
                onClick={handleSave}
                className="flex-1 py-3 bg-[#E63946] text-white rounded-xl font-bold text-sm hover:bg-red-600 transition-colors"
              >
                Speichern
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPowerUps;
