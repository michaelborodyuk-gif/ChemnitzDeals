import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface OnboardingSlidesProps {
  onComplete: () => void;
}

const slides = [
  {
    icon: "📍",
    title: "Besuche lokale Läden",
    description: "Checke bei Partnern in Chemnitz ein und verdiene Coins für jeden Besuch. Je öfter du kommst, desto mehr verdienst du!",
    bg: "from-[#FFFBEB] to-[#FEF3C7]",
  },
  {
    icon: "🏆",
    title: "Schließe Challenges ab",
    description: "Jedes Level hat spannende Challenges: Besuche neue Läden, poste Stories, schreibe Reviews. Steige auf und schalte mehr frei!",
    bg: "from-[#F0FDF4] to-[#DCFCE7]",
  },
  {
    icon: "🎁",
    title: "Löse echte Rewards ein",
    description: "Tausche deine Coins gegen echte Belohnungen ein — Gratis-Essen, Rabatte, VIP-Erlebnisse bei lokalen Partnern.",
    bg: "from-[#FDF2F8] to-[#FCE7F3]",
  },
  {
    icon: "⚔️",
    title: "Fordere Freunde heraus",
    description: "Starte Duell-Challenges gegen andere Chemnitzer. Spiele um Coins oder nur um die Ehre — und klettere in der Rangliste nach oben!",
    bg: "from-[#EFF6FF] to-[#DBEAFE]",
  },
];

export default function OnboardingSlides({ onComplete }: OnboardingSlidesProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const isLast = currentSlide === slides.length - 1;
  const slide = slides[currentSlide];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className={`fixed inset-0 z-[100] bg-gradient-to-b ${slide.bg} flex flex-col`}
    >
      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center"
          >
            {/* Big Icon */}
            <div className="w-32 h-32 bg-white/60 backdrop-blur-sm rounded-full flex items-center justify-center mb-8 shadow-lg">
              <span className="text-7xl">{slide.icon}</span>
            </div>

            {/* Title */}
            <h1 className="text-2xl font-black text-gray-900 mb-4">{slide.title}</h1>

            {/* Description */}
            <p className="text-sm text-gray-600 leading-relaxed max-w-xs">{slide.description}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom Navigation */}
      <div className="px-6 pb-12 flex items-center justify-between">
        {/* Back */}
        {currentSlide > 0 ? (
          <button
            onClick={() => setCurrentSlide(s => s - 1)}
            className="text-[#E63946] font-bold text-sm"
          >
            Zurück
          </button>
        ) : (
          <div className="w-16" />
        )}

        {/* Dots */}
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                i === currentSlide ? "bg-[#E63946] scale-125" : "bg-gray-300"
              }`}
            />
          ))}
        </div>

        {/* Next / Start */}
        {isLast ? (
          <button
            onClick={onComplete}
            className="bg-[#E63946] text-white px-6 py-2.5 rounded-full font-bold text-sm shadow-lg shadow-red-500/20"
          >
            Los geht's
          </button>
        ) : (
          <button
            onClick={() => setCurrentSlide(s => s + 1)}
            className="text-[#E63946] font-bold text-sm"
          >
            Weiter
          </button>
        )}
      </div>
    </motion.div>
  );
}
