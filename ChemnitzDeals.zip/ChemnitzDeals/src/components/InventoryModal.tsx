import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Backpack, Zap, Shield, Target, Clover, ChevronRight, Sparkles, ShoppingBag, Play, Lock, Flame, Coins } from "lucide-react";
import { PowerUp } from "../types";
import { MOCK_POWERUPS, MOCK_SEASONAL_PATH } from "../constants";

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  coinPower: number;
  userCoins?: number;
  userStreak?: number;
  onActivatePowerUp?: (powerUp: PowerUp) => void;
  onBuyPowerUp?: (powerUp: PowerUp, method: "coins" | "streak" | "ad") => void;
}

export default function InventoryModal({ isOpen, onClose, coinPower, userCoins = 0, userStreak = 0, onActivatePowerUp, onBuyPowerUp }: InventoryModalProps) {
  const [activeSection, setActiveSection] = useState<"inventory" | "shop" | "rewards">("shop");
  const [selectedPowerUp, setSelectedPowerUp] = useState<PowerUp | null>(null);
  const [buyingPowerUp, setBuyingPowerUp] = useState<PowerUp | null>(null);
  const [showAdConfirm, setShowAdConfirm] = useState(false);
  const [adWatched, setAdWatched] = useState(false);

  // Simulated inventory (in real app, comes from UserContext)
  const [inventory, setInventory] = useState<PowerUp[]>(() => {
    return MOCK_POWERUPS.map(pu => ({
      ...pu,
      quantity: Math.floor(Math.random() * 3) // 0-2 of each for demo
    }));
  });

  const handleBuy = (powerUp: PowerUp, method: "coins" | "streak" | "ad") => {
    onBuyPowerUp?.(powerUp, method);
    setInventory(prev => prev.map(pu =>
      pu.id === powerUp.id ? { ...pu, quantity: pu.quantity + 1 } : pu
    ));
    setBuyingPowerUp(null);
    setShowAdConfirm(false);
    setAdWatched(false);
  };

  const seasonalPath = MOCK_SEASONAL_PATH;

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "from-gray-100 to-gray-200 border-gray-300";
      case "rare": return "from-blue-50 to-blue-100 border-blue-300";
      case "epic": return "from-purple-50 to-purple-100 border-purple-300";
      default: return "from-gray-100 to-gray-200 border-gray-300";
    }
  };

  const getRarityBadge = (rarity: string) => {
    switch (rarity) {
      case "common": return { text: "Gewöhnlich", bg: "bg-gray-200 text-gray-700" };
      case "rare": return { text: "Selten", bg: "bg-blue-100 text-blue-700" };
      case "epic": return { text: "Episch", bg: "bg-purple-100 text-purple-700" };
      default: return { text: "Gewöhnlich", bg: "bg-gray-200 text-gray-700" };
    }
  };

  const getPowerUpIcon = (type: string) => {
    switch (type) {
      case "coin_boost": return <Zap size={20} className="text-yellow-500" />;
      case "xp_boost": return <Sparkles size={20} className="text-blue-500" />;
      case "streak_shield": return <Shield size={20} className="text-green-500" />;
      case "double_reward": return <Target size={20} className="text-red-500" />;
      case "lucky_charm": return <Clover size={20} className="text-emerald-500" />;
      default: return <Zap size={20} />;
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-[60] flex items-end justify-center"
        onClick={onClose}
      >
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 300 }}
          className="bg-white rounded-t-3xl w-full max-w-lg max-h-[85vh] overflow-hidden"
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center">
                <Backpack size={24} className="text-yellow-600" />
              </div>
              <div>
                <h2 className="text-lg font-bold">Inventar</h2>
                <p className="text-xs text-gray-500">Power-Ups aktivieren</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
              <X size={20} />
            </button>
          </div>

          {/* CoinPower Banner */}
          <div className="mx-4 mt-3 bg-gradient-to-r from-yellow-300 to-yellow-400 rounded-2xl p-4 flex items-center gap-3">
            <div className="w-14 h-14 bg-yellow-200 rounded-full flex items-center justify-center">
              <span className="text-2xl font-black text-yellow-700">{coinPower}</span>
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-yellow-900">CoinPower</h3>
              <p className="text-xs text-yellow-800">Verbessert deine Challenge-Rewards!</p>
            </div>
            <ChevronRight size={20} className="text-yellow-700" />
          </div>

          {/* Section Toggle — 3 Tabs */}
          <div className="flex mx-4 mt-3 bg-gray-100 rounded-xl p-1">
            <button
              onClick={() => setActiveSection("shop")}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeSection === "shop"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500"
              }`}
            >
              Shop
            </button>
            <button
              onClick={() => setActiveSection("inventory")}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeSection === "inventory"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500"
              }`}
            >
              Meine
            </button>
            <button
              onClick={() => setActiveSection("rewards")}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                activeSection === "rewards"
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-500"
              }`}
            >
              Reward-Pfad
            </button>
          </div>

          {/* Content */}
          <div className="p-4 overflow-y-auto max-h-[50vh]">
            {activeSection === "shop" ? (
              /* ========== SHOP: Buy Power-Ups ========== */
              <div className="space-y-3">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs text-gray-500">Dein Guthaben:</p>
                  <span className="text-sm font-bold text-yellow-600 flex items-center gap-1">
                    <Coins size={14} /> {userCoins} Coins
                  </span>
                </div>

                {MOCK_POWERUPS.map(powerUp => {
                  const canAfford = powerUp.coinCost ? userCoins >= powerUp.coinCost : false;
                  const streakMet = powerUp.streakRequired ? userStreak >= powerUp.streakRequired : false;

                  return (
                    <div
                      key={powerUp.id}
                      className={`bg-gradient-to-r ${getRarityColor(powerUp.rarity)} border rounded-2xl p-4`}
                    >
                      {/* Top row: icon + info */}
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm text-2xl">
                          {powerUp.icon}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm">{powerUp.name}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${getRarityBadge(powerUp.rarity).bg}`}>
                              {getRarityBadge(powerUp.rarity).text}
                            </span>
                          </div>
                          <p className="text-xs text-gray-600 mt-0.5">{powerUp.description}</p>
                        </div>
                      </div>

                      {/* Purchase options row */}
                      <div className="flex gap-2">
                        {/* Buy with Coins */}
                        {powerUp.coinCost && (
                          <motion.button
                            whileTap={{ scale: 0.95 }}
                            onClick={() => canAfford && handleBuy(powerUp, "coins")}
                            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                              canAfford
                                ? "bg-yellow-400 text-yellow-900 shadow-sm"
                                : "bg-gray-200 text-gray-400 cursor-not-allowed"
                            }`}
                          >
                            <Coins size={14} />
                            {powerUp.coinCost}
                          </motion.button>
                        )}

                        {/* Unlock via Streak */}
                        {powerUp.streakRequired && (
                          <motion.button
                            whileTap={{ scale: 0.95 }}
                            onClick={() => streakMet && handleBuy(powerUp, "streak")}
                            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                              streakMet
                                ? "bg-orange-400 text-orange-900 shadow-sm"
                                : "bg-gray-200 text-gray-400 cursor-not-allowed"
                            }`}
                          >
                            {streakMet ? <Flame size={14} /> : <Lock size={12} />}
                            {powerUp.streakRequired}d Streak
                          </motion.button>
                        )}

                        {/* Watch Ad */}
                        {powerUp.watchAd && (
                          <motion.button
                            whileTap={{ scale: 0.95 }}
                            onClick={() => {
                              setBuyingPowerUp(powerUp);
                              setShowAdConfirm(true);
                            }}
                            className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-bold bg-green-400 text-green-900 shadow-sm"
                          >
                            <Play size={14} />
                            Werbung
                          </motion.button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : activeSection === "inventory" ? (
              /* ========== INVENTORY: Owned Power-Ups ========== */
              <>
                {inventory.filter(pu => pu.quantity > 0).length === 0 ? (
                  <div className="text-center py-8">
                    <div className="w-20 h-20 bg-yellow-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                      <Backpack size={36} className="text-yellow-400" />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">Inventar ist leer</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Kaufe Power-Ups im Shop oder sammle sie über den Reward-Pfad!
                    </p>
                    <button
                      onClick={() => setActiveSection("shop")}
                      className="bg-[#E63946] text-white px-6 py-3 rounded-full font-bold text-sm"
                    >
                      Zum Shop
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {inventory.filter(pu => pu.quantity > 0).map(powerUp => (
                      <motion.button
                        key={powerUp.id}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setSelectedPowerUp(powerUp)}
                        className={`w-full bg-gradient-to-r ${getRarityColor(powerUp.rarity)} border rounded-2xl p-4 flex items-center gap-3 text-left`}
                      >
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm text-2xl">
                          {powerUp.icon}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm">{powerUp.name}</span>
                            <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${getRarityBadge(powerUp.rarity).bg}`}>
                              {getRarityBadge(powerUp.rarity).text}
                            </span>
                          </div>
                          <p className="text-xs text-gray-600 mt-0.5">{powerUp.description}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-lg font-bold text-gray-800">{powerUp.quantity}x</span>
                        </div>
                      </motion.button>
                    ))}
                  </div>
                )}
              </>
            ) : (
              /* Seasonal Reward Path */
              <div className="space-y-2">
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-semibold">Saison-Fortschritt</span>
                    <span className="text-gray-500">Stufe {seasonalPath.currentTier}/{seasonalPath.maxTier}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(seasonalPath.xp / seasonalPath.xpToNext) * 100}%` }}
                      className="bg-gradient-to-r from-[#E63946] to-[#F59E0B] h-3 rounded-full"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{seasonalPath.xp}/{seasonalPath.xpToNext} XP bis nächste Stufe</p>
                </div>

                {seasonalPath.rewards.map((reward, index) => {
                  const isUnlocked = index < seasonalPath.currentTier;
                  const isCurrent = index === seasonalPath.currentTier;
                  const powerUp = reward.type === "powerup"
                    ? MOCK_POWERUPS.find(p => p.id === reward.item)
                    : null;

                  return (
                    <div
                      key={index}
                      className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                        isUnlocked
                          ? "bg-green-50 border-green-200"
                          : isCurrent
                            ? "bg-yellow-50 border-yellow-300 ring-2 ring-yellow-200"
                            : "bg-gray-50 border-gray-200 opacity-60"
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
                        isUnlocked
                          ? "bg-green-200 text-green-800"
                          : isCurrent
                            ? "bg-yellow-200 text-yellow-800"
                            : "bg-gray-200 text-gray-500"
                      }`}>
                        {isUnlocked ? "✓" : reward.tier}
                      </div>
                      <div className="flex-1">
                        <span className="font-semibold text-sm">
                          {reward.type === "coins" && `${reward.item} Coins`}
                          {reward.type === "powerup" && (powerUp?.name || "Power-Up")}
                          {reward.type === "cosmetic" && "Goldene Krone 👑"}
                        </span>
                        <p className="text-xs text-gray-500">
                          {reward.type === "powerup" && powerUp?.description}
                          {reward.type === "coins" && "Direkt auf dein Konto"}
                          {reward.type === "cosmetic" && "Exklusives Moji-Accessoire"}
                        </p>
                      </div>
                      {isUnlocked && !reward.claimed && (
                        <button className="bg-green-500 text-white text-xs px-3 py-1.5 rounded-full font-bold">
                          Einlösen
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Ad Confirmation Modal */}
          <AnimatePresence>
            {showAdConfirm && buyingPowerUp && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/40 flex items-center justify-center p-6"
                onClick={() => { setShowAdConfirm(false); setBuyingPowerUp(null); setAdWatched(false); }}
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="bg-white rounded-3xl p-6 max-w-sm w-full"
                  onClick={e => e.stopPropagation()}
                >
                  <div className="text-center">
                    <div className="text-5xl mb-3">{buyingPowerUp.icon}</div>
                    <h3 className="text-lg font-black">{buyingPowerUp.name} freischalten</h3>
                    <p className="text-sm text-gray-600 mt-2">
                      Schau dir eine kurze Werbung an und erhalte dieses Power-Up gratis!
                    </p>

                    {!adWatched ? (
                      <motion.button
                        whileTap={{ scale: 0.95 }}
                        onClick={() => {
                          // Simulate ad watching (2s delay)
                          setAdWatched(true);
                          setTimeout(() => {
                            handleBuy(buyingPowerUp, "ad");
                          }, 2000);
                        }}
                        className="mt-6 w-full py-3 bg-green-500 text-white rounded-full font-bold text-sm flex items-center justify-center gap-2"
                      >
                        <Play size={16} />
                        Werbung ansehen
                      </motion.button>
                    ) : (
                      <div className="mt-6">
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: "100%" }}
                            transition={{ duration: 2 }}
                            className="bg-green-500 h-2 rounded-full"
                          />
                        </div>
                        <p className="text-xs text-gray-500">Werbung wird geladen...</p>
                      </div>
                    )}

                    <button
                      onClick={() => { setShowAdConfirm(false); setBuyingPowerUp(null); setAdWatched(false); }}
                      className="mt-3 w-full py-2 text-gray-500 text-sm font-semibold"
                    >
                      Abbrechen
                    </button>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* PowerUp Detail Modal */}
          <AnimatePresence>
            {selectedPowerUp && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/40 flex items-center justify-center p-6"
                onClick={() => setSelectedPowerUp(null)}
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="bg-white rounded-3xl p-6 max-w-sm w-full"
                  onClick={e => e.stopPropagation()}
                >
                  <div className="text-center">
                    <div className="text-5xl mb-3">{selectedPowerUp.icon}</div>
                    <h3 className="text-xl font-black">{selectedPowerUp.name}</h3>
                    <span className={`inline-block text-xs px-3 py-1 rounded-full mt-2 ${getRarityBadge(selectedPowerUp.rarity).bg}`}>
                      {getRarityBadge(selectedPowerUp.rarity).text}
                    </span>
                    <p className="text-gray-600 text-sm mt-3">{selectedPowerUp.description}</p>

                    {selectedPowerUp.duration > 0 && (
                      <p className="text-xs text-gray-400 mt-2">⏱ Dauer: {selectedPowerUp.duration} Minuten</p>
                    )}
                    {selectedPowerUp.multiplier && (
                      <p className="text-xs text-gray-400">✨ Multiplikator: ×{selectedPowerUp.multiplier}</p>
                    )}

                    <div className="flex gap-3 mt-6">
                      <button
                        onClick={() => setSelectedPowerUp(null)}
                        className="flex-1 py-3 border border-gray-300 rounded-full font-bold text-sm"
                      >
                        Schließen
                      </button>
                      <button
                        onClick={() => {
                          onActivatePowerUp?.(selectedPowerUp);
                          setSelectedPowerUp(null);
                        }}
                        className="flex-1 py-3 bg-[#E63946] text-white rounded-full font-bold text-sm"
                      >
                        Aktivieren
                      </button>
                    </div>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
