import React, { useState } from "react";
import { Search, Coins, CheckCircle2, X } from "lucide-react";

interface UserRow {
  id: string;
  username: string;
  level: number;
  balance: number;
  streak: number;
  is_admin: boolean;
  created_at: string;
}

const MOCK_USERS: UserRow[] = [
  { id: "u1", username: "Max Mustermann", level: 2, balance: 145, streak: 3, is_admin: false, created_at: "2026-04-01" },
  { id: "u2", username: "Lisa Meyer", level: 1, balance: 30, streak: 1, is_admin: false, created_at: "2026-04-05" },
  { id: "u3", username: "Tom Schneider", level: 3, balance: 280, streak: 7, is_admin: false, created_at: "2026-03-20" },
  { id: "u4", username: "Anna Braun", level: 1, balance: 15, streak: 0, is_admin: false, created_at: "2026-04-10" },
  { id: "u5", username: "Paul Fischer", level: 2, balance: 95, streak: 2, is_admin: false, created_at: "2026-04-02" },
  { id: "admin", username: "Admin (Misha)", level: 10, balance: 9999, streak: 99, is_admin: true, created_at: "2026-01-01" },
];

const AdminUsers: React.FC = () => {
  const [users, setUsers] = useState<UserRow[]>(MOCK_USERS);
  const [search, setSearch] = useState("");
  const [coinModal, setCoinModal] = useState<{ userId: string; username: string } | null>(null);
  const [coinAmount, setCoinAmount] = useState(100);

  const grantCoins = () => {
    if (!coinModal) return;
    setUsers(prev => prev.map(u =>
      u.id === coinModal.userId ? { ...u, balance: u.balance + coinAmount } : u
    ));
    setCoinModal(null);
    setCoinAmount(100);
  };

  const filtered = users.filter(u => u.username.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-black text-gray-900 tracking-tight">Nutzer-Verwaltung</h1>
        <p className="text-sm text-gray-500 mt-1">{users.length} registrierte Nutzer</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Nutzer suchen..."
          className="w-full pl-11 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-[#E63946] outline-none"
        />
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Nutzer</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden md:table-cell">Level</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Balance</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden lg:table-cell">Streak</th>
              <th className="text-left px-4 py-3 text-[10px] font-bold text-gray-400 uppercase hidden lg:table-cell">Rolle</th>
              <th className="text-right px-4 py-3 text-[10px] font-bold text-gray-400 uppercase">Aktionen</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(u => (
              <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-bold">{u.username}</td>
                <td className="px-4 py-3 text-sm text-gray-600 hidden md:table-cell">Lvl {u.level}</td>
                <td className="px-4 py-3 text-sm font-bold text-amber-500">{u.balance}</td>
                <td className="px-4 py-3 text-sm text-gray-600 hidden lg:table-cell">{u.streak} Tage</td>
                <td className="px-4 py-3 hidden lg:table-cell">
                  {u.is_admin && <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-500">Admin</span>}
                </td>
                <td className="px-4 py-3 text-right">
                  <button
                    onClick={() => setCoinModal({ userId: u.id, username: u.username })}
                    className="p-1.5 hover:bg-amber-50 text-amber-500 rounded-lg"
                    title="Coins vergeben"
                  >
                    <Coins size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {coinModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-black">Coins vergeben</h2>
              <button onClick={() => setCoinModal(null)} className="p-2 hover:bg-gray-100 rounded-lg"><X size={18} /></button>
            </div>
            <p className="text-sm text-gray-600 mb-3">An: <strong>{coinModal.username}</strong></p>
            <input type="number" value={coinAmount} onChange={e => setCoinAmount(Number(e.target.value))}
              className="w-full p-2.5 border rounded-xl text-sm mb-4" />
            <div className="flex gap-3">
              <button onClick={() => setCoinModal(null)} className="flex-1 py-2.5 border rounded-xl font-bold text-sm">Abbrechen</button>
              <button onClick={grantCoins} className="flex-1 py-2.5 bg-amber-500 text-white rounded-xl font-bold text-sm">Vergeben</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminUsers;
