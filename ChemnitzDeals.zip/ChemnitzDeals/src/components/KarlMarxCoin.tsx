import React from "react";
import { motion } from "motion/react";

interface KarlMarxCoinProps {
  size?: number;
  className?: string;
  animate?: boolean;
}

const KarlMarxCoin: React.FC<KarlMarxCoinProps> = ({ size = 48, className = "", animate = false }) => {
  return (
    <motion.div
      className={`relative inline-block ${className}`}
      style={{ width: size, height: size }}
      animate={animate ? {
        y: [0, -10, 0],
      } : {}}
      transition={animate ? {
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut"
      } : {}}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-lg"
      >
        {/* Coin Base with 3D Depth */}
        <circle cx="50" cy="50" r="48" fill="#D97706" /> {/* Darker Ring */}
        <circle cx="50" cy="50" r="45" fill="url(#coinGradient)" />
        
        {/* Embossed Text Around Edge */}
        <defs>
          <path id="textPath" d="M 50, 50 m -35, 0 a 35,35 0 1,1 70,0 a 35,35 0 1,1 -70,0" />
          <linearGradient id="coinGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FCD34D" /> {/* Lighter Gold */}
            <stop offset="100%" stopColor="#F59E0B" /> {/* Main Gold */}
          </linearGradient>
          <filter id="emboss" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="1" result="blur" />
            <feSpecularLighting in="blur" surfaceScale="2" specularConstant="1" specularExponent="20" lightingColor="#white" result="specOut">
              <fePointLight x="-5000" y="-10000" z="20000" />
            </feSpecularLighting>
            <feComposite in="specOut" in2="SourceAlpha" operator="in" result="specOut" />
            <feComposite in="SourceGraphic" in2="specOut" operator="arithmetic" k1="0" k2="1" k3="1" k4="0" />
          </filter>
        </defs>
        
        <text fill="#B45309" fontSize="6" fontWeight="900" letterSpacing="2" className="uppercase opacity-40">
          <textPath href="#textPath" startOffset="0%">CHEMNITZ • COINS • CHEMNITZ • COINS • </textPath>
        </text>

        {/* Karl Marx Cartoon Bust */}
        <g transform="translate(20, 20) scale(0.6)">
          {/* Head Shape */}
          <path 
            d="M20 40 C20 20, 80 20, 80 40 C80 60, 70 85, 50 85 C30 85, 20 60, 20 40 Z" 
            fill="#9CA3AF" 
            stroke="#4B5563"
            strokeWidth="2"
          />
          
          {/* Wild Hair */}
          <path 
            d="M15 40 Q5 30 20 20 Q35 10 50 15 Q65 10 80 20 Q95 30 85 40" 
            fill="#E5E7EB" 
            stroke="#4B5563"
            strokeWidth="2"
          />

          {/* Big Beard */}
          <path 
            d="M25 55 C25 85, 75 85, 75 55 C75 65, 65 75, 50 75 C35 75, 25 65, 25 55 Z" 
            fill="#D1D5DB" 
            stroke="#4B5563"
            strokeWidth="2"
          />

          {/* Mustache */}
          <path 
            d="M35 55 Q50 50 65 55 Q50 65 35 55" 
            fill="#9CA3AF" 
            stroke="#4B5563"
            strokeWidth="1.5"
          />

          {/* Cute Eyes */}
          <circle cx="40" cy="42" r="4" fill="black" />
          <circle cx="60" cy="42" r="4" fill="black" />
          <circle cx="41" cy="41" r="1.5" fill="white" />
          <circle cx="61" cy="41" r="1.5" fill="white" />
        </g>
      </svg>
    </motion.div>
  );
};

export default KarlMarxCoin;
