import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Coins, Trophy, Gift, User, LayoutGrid, Settings, LogOut, Heart, History, Bell, Sun, Moon, Languages } from "lucide-react";
import { useLanguage } from "../context/LanguageContext";
import { useUser } from "../context/UserContext";
import { useTheme } from "../context/ThemeContext";
import Logo from "./Logo";
import ChemnitzMoji from "./ChemnitzMoji";
import KarlMarxCoin from "./KarlMarxCoin";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, activeTab, setActiveTab }) => {
  const { t, language, setLanguage } = useLanguage();
  const { user } = useUser();
  const { theme, toggleTheme } = useTheme();

  const menuItems = [
    { id: "coins", label: t("coins"), icon: Coins },
    { id: "quests", label: t("quests"), icon: Trophy },
    { id: "rewards", label: t("rewards"), icon: Gift },
    { id: "profile", label: t("profile"), icon: User },
    { id: "leaderboard", label: t("leaderboard"), icon: LayoutGrid }
  ];

  const secondaryItems = [
    { id: "favorites", label: t("favorites"), icon: Heart },
    { id: "history", label: t("history"), icon: History },
    { id: "notifications", label: "Benachrichtigungen", icon: Bell },
    { id: "settings", label: t("settings"), icon: Settings }
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[60]"
          />

          {/* Sidebar Panel */}
          <motion.aside
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed top-0 left-0 bottom-0 w-[300px] bg-white z-[70] shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="p-6 flex items-center justify-between border-b border-border">
              <Logo size="sm" />
              <button 
                onClick={onClose}
                className="p-2 hover:bg-secondary rounded-full transition-colors"
              >
                <X size={24} className="text-text-primary" />
              </button>
            </div>

            {/* User Profile Summary */}
            <div className="p-6 bg-secondary/30 flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-white shadow-sm border border-border flex items-center justify-center overflow-hidden">
                <ChemnitzMoji config={user.mojiConfig} size={50} />
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-black text-text-primary tracking-tight">
                  {user.username}
                </span>
                <span className="text-[10px] font-bold text-[#E63946] uppercase tracking-widest">
                  Level {user.level}
                </span>
                <div className="flex items-center gap-1 mt-1">
                  <KarlMarxCoin size={12} />
                  <span className="text-xs font-black text-text-primary">{user.balance}</span>
                </div>
              </div>
            </div>

            {/* Main Navigation */}
            <nav className="flex-1 overflow-y-auto p-4 flex flex-col gap-1">
              <span className="px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-text-secondary">
                Hauptmenü
              </span>
              {menuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    onClose();
                  }}
                  className={`flex items-center gap-4 px-4 py-3.5 rounded-2xl transition-all ${
                    activeTab === item.id 
                      ? "bg-[#E63946] text-white shadow-lg shadow-red-500/20" 
                      : "text-text-primary hover:bg-secondary"
                  }`}
                >
                  <item.icon size={22} className={activeTab === item.id ? "text-white" : "text-text-secondary"} />
                  <span className="text-sm font-bold uppercase tracking-widest">
                    {item.label}
                  </span>
                </button>
              ))}

              <div className="my-4 border-t border-border" />

              <span className="px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-text-secondary">
                Konto
              </span>
              {secondaryItems.map((item) => (
                <button
                  key={item.id}
                  className="flex items-center gap-4 px-4 py-3.5 rounded-2xl text-text-primary hover:bg-secondary transition-all"
                >
                  <item.icon size={22} className="text-text-secondary" />
                  <span className="text-sm font-bold uppercase tracking-widest">
                    {item.label}
                  </span>
                </button>
              ))}
            </nav>

            {/* Settings Quick Bar */}
            <div className="px-6 py-4 border-t border-border flex items-center justify-between">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg bg-secondary text-text-primary hover:bg-secondary/80 transition-colors"
              >
                {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
              </button>
              <button
                onClick={() => setLanguage(language === "de" ? "en" : "de")}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-secondary text-text-primary hover:bg-secondary/80 transition-colors text-xs font-bold uppercase"
              >
                <Languages size={16} />
                {language}
              </button>
            </div>

            {/* Footer */}
            <div className="p-6 border-t border-border">
              <button className="flex items-center gap-4 px-4 py-3.5 w-full rounded-2xl text-red-500 hover:bg-red-50 transition-all">
                <LogOut size={22} />
                <span className="text-sm font-black uppercase tracking-widest">
                  Abmelden
                </span>
              </button>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
};

export default Sidebar;
